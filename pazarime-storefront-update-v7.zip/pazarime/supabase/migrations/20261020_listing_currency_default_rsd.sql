-- PazariMe 20261020: new listings default to RSD (user chooses RSD or EUR per listing in the create/edit forms).
-- Existing rows are NOT rewritten: they keep the currency already stored (EUR from 20261015), so their prices display exactly as before.
-- The CHECK listings_currency_chk (RSD/EUR) and generated price_eur (cross-currency sort/filter, ref. rate 117.5) already exist.
alter table public.listings alter column currency set default 'RSD';
