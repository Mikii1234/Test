-- PazariMe: store promotions (percentage discounts with start/end dates). ADDITIVE. Requires 20261015_product_currency.sql first.
-- Design: ONLY the percent + dates are stored. The discounted price is always computed from the product's CURRENT price, so product
-- card, product page and checkout can never disagree. A promotion is active when starts_at <= now() < ends_at (no cron needed).
-- Orders snapshot the paid unit price (product_price) plus list_price and discount_percent, so history never changes.

create table if not exists public.store_promotions (
  id          uuid primary key default gen_random_uuid(),
  listing_id  uuid not null references public.listings(id) on delete cascade,
  store_id    uuid not null references public.stores(id)   on delete cascade,
  percent     integer not null check (percent between 1 and 90),
  starts_at   timestamptz not null,
  ends_at     timestamptz not null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  constraint store_promotions_dates_chk check (ends_at > starts_at)
);
create index if not exists store_promotions_listing_idx on public.store_promotions (listing_id, starts_at, ends_at);
create index if not exists store_promotions_store_idx   on public.store_promotions (store_id);

alter table public.store_promotions enable row level security;
revoke all on public.store_promotions from anon, authenticated;
grant select on public.store_promotions to authenticated;      -- reads limited by RLS below; ALL writes go through the RPCs
drop policy if exists store_promotions_select on public.store_promotions;
create policy store_promotions_select on public.store_promotions for select to authenticated
  using ( public.is_admin() or exists (select 1 from public.stores s where s.id = store_id and s.owner_id = auth.uid()) );

-- Public, read-only list of promotions that are active right now (no private fields).
create or replace view public.active_promotions with (security_invoker = false) as
  select listing_id, store_id, percent, starts_at, ends_at from public.store_promotions
  where now() >= starts_at and now() < ends_at;
revoke all on public.active_promotions from public, anon, authenticated;   -- default privileges would otherwise make this auto-updatable view WRITABLE (as owner, bypassing RLS)
grant select on public.active_promotions to anon, authenticated;

create or replace function public.pzm_active_percent(p_listing_id uuid) returns integer
language sql stable security definer set search_path = public as $$
  select max(percent) from public.store_promotions where listing_id = p_listing_id and now() >= starts_at and now() < ends_at;
$$;
revoke all on function public.pzm_active_percent(uuid) from public;
grant execute on function public.pzm_active_percent(uuid) to anon, authenticated;

alter table public.order_items add column if not exists list_price numeric(12,2);
alter table public.order_items add column if not exists discount_percent integer;

create or replace function public.save_store_promotion(p_id uuid, p_listing_id uuid, p_percent integer, p_starts timestamptz, p_ends timestamptz)
returns uuid language plpgsql security definer set search_path = public as $$
declare l public.listings; s public.stores; v_id uuid;
begin
  if auth.uid() is null then raise exception 'Prijavi se da bi upravljao akcijama'; end if;
  select * into l from public.listings where id = p_listing_id;
  if not found or l.store_id is null then raise exception 'Proizvod nije pronađen'; end if;
  select * into s from public.stores where id = l.store_id;
  if s.owner_id is distinct from auth.uid() and not public.is_admin() then raise exception 'Možeš da upravljaš akcijama samo za proizvode svoje prodavnice'; end if;
  if coalesce(l.price, 0) <= 0 then raise exception 'Proizvod mora imati cenu veću od 0'; end if;
  if p_percent is null or p_percent < 1 or p_percent > 90 then raise exception 'Popust mora biti između 1%% i 90%%'; end if;
  if p_starts is null or p_ends is null then raise exception 'Unesi početak i kraj akcije'; end if;
  if p_ends <= p_starts then raise exception 'Kraj akcije mora biti posle početka'; end if;
  if p_ends <= now() then raise exception 'Kraj akcije mora biti u budućnosti'; end if;
  if exists (select 1 from public.store_promotions x where x.listing_id = p_listing_id and x.id is distinct from p_id
             and tstzrange(x.starts_at, x.ends_at) && tstzrange(p_starts, p_ends)) then
    raise exception 'Za ovaj proizvod već postoji akcija u tom periodu'; end if;
  if p_id is null then
    insert into public.store_promotions (listing_id, store_id, percent, starts_at, ends_at) values (p_listing_id, s.id, p_percent, p_starts, p_ends) returning id into v_id;
  else
    update public.store_promotions set percent = p_percent, starts_at = p_starts, ends_at = p_ends, updated_at = now()
      where id = p_id and store_id = s.id and listing_id = p_listing_id returning id into v_id;
    if v_id is null then raise exception 'Akcija nije pronađena'; end if;
  end if;
  return v_id;
end $$;
revoke all on function public.save_store_promotion(uuid,uuid,integer,timestamptz,timestamptz) from public, anon;
grant execute on function public.save_store_promotion(uuid,uuid,integer,timestamptz,timestamptz) to authenticated;

create or replace function public.delete_store_promotion(p_id uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Prijavi se'; end if;
  delete from public.store_promotions p where p.id = p_id
    and (public.is_admin() or exists (select 1 from public.stores s where s.id = p.store_id and s.owner_id = auth.uid()));
  if not found then raise exception 'Akcija nije pronađena'; end if;
end $$;
revoke all on function public.delete_store_promotion(uuid) from public, anon;
grant execute on function public.delete_store_promotion(uuid) to authenticated;

-- place_order(): same as 20261015, but the unit price is the ACTIVE promotional price (decided by the database, never the browser).
create or replace function public.place_order(
  p_product_id  uuid,
  p_quantity    integer,
  p_name        text,
  p_surname     text,
  p_email       text,
  p_phone       text,
  p_address     text,
  p_city        text,
  p_postal_code text,
  p_note        text default null
) returns jsonb
language plpgsql security definer
set search_path = public
as $$
declare
  v_pct integer; v_unit numeric;
  l        public.listings%rowtype;
  s        public.stores%rowtype;
  v_buyer  uuid := auth.uid();
  v_name   text := btrim(coalesce(p_name,''));
  v_surn   text := btrim(coalesce(p_surname,''));
  v_email  text := lower(btrim(coalesce(p_email,'')));
  v_phone  text := btrim(coalesce(p_phone,''));
  v_addr   text := btrim(coalesce(p_address,''));
  v_city   text := btrim(coalesce(p_city,''));
  v_zip    text := btrim(coalesce(p_postal_code,''));
  v_note   text := nullif(btrim(coalesce(p_note,'')), '');
  v_total  numeric(12,2);
  v_oid    uuid;
  v_num    bigint;
begin
  if p_quantity is null or p_quantity < 1 or p_quantity > 99 then raise exception 'Neispravna količina'; end if;
  if char_length(v_name)  not between 1 and 60  then raise exception 'Unesi ime'; end if;
  if char_length(v_surn)  not between 1 and 60  then raise exception 'Unesi prezime'; end if;
  if char_length(v_email) > 120 or v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'Email adresa nije ispravna'; end if;
  if char_length(v_phone) not between 6 and 30  then raise exception 'Broj telefona nije ispravan'; end if;
  if char_length(v_addr)  not between 3 and 200 then raise exception 'Unesi adresu'; end if;
  if char_length(v_city)  not between 2 and 80  then raise exception 'Unesi grad'; end if;
  if char_length(v_zip)   not between 3 and 12  then raise exception 'Unesi poštanski broj'; end if;
  if v_note is not null and char_length(v_note) > 500 then raise exception 'Napomena je predugačka (maks 500 karaktera)'; end if;

  -- lock the product row so concurrent buyers can't oversell the stock
  select * into l from public.listings where id = p_product_id for update;
  if not found or l.store_id is null then raise exception 'Proizvod nije dostupan za kupovinu'; end if;
  if l.status <> 'active' or l.available is false then raise exception 'Proizvod trenutno nije dostupan'; end if;

  select * into s from public.stores where id = l.store_id;
  if not found or s.status <> 'active' then raise exception 'Prodavnica trenutno ne prima porudžbine'; end if;
  if v_buyer is not null and v_buyer = s.owner_id then raise exception 'Ne možeš da kupiš sopstveni proizvod'; end if;

  -- anti-spam: max 5 orders / hour per e-mail, and per logged-in user
  if (select count(*) from public.orders o
       where o.created_at > now() - interval '1 hour'
         and (lower(o.buyer_email) = v_email or (v_buyer is not null and o.buyer_id = v_buyer))) >= 5 then
    raise exception 'Previše porudžbina u kratkom roku. Pokušaj ponovo kasnije.';
  end if;

  if l.stock is not null then
    if l.stock < p_quantity then
      raise exception 'Nema dovoljno proizvoda na stanju (dostupno: %)', l.stock;
    end if;
    update public.listings set stock = stock - p_quantity where id = l.id;
  end if;

  v_pct   := coalesce(public.pzm_active_percent(l.id), 0);               -- server decides if a promotion is active RIGHT NOW
  v_unit  := round(l.price * (100 - v_pct) / 100.0, 2);
  v_total := round(v_unit * p_quantity, 2);

  insert into public.orders (store_id, seller_id, buyer_id, store_name, store_slug,
                             buyer_name, buyer_surname, buyer_email, buyer_phone,
                             buyer_address, buyer_city, buyer_postal_code, buyer_note, total, currency)
  values (s.id, s.owner_id, v_buyer, s.name, s.slug,
          v_name, v_surn, v_email, v_phone, v_addr, v_city, v_zip, v_note, v_total, l.currency)
  returning id, order_number into v_oid, v_num;

  insert into public.order_items (order_id, product_id, product_name, product_price, product_image, quantity, subtotal, currency, list_price, discount_percent)
  values (v_oid, l.id, l.title, v_unit, l.images->>0, p_quantity, v_total, l.currency, l.price, nullif(v_pct,0));

  return jsonb_build_object('id', v_oid, 'order_number', v_num, 'total', v_total, 'currency', l.currency, 'discount_percent', v_pct);
end;
$$;
revoke all on function public.place_order(uuid,integer,text,text,text,text,text,text,text,text) from public;
grant execute on function public.place_order(uuid,integer,text,text,text,text,text,text,text,text) to anon, authenticated;

-- Make PostgREST reload its schema cache right away (fixes PGRST205 immediately after the DDL).
notify pgrst, 'reload schema';
