-- ============================================================================
-- PazariMe — SELLER STORES, v2 (reconciled with the REAL PazariMe-v2 database)
-- Idempotent. Never drops/rewrites existing tables, data or policies.
--
-- Reconciliation notes (real schema inspected 2026-10-02):
--   * REUSES  public.is_admin()                  (instead of own helper)
--   * REUSES  public.log_admin_action(...)       (admin_actions has target_id)
--   * REUSES  listings.updated_at + trg_listings_updated_at (already exist)
--   * FOLLOWS the project's trust convention:
--       client request  = current_user in ('anon','authenticated')  [and not admin]
--       trusted writes  = SECURITY DEFINER RPCs / service role / SQL editor
--   * MIRRORS the listings insert gate: only users who completed the trader
--     declaration (profiles.trader_status <> 'undeclared') may open a store.
--   * listings.status is the enum listing_status; listings.price is numeric.
--   * Existing listings (store_id IS NULL) are completely unaffected.
-- ============================================================================

-- ---------- 1. stores
create table if not exists public.stores (
  id               uuid primary key default gen_random_uuid(),
  owner_id         uuid not null unique references public.profiles(id) on delete cascade,
  name             text not null check (char_length(btrim(name)) between 2 and 60),
  slug             text not null unique
                   check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$' and char_length(slug) between 3 and 40),
  description      text check (description is null or char_length(description) <= 2000),
  logo_url         text check (logo_url  is null or logo_url  ~ '^https://'),
  cover_url        text check (cover_url is null or cover_url ~ '^https://'),
  category         text references public.categories(id) on update cascade on delete set null,
  city             text,
  contact_phone    text check (contact_phone is null or char_length(contact_phone) <= 30),
  contact_email    text check (contact_email is null or char_length(contact_email) <= 120),
  status           text not null default 'active' check (status in ('active','inactive','suspended')),
  suspended_reason text,
  views_count      integer not null default 0,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
create index if not exists stores_status_created_idx on public.stores (status, created_at desc);
create index if not exists stores_category_idx on public.stores (category);

-- ---------- 2. store_categories
create table if not exists public.store_categories (
  id         uuid primary key default gen_random_uuid(),
  store_id   uuid not null references public.stores(id) on delete cascade,
  name       text not null check (char_length(btrim(name)) between 1 and 40),
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  unique (store_id, name)
);
create index if not exists store_categories_store_idx on public.store_categories (store_id);

-- ---------- 3. extend listings (nullable/defaulted: existing rows & code unaffected)
-- (updated_at already exists in the real schema; add-if-not-exists is a no-op for it)
alter table public.listings
  add column if not exists store_id          uuid references public.stores(id) on delete cascade,
  add column if not exists store_category_id uuid references public.store_categories(id) on delete set null,
  add column if not exists slug              text,
  add column if not exists stock             integer check (stock is null or stock >= 0),
  add column if not exists available         boolean not null default true,
  add column if not exists paused_by_store   boolean not null default false,
  add column if not exists updated_at        timestamptz not null default now();

do $$ begin
  if not exists (select 1 from pg_constraint where conname = 'listings_slug_format_chk') then
    alter table public.listings
      add constraint listings_slug_format_chk
      check (slug is null or (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$' and char_length(slug) <= 60));
  end if;
end $$;

create index if not exists listings_store_idx on public.listings (store_id) where store_id is not null;
create unique index if not exists listings_store_slug_uidx
  on public.listings (store_id, slug) where store_id is not null;

-- ---------- 4. store_views (written ONLY through record_store_view RPC; RLS on, no policies)
create table if not exists public.store_views (
  store_id   uuid not null references public.stores(id) on delete cascade,
  viewer_key text not null,
  view_date  date not null default current_date,
  primary key (store_id, viewer_key, view_date)
);

-- ============================================================================
-- 5. TRIGGERS
-- Guards are SECURITY INVOKER on purpose (same as the project's protect_* triggers),
-- so current_user reflects the real caller: PostgREST clients run as
-- anon/authenticated, definer RPCs / service role / SQL editor do not.
-- ============================================================================

-- 5a. stores guard
create or replace function public.pzm_stores_guard()
returns trigger
language plpgsql
set search_path = public
as $$
declare
  v_client boolean := current_user in ('anon','authenticated') and not public.is_admin();
begin
  if tg_op = 'INSERT' then
    if v_client then
      if new.owner_id is distinct from auth.uid() then
        raise exception 'Nemate dozvolu da otvorite prodavnicu za drugog korisnika';
      end if;
      new.status           := case when new.status = 'inactive' then 'inactive' else 'active' end;
      new.suspended_reason := null;
      new.views_count      := 0;
    end if;
    new.created_at := now();
    new.updated_at := now();
    return new;
  end if;

  if v_client then
    if new.owner_id is distinct from old.owner_id then
      raise exception 'Vlasnik prodavnice se ne može promeniti';
    end if;
    if new.status = 'suspended' and old.status <> 'suspended' then
      raise exception 'Samo administrator može suspendovati prodavnicu';
    end if;
    if old.status = 'suspended' and new.status <> 'suspended' then
      raise exception 'Prodavnica je suspendovana — kontaktiraj podršku';
    end if;
    new.slug             := old.slug;
    new.views_count      := old.views_count;
    new.created_at       := old.created_at;
    new.suspended_reason := old.suspended_reason;
  end if;
  new.updated_at := now();
  return new;
end;
$$;
drop trigger if exists pzm_stores_guard_trg on public.stores;
create trigger pzm_stores_guard_trg
  before insert or update on public.stores
  for each row execute function public.pzm_stores_guard();

-- 5b. store status -> product visibility cascade (SECURITY DEFINER: must touch all its listings)
create or replace function public.pzm_stores_status_cascade()
returns trigger
language plpgsql security definer
set search_path = public
as $$
begin
  if new.status is distinct from old.status then
    if new.status <> 'active' then
      update public.listings set status = 'paused', paused_by_store = true
       where store_id = new.id and status = 'active';
    else
      update public.listings set status = 'active', paused_by_store = false
       where store_id = new.id and paused_by_store = true and status = 'paused';
    end if;
  end if;
  return null;
end;
$$;
drop trigger if exists pzm_stores_status_cascade_trg on public.stores;
create trigger pzm_stores_status_cascade_trg
  after update of status on public.stores
  for each row execute function public.pzm_stores_status_cascade();

-- 5c. listings guard — only acts on store products (store_id not null); plain listings pass untouched.
create or replace function public.pzm_listings_store_guard()
returns trigger
language plpgsql
set search_path = public
as $$
declare
  s        public.stores%rowtype;
  v_client boolean := current_user in ('anon','authenticated') and not public.is_admin();
begin
  if tg_op = 'UPDATE' and v_client then
    if new.store_id is distinct from old.store_id then
      raise exception 'Proizvod ne može da promeni prodavnicu';
    end if;
    if old.store_id is not null then
      if new.seller_id is distinct from old.seller_id then
        raise exception 'Proizvod ne može da promeni vlasnika';
      end if;
      -- a product removed by moderation can't be re-published by its owner
      if old.status = 'removed' and new.status is distinct from old.status then
        raise exception 'Proizvod je uklonjen od strane administracije';
      end if;
    end if;
  end if;

  if new.store_id is null then
    new.store_category_id := null;
    return new;
  end if;

  select * into s from public.stores where id = new.store_id;
  if not found then
    raise exception 'Prodavnica ne postoji';
  end if;

  if v_client then
    if tg_op = 'INSERT'
       and (s.owner_id is distinct from auth.uid() or new.seller_id is distinct from s.owner_id) then
      raise exception 'Nemaš dozvolu za ovu prodavnicu';
    end if;
    if new.status = 'active' and (tg_op = 'INSERT' or new.status is distinct from old.status)
       and s.status <> 'active' then
      raise exception 'Prodavnica nije aktivna — proizvod ne može biti javno vidljiv';
    end if;
    if new.status <> 'paused' then
      new.paused_by_store := false;
    end if;
  end if;

  if new.store_category_id is not null
     and (tg_op = 'INSERT' or new.store_category_id is distinct from old.store_category_id)
     and not exists (select 1 from public.store_categories c
                      where c.id = new.store_category_id and c.store_id = new.store_id) then
    raise exception 'Kategorija ne pripada ovoj prodavnici';
  end if;

  if new.slug is null or btrim(new.slug) = '' then
    new.slug := 'p-' || substr(new.id::text, 1, 8);
  end if;
  return new;
end;
$$;
drop trigger if exists pzm_listings_store_guard_trg on public.listings;
create trigger pzm_listings_store_guard_trg
  before insert or update on public.listings
  for each row execute function public.pzm_listings_store_guard();

-- (no updated_at trigger for listings: the project's trg_listings_updated_at already does it)
drop trigger if exists pzm_listings_touch_trg on public.listings;   -- v1 leftover, if it was ever created
drop function if exists public.pzm_touch_updated_at();

-- ============================================================================
-- 6. ROW LEVEL SECURITY
-- ============================================================================
alter table public.stores           enable row level security;
alter table public.store_categories enable row level security;
alter table public.store_views      enable row level security;   -- RPC only, no policies (like listing_view_events)

drop policy if exists stores_select on public.stores;
create policy stores_select on public.stores for select
  using (status = 'active' or owner_id = auth.uid() or public.is_admin());

-- same legal gate as "declared users insert own listings"
drop policy if exists stores_insert on public.stores;
create policy stores_insert on public.stores for insert to authenticated
  with check (
    owner_id = auth.uid()
    and exists (select 1 from public.profiles p
                 where p.id = auth.uid() and p.trader_status <> 'undeclared'::trader_status_type)
  );

drop policy if exists stores_update on public.stores;
create policy stores_update on public.stores for update to authenticated
  using      (owner_id = auth.uid() or public.is_admin())
  with check (owner_id = auth.uid() or public.is_admin());

drop policy if exists stores_delete on public.stores;
create policy stores_delete on public.stores for delete to authenticated
  using (owner_id = auth.uid() or public.is_admin());

drop policy if exists store_categories_select on public.store_categories;
create policy store_categories_select on public.store_categories for select
  using (exists (select 1 from public.stores s where s.id = store_id));   -- inherits stores visibility

drop policy if exists store_categories_write on public.store_categories;
create policy store_categories_write on public.store_categories for all to authenticated
  using      (public.is_admin() or exists (select 1 from public.stores s where s.id = store_id and s.owner_id = auth.uid()))
  with check (public.is_admin() or exists (select 1 from public.stores s where s.id = store_id and s.owner_id = auth.uid()));

-- listings keeps ALL of its existing policies unchanged.

-- ============================================================================
-- 7. RPCs
-- ============================================================================
create or replace function public.record_store_view(p_store_id uuid, p_viewer_key text)
returns void
language plpgsql security definer
set search_path = public
as $$
declare v_key text := p_viewer_key;
begin
  if auth.uid() is not null then v_key := 'u:' || auth.uid()::text; end if;
  if v_key is null or char_length(v_key) not between 3 and 80 then return; end if;
  if not exists (select 1 from public.stores where id = p_store_id and status = 'active') then return; end if;
  if exists (select 1 from public.stores where id = p_store_id and owner_id = auth.uid()) then return; end if;

  insert into public.store_views (store_id, viewer_key) values (p_store_id, v_key)
  on conflict do nothing;
  if found then
    update public.stores set views_count = views_count + 1 where id = p_store_id;
  end if;
end;
$$;
revoke all on function public.record_store_view(uuid, text) from public;
grant execute on function public.record_store_view(uuid, text) to anon, authenticated;

create or replace function public.store_product_counts(p_store_ids uuid[])
returns table (store_id uuid, product_count bigint)
language sql stable
set search_path = public
as $$
  select l.store_id, count(*)::bigint
    from public.listings l
   where l.store_id = any(p_store_ids) and l.status = 'active'
   group by l.store_id;
$$;
revoke all on function public.store_product_counts(uuid[]) from public;
grant execute on function public.store_product_counts(uuid[]) to anon, authenticated;

create or replace function public.admin_set_store_status(p_store_id uuid, p_status text, p_reason text default null)
returns void
language plpgsql security definer
set search_path = public
as $$
begin
  if not public.is_admin() then raise exception 'Permission denied'; end if;
  if p_status not in ('active','suspended') then raise exception 'Invalid status'; end if;

  update public.stores
     set status = p_status,
         suspended_reason = case when p_status = 'suspended' then nullif(btrim(coalesce(p_reason,'')), '') else null end
   where id = p_store_id;
  if not found then raise exception 'Store not found'; end if;

  perform public.log_admin_action(
    case when p_status = 'suspended' then 'suspend_store' else 'reactivate_store' end,
    'store', p_store_id::text,
    'Status changed to ' || p_status || coalesce(' — ' || nullif(btrim(coalesce(p_reason,'')), ''), ''));
end;
$$;
revoke all on function public.admin_set_store_status(uuid, text, text) from public, anon;
grant execute on function public.admin_set_store_status(uuid, text, text) to authenticated;

-- ============================================================================
-- 8. STORAGE — public bucket for logos/covers; path = {auth.uid()}/<file>.
--    Product photos keep using the existing `listing-images` bucket.
-- ============================================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('store-images', 'store-images', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

drop policy if exists store_images_read on storage.objects;
create policy store_images_read on storage.objects for select
  using (bucket_id = 'store-images');

drop policy if exists store_images_insert on storage.objects;
create policy store_images_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'store-images' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists store_images_update on storage.objects;
create policy store_images_update on storage.objects for update to authenticated
  using      (bucket_id = 'store-images' and (storage.foldername(name))[1] = auth.uid()::text)
  with check (bucket_id = 'store-images' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists store_images_delete on storage.objects;
create policy store_images_delete on storage.objects for delete to authenticated
  using (bucket_id = 'store-images' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));
