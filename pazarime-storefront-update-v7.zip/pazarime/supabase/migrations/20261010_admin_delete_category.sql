-- PazariMe — admin category deletion (the ONLY database change this feature still needs).
-- Additive: creates one function. No table, policy, trigger or row is changed.
-- NOTE: the live project (juzjzmaxyemwbvdmocdn) already contains the listing-type and specification
-- schema from migrations 20261009210205 / 20261010060305 (category_specifications with label +
-- category_ids[], listing_specification_values, admin_*_specification RPCs, set_listing_specifications).
-- The app now uses THAT design. This file adds only what was missing.
--
-- Refuses to delete a category that any listing or store still uses (no listing is ever orphaned/deleted).
-- Specs assigned ONLY to this category are deleted with it, because an empty category_ids array would
-- otherwise mean "all categories"; specs shared with other categories just lose this one.
create or replace function public.admin_delete_category(p_id text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare n bigint;
begin
  if not public.is_admin() then raise exception 'Permission denied'; end if;
  if not exists (select 1 from public.categories where id = p_id) then
    raise exception 'Kategorija ne postoji';
  end if;
  select count(*) into n from public.listings where category = p_id;
  if n > 0 then
    raise exception 'Kategorija ima % oglasa — isključi je umesto brisanja', n;
  end if;
  if exists (select 1 from public.stores where category = p_id) then
    raise exception 'Kategoriju koristi prodavnica — isključi je umesto brisanja';
  end if;
  delete from public.category_specifications where category_ids = array[p_id];
  update public.category_specifications set category_ids = array_remove(category_ids, p_id) where p_id = any(category_ids);
  delete from public.categories where id = p_id;
  perform public.log_admin_action('delete_category', 'category', p_id, 'Category deleted');
end;
$$;
revoke all on function public.admin_delete_category(text) from public, anon;
grant execute on function public.admin_delete_category(text) to authenticated;
