-- PazariMe: storefront enhancements (welcome section + featured products). ADDITIVE; nothing is deleted or rewritten.
-- Existing RLS keeps working: owners can already update only their own store row / their own store products, and the existing
-- triggers (pzm_stores_guard, pzm_listings_store_guard) do not restrict these new, purely presentational columns.
alter table public.stores   add column if not exists welcome_title text check (welcome_title is null or char_length(welcome_title) <= 80);
alter table public.stores   add column if not exists welcome_text  text check (welcome_text  is null or char_length(welcome_text)  <= 1000);
alter table public.listings add column if not exists is_store_featured boolean not null default false;
create index if not exists listings_store_featured_idx on public.listings (store_id) where is_store_featured;
