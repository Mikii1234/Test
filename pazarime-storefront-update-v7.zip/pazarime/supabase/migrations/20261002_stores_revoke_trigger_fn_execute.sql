-- Applied to PazariMe-v2 as migration "stores_revoke_trigger_fn_execute".
-- Trigger function must not be callable through the REST API (advisor 0028/0029).
revoke all on function public.pzm_stores_status_cascade() from public, anon, authenticated;
