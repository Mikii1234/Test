-- PazariMe 20261018: (1) real, time-based "active featured" priority in queries, (2) admin-configured specification filters.
-- ADDITIVE + idempotent: no table is altered, no data is touched. Safe to re-run.
-- Depends on: listings.is_featured / featured_until (existing), category_specifications.is_filterable (existing),
--             listing_specification_values (existing), public.is_admin() not required.

-- 1) Single definition of "featured right now": flag set AND (no expiry = admin-granted permanent, OR expiry still in the future).
--    Same rule as isFeaturedNow() in app.js. Evaluated at query time with now(), so it does NOT depend on any cron job
--    (pg_cron is not installed; expire_promotions() is only a cleanup, never required for correctness).
create or replace function public.pzm_is_featured_now(p_featured boolean, p_until timestamptz)
returns boolean
language sql stable parallel safe
set search_path = public, pg_temp
as $$ select coalesce(p_featured, false) and (p_until is null or p_until > now()) $$;

-- 2) Read-only view used by the public listing queries. security_invoker => the caller's RLS on public.listings still applies
--    (active listings public, owners see own, admins see all). featured_active is what PostgREST sorts/filters on.
create or replace view public.listings_search with (security_invoker = true) as
select l.*, public.pzm_is_featured_now(l.is_featured, l.featured_until) as featured_active
from public.listings l;

-- Supabase default privileges would give anon/authenticated INSERT/UPDATE/DELETE on a new view; lock it down to SELECT.
revoke all on public.listings_search from public, anon, authenticated;
grant select on public.listings_search to anon, authenticated;

-- 3) Specification filters. p_filters = jsonb array of objects keyed by specification id:
--      number/decimal : {"id": "<spec uuid>", "min": 2000, "max": 2010}   (either bound optional)
--      select         : {"id": "...", "values": ["a","b"]}                  (listing value is any of them)
--      multiselect    : {"id": "...", "values": ["a","b"]}                  (listing has any of them)
--      boolean        : {"id": "...", "bool": true}
--      text           : {"id": "...", "text": "intel"}                      (case-insensitive contains)
--    ALL filters must match (AND). Only specs that are currently active AND is_filterable are honored; a filter for a spec
--    that was disabled / made non-filterable is ignored (so stale links never hide results). Returns rows from
--    listings_search, so the caller can chain the usual PostgREST filters / order / limit.
create or replace function public.search_listings_by_specs(p_filters jsonb)
returns setof public.listings_search
language sql stable security invoker
set search_path = public, pg_temp
as $$
  select ls.*
  from public.listings_search ls
  where not exists (
    select 1
    from jsonb_array_elements(case when jsonb_typeof(p_filters) = 'array' then p_filters else '[]'::jsonb end) f
    where exists (select 1 from public.category_specifications s0
                  where s0.id::text = f->>'id' and s0.is_active and s0.is_filterable)
      and (coalesce(nullif(f->>'min',''), nullif(f->>'max',''), nullif(f->>'text',''), f->>'bool') is not null
           or jsonb_array_length(coalesce(f->'values', '[]'::jsonb)) > 0)
      and not exists (
        select 1
        from public.listing_specification_values v
        join public.category_specifications s on s.id = v.specification_id
        where v.listing_id = ls.id
          and v.specification_id::text = f->>'id'
          and case s.field_type
                when 'number'      then v.value_number is not null
                                        and (nullif(f->>'min','') is null or v.value_number >= (f->>'min')::numeric)
                                        and (nullif(f->>'max','') is null or v.value_number <= (f->>'max')::numeric)
                when 'decimal'     then v.value_number is not null
                                        and (nullif(f->>'min','') is null or v.value_number >= (f->>'min')::numeric)
                                        and (nullif(f->>'max','') is null or v.value_number <= (f->>'max')::numeric)
                when 'select'      then v.value_text = any (array(select jsonb_array_elements_text(coalesce(f->'values','[]'::jsonb))))
                when 'multiselect' then v.value_options && array(select jsonb_array_elements_text(coalesce(f->'values','[]'::jsonb)))
                when 'boolean'     then v.value_boolean is not null and v.value_boolean = (f->>'bool')::boolean
                when 'text'        then v.value_text is not null and position(lower(f->>'text') in lower(v.value_text)) > 0
                else false
              end
      )
  )
$$;

revoke all on function public.search_listings_by_specs(jsonb) from public;
grant execute on function public.search_listings_by_specs(jsonb) to anon, authenticated;

-- Make PostgREST pick up the new view/function immediately.
notify pgrst, 'reload schema';
