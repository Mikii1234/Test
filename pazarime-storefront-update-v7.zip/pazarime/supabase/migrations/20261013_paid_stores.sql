-- =============================================================================
-- PazariMe — PLAĆENE PRODAVNICE (otvaranje i obnova pretplate uplatom na račun)
--
-- Nadograđuje postojeći sistem uplata (promo_packages / promo_orders / promo_payment_settings /
-- promo_payment_events i admin RPC funkcije) i postojeću tabelu `stores`. Ništa se ne briše,
-- nijedna prodavnica ni proizvod se ne dira, nijedna postojeća prodavnica se ne gasi.
--
-- GRANDFATHERING (eksplicitno): sve prodavnice koje POSTOJE u trenutku ove migracije dobijaju
--   stores.grandfathered = true  (besplatna pretplata bez isteka). Admin to može da promeni po prodavnici:
--   admin_set_store_grandfathered(store_id, false, <datum isteka>)  — tada prodavnica prelazi na plaćenu pretplatu.
--   Sve prodavnice otvorene posle migracije imaju grandfathered = false i vaze samo uz plaćenu pretplatu.
--
-- Idempotentno. Preduslov: migracija 20261012_promo_bank_transfer.sql.
-- =============================================================================

-- ---------- 1. stores: pretplata ----------
alter table public.stores add column if not exists paid_until timestamptz;

do $$
begin
  if not exists (select 1 from information_schema.columns
                  where table_schema = 'public' and table_name = 'stores' and column_name = 'grandfathered') then
    -- Kolona se dodaje sa podrazumevanom vrednošću TRUE (postojeći redovi dobijaju true bez ikakvog UPDATE-a),
    -- a zatim se podrazumevana vrednost za NOVE prodavnice vraća na FALSE.
    alter table public.stores add column grandfathered boolean not null default true;
    alter table public.stores alter column grandfathered set default false;
  end if;
end $$;

create index if not exists stores_paid_until_idx on public.stores (paid_until) where not grandfathered;

-- ---------- 2. Javna vidljivost prodavnice poštuje pretplatu (bez oslanjanja na cron) ----------
drop policy if exists stores_select on public.stores;
create policy stores_select on public.stores for select
  using (
    (status = 'active' and (grandfathered or (paid_until is not null and paid_until > now())))
    or owner_id = auth.uid()
    or public.is_admin()
  );

-- ---------- 3. Prodavnica se NE može otvoriti direktno iz klijenta (zaobilaženje plaćanja) ----------
-- Jedini put je admin_confirm_promo_payment (SECURITY DEFINER) nakon potvrđene uplate.
drop policy if exists stores_insert on public.stores;
create policy stores_insert on public.stores for insert to authenticated
  with check (public.is_admin());
revoke insert on public.stores from anon, authenticated;

-- ---------- 4. Zaštita tabele stores (proširenje postojeće funkcije; sva stara pravila ostaju) ----------
create or replace function public.pzm_stores_guard()
returns trigger
language plpgsql
set search_path = public
as $$
declare
  v_client boolean := current_user in ('anon','authenticated') and not public.is_admin();
begin
  if tg_op = 'INSERT' then
    if v_client then
      raise exception 'Prodavnica se otvara tek nakon potvrđene uplate';
    end if;
    new.created_at := now();
    new.updated_at := now();
    return new;
  end if;

  if v_client then
    if new.owner_id is distinct from old.owner_id then
      raise exception 'Vlasnik prodavnice se ne može promeniti';
    end if;
    if new.status = 'suspended' and old.status <> 'suspended' then
      raise exception 'Samo administrator može suspendovati prodavnicu';
    end if;
    if old.status = 'suspended' and new.status <> 'suspended' then
      raise exception 'Prodavnica je suspendovana — kontaktiraj podršku';
    end if;
    -- pretplatu menja isključivo potvrda uplate / admin, nikada klijent
    new.paid_until   := old.paid_until;
    new.grandfathered := old.grandfathered;
    if new.status = 'active' and old.status <> 'active'
       and not (old.grandfathered or (old.paid_until is not null and old.paid_until > now())) then
      raise exception 'Pretplata prodavnice nije aktivna — obnovi pretplatu da bi prodavnica bila javno vidljiva';
    end if;
    new.slug             := old.slug;
    new.views_count      := old.views_count;
    new.created_at       := old.created_at;
    new.suspended_reason := old.suspended_reason;
  end if;
  new.updated_at := now();
  return new;
end;
$$;

-- Proizvod prodavnice ne može biti javno vidljiv ako prodavnica nema važeću pretplatu
-- (jedina izmena u odnosu na postojeću funkciju je uslov uz "s.status <> 'active'").
create or replace function public.pzm_listings_store_guard()
returns trigger
language plpgsql
set search_path = public
as $$
declare
  s        public.stores%rowtype;
  v_client boolean := current_user in ('anon','authenticated') and not public.is_admin();
begin
  if tg_op = 'UPDATE' and v_client then
    if new.store_id is distinct from old.store_id then
      raise exception 'Proizvod ne može da promeni prodavnicu';
    end if;
    if old.store_id is not null then
      if new.seller_id is distinct from old.seller_id then
        raise exception 'Proizvod ne može da promeni vlasnika';
      end if;
      if old.status = 'removed' and new.status is distinct from old.status then
        raise exception 'Proizvod je uklonjen od strane administracije';
      end if;
    end if;
  end if;

  if new.store_id is null then
    new.store_category_id := null;
    return new;
  end if;

  select * into s from public.stores where id = new.store_id;
  if not found then
    raise exception 'Prodavnica ne postoji';
  end if;

  if v_client then
    if tg_op = 'INSERT'
       and (s.owner_id is distinct from auth.uid() or new.seller_id is distinct from s.owner_id) then
      raise exception 'Nemaš dozvolu za ovu prodavnicu';
    end if;
    if new.status = 'active' and (tg_op = 'INSERT' or new.status is distinct from old.status)
       and (s.status <> 'active' or not (s.grandfathered or (s.paid_until is not null and s.paid_until > now()))) then
      raise exception 'Prodavnica nije aktivna — proizvod ne može biti javno vidljiv';
    end if;
    if new.status <> 'paused' then
      new.paused_by_store := false;
    end if;
  end if;

  if new.store_category_id is not null
     and (tg_op = 'INSERT' or new.store_category_id is distinct from old.store_category_id)
     and not exists (select 1 from public.store_categories c
                      where c.id = new.store_category_id and c.store_id = new.store_id) then
    raise exception 'Kategorija ne pripada ovoj prodavnici';
  end if;

  if new.slug is null or btrim(new.slug) = '' then
    new.slug := 'p-' || substr(new.id::text, 1, 8);
  end if;
  return new;
end;
$$;

-- ---------- 5. Paketi: vrsta (promocija oglasa / pretplata prodavnice) ----------
alter table public.promo_packages add column if not exists kind text not null default 'listing_promo';
do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'promo_packages_kind_chk') then
    alter table public.promo_packages add constraint promo_packages_kind_chk check (kind in ('listing_promo','store_subscription'));
  end if;
end $$;
create index if not exists promo_packages_kind_idx on public.promo_packages (kind, is_active, sort_order);

-- ---------- 6. Porudžbine: vrsta + podaci prodavnice ----------
alter table public.promo_orders add column if not exists kind text not null default 'listing_promo';
alter table public.promo_orders add column if not exists store_id uuid references public.stores(id) on delete set null;
alter table public.promo_orders add column if not exists store_name text;
alter table public.promo_orders add column if not exists store_slug text;
alter table public.promo_orders add column if not exists store_category text;
alter table public.promo_orders add column if not exists store_city text;
alter table public.promo_orders alter column listing_title drop not null;

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'promo_orders_kind_chk') then
    alter table public.promo_orders add constraint promo_orders_kind_chk check (kind in ('listing_promo','store_open','store_renew'));
  end if;
  if not exists (select 1 from pg_constraint where conname = 'promo_orders_listing_title_chk') then
    alter table public.promo_orders add constraint promo_orders_listing_title_chk check (kind <> 'listing_promo' or listing_title is not null);
  end if;
  if not exists (select 1 from pg_constraint where conname = 'promo_orders_store_open_chk') then
    alter table public.promo_orders add constraint promo_orders_store_open_chk check (kind <> 'store_open' or (store_name is not null and store_slug is not null));
  end if;
  if not exists (select 1 from pg_constraint where conname = 'promo_orders_store_renew_chk') then
    alter table public.promo_orders add constraint promo_orders_store_renew_chk check (kind <> 'store_renew' or store_id is not null);
  end if;
end $$;

create index if not exists promo_orders_kind_idx  on public.promo_orders (kind, created_at desc);
create index if not exists promo_orders_store_idx on public.promo_orders (store_id);
-- Tvrde garancije u bazi: jedna otvorena porudžbina za otvaranje po korisniku, jedna za obnovu po prodavnici,
-- i adresa (slug) je rezervisana dok traje otvorena porudžbina.
create unique index if not exists promo_orders_one_open_store_open_per_user
  on public.promo_orders (user_id) where kind = 'store_open' and status in ('awaiting_payment','payment_submitted');
create unique index if not exists promo_orders_one_open_store_renew_per_store
  on public.promo_orders (store_id) where kind = 'store_renew' and store_id is not null and status in ('awaiting_payment','payment_submitted');
create unique index if not exists promo_orders_open_store_slug
  on public.promo_orders (store_slug) where kind = 'store_open' and status in ('awaiting_payment','payment_submitted');

-- ---------- 7. Interno: nova referenca ----------
create or replace function public.pzm_new_order_reference()
returns text
language sql
security definer
set search_path = public
as $$
  select 'PP-' || lpad(nextval('public.promo_orders_ref_seq')::text, 6, '0') || '-' || upper(substr(md5(gen_random_uuid()::text), 1, 4));
$$;
revoke all on function public.pzm_new_order_reference() from public, anon, authenticated;

-- ---------- 8. Korisnik: porudžbina za OTVARANJE prodavnice ----------
-- Cena i trajanje se čitaju iz paketa u bazi. Naziv i adresa se čuvaju u porudžbini i koriste tek nakon potvrde.
create or replace function public.create_store_order(
  p_package_id uuid, p_name text, p_slug text,
  p_category text default null, p_city text default null, p_expected_price numeric default null)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  pk public.promo_packages%rowtype;
  st public.promo_payment_settings%rowtype;
  v_name text := btrim(coalesce(p_name, ''));
  v_slug text := lower(btrim(coalesce(p_slug, '')));
  v_cat  text := nullif(btrim(coalesce(p_category, '')), '');
  v_city text := nullif(btrim(coalesce(p_city, '')), '');
  v_ref text; v_purpose text; v_id uuid; v_dn text;
begin
  if v_uid is null then raise exception 'Prijava je obavezna'; end if;
  perform public.pzm_expire_stale_orders();
  if not public.promo_checkout_available() then
    raise exception 'Plaćanje uplatom na račun trenutno nije dostupno';
  end if;
  select * into st from public.promo_payment_settings where id;

  if not exists (select 1 from public.profiles p where p.id = v_uid and p.trader_status <> 'undeclared') then
    raise exception 'Za otvaranje prodavnice potrebna je izjava o statusu prodavca';
  end if;
  if exists (select 1 from public.stores s where s.owner_id = v_uid) then
    raise exception 'Već imaš prodavnicu. Za produženje koristi obnovu pretplate.';
  end if;

  select * into pk from public.promo_packages where id = p_package_id;
  if not found or not pk.is_active or pk.kind <> 'store_subscription' then raise exception 'Paket nije dostupan'; end if;
  if p_expected_price is not null and p_expected_price <> pk.price_rsd then
    raise exception 'Cena paketa se promenila. Osveži stranicu i pokušaj ponovo.';
  end if;

  if char_length(v_name) not between 2 and 60 then raise exception 'Naziv prodavnice mora imati 2–60 karaktera'; end if;
  if v_slug !~ '^[a-z0-9]+(-[a-z0-9]+)*$' then raise exception 'Adresa može sadržati samo mala slova, brojeve i crtice'; end if;
  if char_length(v_slug) not between 3 and 40 then raise exception 'Adresa mora imati 3–40 karaktera'; end if;
  if exists (select 1 from public.stores s where s.slug = v_slug)
     or exists (select 1 from public.promo_orders o where o.kind = 'store_open' and o.store_slug = v_slug and o.status in ('awaiting_payment','payment_submitted')) then
    raise exception 'Ta adresa je već zauzeta — izaberi drugu';
  end if;
  if exists (select 1 from public.promo_orders o where o.user_id = v_uid and o.kind = 'store_open' and o.status in ('awaiting_payment','payment_submitted')) then
    raise exception 'Već imaš porudžbinu za otvaranje prodavnice koja čeka uplatu';
  end if;
  if v_cat is not null and not exists (select 1 from public.categories c where c.id = v_cat) then raise exception 'Nepoznata kategorija'; end if;
  if v_city is not null and char_length(v_city) > 60 then raise exception 'Naziv grada je predugačak'; end if;
  if (select count(*) from public.promo_orders o where o.user_id = v_uid and o.created_at > now() - interval '1 hour') >= 5 then
    raise exception 'Previše porudžbina u kratkom roku. Pokušaj ponovo kasnije.';
  end if;

  v_ref := public.pzm_new_order_reference();
  v_purpose := replace(replace(st.purpose_template, '{referenca}', v_ref), '{paket}', pk.name);
  if position(v_ref in v_purpose) = 0 then v_purpose := btrim(v_purpose) || ' ' || v_ref; end if;
  select p.display_name into v_dn from public.profiles p where p.id = v_uid;

  insert into public.promo_orders (kind, reference, user_id, user_email, user_name, package_id, package_name, price_rsd, duration_days,
                                   store_name, store_slug, store_category, store_city, payment_snapshot)
  values ('store_open', v_ref, v_uid, coalesce(auth.jwt() ->> 'email', ''), v_dn, pk.id, pk.name, pk.price_rsd, pk.duration_days,
          v_name, v_slug, v_cat, v_city,
          jsonb_build_object('recipient_name', st.recipient_name, 'account_number', st.account_number,
                             'bank_name', st.bank_name, 'instructions', st.instructions, 'purpose', v_purpose))
  returning id into v_id;

  insert into public.promo_payment_events (order_id, event, to_status, actor_id, note)
  values (v_id, 'created', 'awaiting_payment', v_uid, 'Porudžbina za otvaranje prodavnice kreirana');
  return jsonb_build_object('id', v_id, 'reference', v_ref);
end;
$$;
revoke all on function public.create_store_order(uuid, text, text, text, text, numeric) from public, anon;
grant execute on function public.create_store_order(uuid, text, text, text, text, numeric) to authenticated;


-- ---------- 8b. Promocija oglasa ne sme da koristi paket prodavnice (i obrnuto) ----------
-- Ista funkcija kao u 20261012, jedina izmena: paket mora biti vrste 'listing_promo'.
create or replace function public.create_promo_order(p_listing_id uuid, p_package_id uuid, p_expected_price numeric default null)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  l  public.listings%rowtype;
  pk public.promo_packages%rowtype;
  st public.promo_payment_settings%rowtype;
  v_seq bigint; v_ref text; v_purpose text; v_id uuid; v_name text;
begin
  if v_uid is null then raise exception 'Prijava je obavezna'; end if;
  perform public.pzm_expire_stale_orders();
  if not public.promo_checkout_available() then
    raise exception 'Plaćanje uplatom na račun trenutno nije dostupno';
  end if;
  select * into st from public.promo_payment_settings where id;

  select * into l from public.listings where id = p_listing_id for update;
  if not found or l.seller_id <> v_uid then raise exception 'Oglas nije pronađen'; end if;
  if l.status <> 'active' then raise exception 'Samo aktivan oglas može da se promoviše'; end if;

  select * into pk from public.promo_packages where id = p_package_id;
  if not found or not pk.is_active or pk.kind <> 'listing_promo' then raise exception 'Paket nije dostupan'; end if;
  if p_expected_price is not null and p_expected_price <> pk.price_rsd then
    raise exception 'Cena paketa se promenila. Osveži stranicu i pokušaj ponovo.';
  end if;

  if exists (select 1 from public.promo_orders o where o.listing_id = l.id and o.status in ('awaiting_payment','payment_submitted')) then
    raise exception 'Za ovaj oglas već postoji porudžbina koja čeka uplatu';
  end if;
  if (select count(*) from public.promo_orders o where o.user_id = v_uid and o.created_at > now() - interval '1 hour') >= 5 then
    raise exception 'Previše porudžbina u kratkom roku. Pokušaj ponovo kasnije.';
  end if;

  v_seq := nextval('public.promo_orders_ref_seq');
  v_ref := 'PP-' || lpad(v_seq::text, 6, '0') || '-' || upper(substr(md5(gen_random_uuid()::text), 1, 4));

  v_purpose := replace(replace(st.purpose_template, '{referenca}', v_ref), '{paket}', pk.name);
  if position(v_ref in v_purpose) = 0 then v_purpose := btrim(v_purpose) || ' ' || v_ref; end if;

  select p.display_name into v_name from public.profiles p where p.id = v_uid;

  insert into public.promo_orders (reference, user_id, user_email, user_name, listing_id, listing_title,
                                   package_id, package_name, price_rsd, duration_days, payment_snapshot)
  values (v_ref, v_uid, coalesce(auth.jwt() ->> 'email', ''), v_name, l.id, l.title,
          pk.id, pk.name, pk.price_rsd, pk.duration_days,
          jsonb_build_object('recipient_name', st.recipient_name, 'account_number', st.account_number,
                             'bank_name', st.bank_name, 'instructions', st.instructions, 'purpose', v_purpose))
  returning id into v_id;

  insert into public.promo_payment_events (order_id, event, to_status, actor_id, note)
  values (v_id, 'created', 'awaiting_payment', v_uid, 'Porudžbina kreirana');

  return jsonb_build_object('id', v_id, 'reference', v_ref);
end;
$$;
revoke all on function public.create_promo_order(uuid, uuid, numeric) from public, anon;
grant execute on function public.create_promo_order(uuid, uuid, numeric) to authenticated;

-- ---------- 9. Korisnik: porudžbina za OBNOVU pretplate ----------
create or replace function public.create_store_renewal_order(p_package_id uuid, p_expected_price numeric default null)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  s  public.stores%rowtype;
  pk public.promo_packages%rowtype;
  st public.promo_payment_settings%rowtype;
  v_ref text; v_purpose text; v_id uuid; v_dn text;
begin
  if v_uid is null then raise exception 'Prijava je obavezna'; end if;
  perform public.pzm_expire_stale_orders();
  if not public.promo_checkout_available() then
    raise exception 'Plaćanje uplatom na račun trenutno nije dostupno';
  end if;
  select * into st from public.promo_payment_settings where id;

  select * into s from public.stores where owner_id = v_uid for update;
  if not found then raise exception 'Nemaš prodavnicu'; end if;
  if s.grandfathered then raise exception 'Tvoja prodavnica ima besplatnu pretplatu — obnova nije potrebna'; end if;
  if s.status = 'suspended' then raise exception 'Prodavnica je suspendovana — kontaktiraj podršku'; end if;

  select * into pk from public.promo_packages where id = p_package_id;
  if not found or not pk.is_active or pk.kind <> 'store_subscription' then raise exception 'Paket nije dostupan'; end if;
  if p_expected_price is not null and p_expected_price <> pk.price_rsd then
    raise exception 'Cena paketa se promenila. Osveži stranicu i pokušaj ponovo.';
  end if;
  if exists (select 1 from public.promo_orders o where o.kind = 'store_renew' and o.store_id = s.id and o.status in ('awaiting_payment','payment_submitted')) then
    raise exception 'Već imaš porudžbinu za obnovu koja čeka uplatu';
  end if;
  if (select count(*) from public.promo_orders o where o.user_id = v_uid and o.created_at > now() - interval '1 hour') >= 5 then
    raise exception 'Previše porudžbina u kratkom roku. Pokušaj ponovo kasnije.';
  end if;

  v_ref := public.pzm_new_order_reference();
  v_purpose := replace(replace(st.purpose_template, '{referenca}', v_ref), '{paket}', pk.name);
  if position(v_ref in v_purpose) = 0 then v_purpose := btrim(v_purpose) || ' ' || v_ref; end if;
  select p.display_name into v_dn from public.profiles p where p.id = v_uid;

  insert into public.promo_orders (kind, reference, user_id, user_email, user_name, package_id, package_name, price_rsd, duration_days,
                                   store_id, store_name, store_slug, payment_snapshot)
  values ('store_renew', v_ref, v_uid, coalesce(auth.jwt() ->> 'email', ''), v_dn, pk.id, pk.name, pk.price_rsd, pk.duration_days,
          s.id, s.name, s.slug,
          jsonb_build_object('recipient_name', st.recipient_name, 'account_number', st.account_number,
                             'bank_name', st.bank_name, 'instructions', st.instructions, 'purpose', v_purpose))
  returning id into v_id;

  insert into public.promo_payment_events (order_id, event, to_status, actor_id, note)
  values (v_id, 'created', 'awaiting_payment', v_uid, 'Porudžbina za obnovu pretplate kreirana');
  return jsonb_build_object('id', v_id, 'reference', v_ref);
end;
$$;
revoke all on function public.create_store_renewal_order(uuid, numeric) from public, anon;
grant execute on function public.create_store_renewal_order(uuid, numeric) to authenticated;

-- ---------- 10. Admin: potvrda uplate (promocija oglasa + otvaranje + obnova prodavnice) ----------
-- Jedina putanja koja aktivira promociju, otvara prodavnicu ili produžava pretplatu.
create or replace function public.admin_confirm_promo_payment(p_order_id uuid, p_note text default null)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  o public.promo_orders%rowtype; l public.listings%rowtype; s public.stores%rowtype;
  v_start timestamptz; v_end timestamptz; v_touch boolean := true; v_store uuid; v_cat text;
  v_note text := nullif(left(btrim(coalesce(p_note, '')), 500), '');
begin
  if not public.is_admin() then raise exception 'Permission denied'; end if;
  perform public.pzm_expire_stale_orders();

  select * into o from public.promo_orders where id = p_order_id for update;      -- zaključava porudžbinu: nema dvostruke obrade
  if not found then raise exception 'Porudžbina nije pronađena'; end if;
  if o.status = 'paid' then raise exception 'Porudžbina je već potvrđena'; end if;
  if o.status not in ('awaiting_payment','payment_submitted','expired') then
    raise exception 'Porudžbina je u statusu "%" i ne može da se potvrdi', o.status;
  end if;

  if o.kind = 'listing_promo' then
    if o.listing_id is null then raise exception 'Oglas više ne postoji — promocija se ne može aktivirati'; end if;
    select * into l from public.listings where id = o.listing_id for update;
    if not found or l.status <> 'active' then raise exception 'Oglas nije aktivan — promocija se ne može aktivirati'; end if;
    if l.is_featured and l.featured_until is null then
      v_start := now(); v_end := now() + make_interval(days => o.duration_days); v_touch := false;
    else
      v_start := case when l.is_featured and l.featured_until > now() then l.featured_until else now() end;
      v_end   := v_start + make_interval(days => o.duration_days);
    end if;
    if v_touch then
      perform set_config('pazarime.trusted_counter_update', 'on', true);
      update public.listings set is_featured = true, featured_until = v_end where id = l.id;
      perform set_config('pazarime.trusted_counter_update', 'off', true);
    end if;

  elsif o.kind = 'store_open' then
    if exists (select 1 from public.stores x where x.owner_id = o.user_id) then
      raise exception 'Korisnik već ima prodavnicu — porudžbina se ne može potvrditi';
    end if;
    if exists (select 1 from public.stores x where x.slug = o.store_slug) then
      raise exception 'Adresa prodavnice je već zauzeta — porudžbina se ne može potvrditi';
    end if;
    v_cat := case when o.store_category is not null and exists (select 1 from public.categories c where c.id = o.store_category) then o.store_category else null end;
    v_start := now(); v_end := v_start + make_interval(days => o.duration_days);
    insert into public.stores (owner_id, name, slug, category, city, status, paid_until, grandfathered)
    values (o.user_id, o.store_name, o.store_slug, v_cat, o.store_city, 'active', v_end, false)
    returning id into v_store;

  elsif o.kind = 'store_renew' then
    select * into s from public.stores where id = o.store_id for update;
    if not found then raise exception 'Prodavnica više ne postoji — obnova se ne može potvrditi'; end if;
    if s.grandfathered then raise exception 'Prodavnica ima besplatnu pretplatu — obnova nije potrebna (odbij porudžbinu)'; end if;
    -- nova pretplata počinje kada postojeća ističe (ili sada, ako je već istekla); plaćeni dani se ne gube
    v_start := case when s.paid_until is not null and s.paid_until > now() then s.paid_until else now() end;
    v_end   := v_start + make_interval(days => o.duration_days);
    update public.stores
       set paid_until = v_end,
           status = case when status = 'inactive' and (paid_until is null or paid_until <= now()) then 'active' else status end
     where id = s.id;
    v_store := s.id;
  end if;

  update public.promo_orders
     set status = 'paid', confirmed_by = auth.uid(), confirmed_at = now(),
         promo_starts_at = v_start, promo_ends_at = v_end, admin_note = v_note,
         store_id = coalesce(v_store, store_id)
   where id = o.id;

  insert into public.promo_payment_events (order_id, event, from_status, to_status, actor_id, note)
  values (o.id, 'confirmed', o.status, 'paid', auth.uid(),
          coalesce(v_note, '') || case when o.kind = 'listing_promo' and not v_touch then ' (oglas je već trajno izdvojen)' else '' end);
  perform public.log_admin_action('confirm_promo_payment', 'promo_order', o.id::text, 'Potvrđena uplata ' || o.reference);

  return jsonb_build_object('id', o.id, 'reference', o.reference, 'starts_at', v_start, 'ends_at', v_end, 'store_id', v_store);
end;
$$;
revoke all on function public.admin_confirm_promo_payment(uuid, text) from public, anon;
grant execute on function public.admin_confirm_promo_payment(uuid, text) to authenticated;

-- ---------- 11. Admin: paketi (sada sa vrstom) ----------
create or replace function public.admin_upsert_promo_package(p_id uuid, p_data jsonb)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_name text := btrim(coalesce(p_data ->> 'name', ''));
  v_desc text := nullif(btrim(coalesce(p_data ->> 'description', '')), '');
  v_price numeric; v_days numeric; v_active boolean := coalesce((p_data ->> 'is_active')::boolean, true);
  v_kind text := coalesce(nullif(p_data ->> 'kind', ''), 'listing_promo');
  v_id uuid := p_id;
begin
  if not public.is_admin() then raise exception 'Permission denied'; end if;
  if char_length(v_name) not between 1 and 80 then raise exception 'Naziv paketa je obavezan (do 80 karaktera)'; end if;
  if v_desc is not null and char_length(v_desc) > 500 then raise exception 'Opis je predugačak (do 500 karaktera)'; end if;
  if v_kind not in ('listing_promo','store_subscription') then raise exception 'Nepoznata vrsta paketa'; end if;
  begin v_price := (p_data ->> 'price_rsd')::numeric; exception when others then raise exception 'Cena mora biti broj'; end;
  begin v_days  := (p_data ->> 'duration_days')::numeric; exception when others then raise exception 'Trajanje mora biti broj dana'; end;
  if v_price is null or v_price <= 0 or v_price > 10000000 then raise exception 'Cena mora biti veća od 0 RSD'; end if;
  if v_days is null or v_days <> trunc(v_days) or v_days < 1 or v_days > 365 then raise exception 'Trajanje mora biti ceo broj dana od 1 do 365'; end if;

  if v_id is null then
    insert into public.promo_packages (name, description, price_rsd, duration_days, is_active, kind, sort_order)
    values (v_name, v_desc, round(v_price, 2), v_days::int, v_active, v_kind,
            coalesce((select max(sort_order) from public.promo_packages), 0) + 10)
    returning id into v_id;
    perform public.log_admin_action('create_promo_package', 'promo_package', v_id::text, 'Novi paket: ' || v_name);
  else
    update public.promo_packages        -- vrsta paketa se ne menja nakon kreiranja
       set name = v_name, description = v_desc, price_rsd = round(v_price, 2), duration_days = v_days::int, is_active = v_active
     where id = v_id;
    if not found then raise exception 'Paket nije pronađen'; end if;
    perform public.log_admin_action('update_promo_package', 'promo_package', v_id::text, 'Izmenjen paket: ' || v_name);
  end if;
  return v_id;
end;
$$;
revoke all on function public.admin_upsert_promo_package(uuid, jsonb) from public, anon;
grant execute on function public.admin_upsert_promo_package(uuid, jsonb) to authenticated;

-- ---------- 12. Admin: besplatna pretplata (grandfathering) po prodavnici ----------
create or replace function public.admin_set_store_grandfathered(p_store_id uuid, p_value boolean, p_paid_until timestamptz default null)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_admin() then raise exception 'Permission denied'; end if;
  if p_value then
    update public.stores set grandfathered = true where id = p_store_id;
  else
    if p_paid_until is null or p_paid_until <= now() then
      raise exception 'Za prelazak na plaćenu pretplatu unesi datum isteka u budućnosti';
    end if;
    update public.stores set grandfathered = false, paid_until = p_paid_until where id = p_store_id;
  end if;
  if not found then raise exception 'Prodavnica nije pronađena'; end if;
  perform public.log_admin_action('set_store_grandfathered', 'store', p_store_id::text,
    case when p_value then 'Besplatna pretplata uključena' else 'Prelazak na plaćenu pretplatu do ' || p_paid_until::text end);
end;
$$;
revoke all on function public.admin_set_store_grandfathered(uuid, boolean, timestamptz) from public, anon;
grant execute on function public.admin_set_store_grandfathered(uuid, boolean, timestamptz) to authenticated;

-- ---------- 13. Istek (promocije + pretplate prodavnica) ----------
-- Deaktivira prodavnice bez važeće pretplate; postojeći trigger pauzira njihove proizvode,
-- a obnova ih vraća. Grandfathered prodavnice se NE diraju.
create or replace function public.expire_promotions()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare n_list integer; n_ord integer; n_store integer;
begin
  n_ord := public.pzm_expire_stale_orders();
  perform set_config('pazarime.trusted_counter_update', 'on', true);
  update public.listings set is_featured = false, featured_until = null
   where is_featured and featured_until is not null and featured_until <= now();
  get diagnostics n_list = row_count;
  perform set_config('pazarime.trusted_counter_update', 'off', true);

  update public.stores set status = 'inactive'
   where status = 'active' and not grandfathered and (paid_until is null or paid_until <= now());
  get diagnostics n_store = row_count;

  return jsonb_build_object('listings_unfeatured', n_list, 'orders_expired', n_ord, 'stores_deactivated', n_store);
end;
$$;
revoke all on function public.expire_promotions() from public;
grant execute on function public.expire_promotions() to anon, authenticated;
