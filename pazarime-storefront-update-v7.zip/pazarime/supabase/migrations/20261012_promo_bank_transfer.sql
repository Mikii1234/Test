-- =============================================================================
-- PazariMe — PROMOCIJA OGLASA UPLATOM NA RAČUN (ručna provera uplate)
--
-- Dodaje (ništa se ne briše, ne menja se nijedan postojeći red):
--   * promo_packages           paketi promocije (naziv, opis, cena u RSD, trajanje, aktivan, redosled)
--   * promo_payment_settings   jedan red: primalac / broj računa / banka / uputstvo / svrha / uključeno (samo admin)
--   * promo_orders             porudžbine promocije (jedinstvena referenca, snimak cene/trajanja/uputstva)
--   * promo_payment_events     istorija (audit) svake porudžbine, vidi samo admin
--   * RPC funkcije (SECURITY DEFINER): create_promo_order, submit_promo_payment, cancel_promo_order,
--     admin_confirm_promo_payment, admin_reject_promo_payment, admin_upsert_promo_package,
--     admin_set_promo_package_active, admin_reorder_promo_packages, admin_get_payment_settings,
--     admin_save_payment_settings, promo_checkout_available, expire_promotions
--   * BEFORE INSERT zaštita na listings (is_featured / featured_until) — vidi tačku 1.
--
-- Koristi postojeće: is_admin(), log_admin_action(), set_updated_at(), listings.is_featured / featured_until,
-- GUC 'pazarime.trusted_counter_update' (isti mehanizam koji već koristi admin_set_featured).
--
-- Idempotentno (može da se pokrene više puta). Bez ijednog pravog podatka o računu:
-- uplate su ISKLJUČENE dok admin ne unese primaoca, broj računa i svrhu uplate.
-- =============================================================================

-- ---------- 1. Postojeća rupa: INSERT oglasa sa is_featured=true (zaobilazi plaćanje) ----------
-- protect_listing_counters važi samo za UPDATE. Bez ovoga bi korisnik mogao da kreira oglas
-- koji je odmah "izdvojen" bez isteka. Pouzdane funkcije (admin_set_featured, potvrda uplate) postavljaju GUC.
create or replace function public.pzm_listings_featured_insert_guard()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  if current_setting('pazarime.trusted_counter_update', true) is distinct from 'on' then
    new.is_featured := false;
    new.featured_until := null;
  end if;
  return new;
end;
$$;
drop trigger if exists pzm_listings_featured_insert_guard_trg on public.listings;
create trigger pzm_listings_featured_insert_guard_trg
  before insert on public.listings
  for each row execute function public.pzm_listings_featured_insert_guard();

create index if not exists listings_featured_until_idx
  on public.listings (featured_until) where is_featured and featured_until is not null;

-- ---------- 2. Paketi promocije ----------
create table if not exists public.promo_packages (
  id            uuid primary key default gen_random_uuid(),
  name          text not null check (char_length(btrim(name)) between 1 and 80),
  description   text check (description is null or char_length(description) <= 500),
  price_rsd     numeric(12,2) not null check (price_rsd > 0 and price_rsd <= 10000000),
  duration_days integer not null check (duration_days between 1 and 365),
  is_active     boolean not null default true,
  sort_order    integer not null default 0,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists promo_packages_order_idx on public.promo_packages (is_active, sort_order);

-- ---------- 3. Podešavanja uplate (tačno jedan red; čita samo admin) ----------
create table if not exists public.promo_payment_settings (
  id                  boolean primary key default true check (id),
  enabled             boolean not null default false,
  recipient_name      text check (recipient_name is null or char_length(recipient_name) <= 120),
  account_number      text check (account_number is null or char_length(account_number) <= 40),
  bank_name           text check (bank_name is null or char_length(bank_name) <= 120),
  instructions        text check (instructions is null or char_length(instructions) <= 1000),
  purpose_template    text check (purpose_template is null or char_length(purpose_template) <= 140),
  pending_expiry_days integer not null default 7 check (pending_expiry_days between 1 and 60),
  updated_by          uuid,
  updated_at          timestamptz not null default now()
);
insert into public.promo_payment_settings (id) values (true) on conflict (id) do nothing;

-- ---------- 4. Porudžbine promocije ----------
create sequence if not exists public.promo_orders_ref_seq;

create table if not exists public.promo_orders (
  id               uuid primary key default gen_random_uuid(),
  reference        text not null unique,
  user_id          uuid not null references public.profiles(id) on delete restrict,
  user_email       text,
  user_name        text,
  listing_id       uuid references public.listings(id) on delete set null,
  listing_title    text not null,
  package_id       uuid references public.promo_packages(id) on delete set null,
  package_name     text not null,
  price_rsd        numeric(12,2) not null check (price_rsd > 0),
  duration_days    integer not null check (duration_days between 1 and 365),
  status           text not null default 'awaiting_payment'
                   check (status in ('awaiting_payment','payment_submitted','paid','rejected','cancelled','expired')),
  payment_snapshot jsonb not null,
  user_note        text check (user_note is null or char_length(user_note) <= 300),
  submitted_at     timestamptz,
  cancelled_at     timestamptz,
  expired_at       timestamptz,
  rejected_at      timestamptz,
  rejected_by      uuid,
  reject_reason    text,
  confirmed_at     timestamptz,
  confirmed_by     uuid,
  admin_note       text,
  promo_starts_at  timestamptz,
  promo_ends_at    timestamptz,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  constraint promo_orders_paid_complete_chk check (status <> 'paid' or
    (confirmed_at is not null and confirmed_by is not null and promo_starts_at is not null and promo_ends_at is not null)),
  constraint promo_orders_rejected_complete_chk check (status <> 'rejected' or
    (rejected_at is not null and reject_reason is not null))
);
create index if not exists promo_orders_user_idx    on public.promo_orders (user_id, created_at desc);
create index if not exists promo_orders_status_idx  on public.promo_orders (status, created_at desc);
create index if not exists promo_orders_listing_idx on public.promo_orders (listing_id);
-- Najviše jedna otvorena porudžbina po oglasu (tvrda garancija u bazi, ne samo u funkciji)
create unique index if not exists promo_orders_one_open_per_listing
  on public.promo_orders (listing_id) where listing_id is not null and status in ('awaiting_payment','payment_submitted');

-- ---------- 5. Istorija (audit) ----------
create table if not exists public.promo_payment_events (
  id          uuid primary key default gen_random_uuid(),
  order_id    uuid not null references public.promo_orders(id) on delete cascade,
  event       text not null check (event in ('created','submitted','confirmed','rejected','cancelled','expired')),
  from_status text,
  to_status   text,
  actor_id    uuid,
  note        text,
  created_at  timestamptz not null default now()
);
create index if not exists promo_events_order_idx on public.promo_payment_events (order_id, created_at);

-- ---------- 6. updated_at ----------
drop trigger if exists trg_promo_packages_updated_at on public.promo_packages;
create trigger trg_promo_packages_updated_at before update on public.promo_packages
  for each row execute function public.set_updated_at();
drop trigger if exists trg_promo_orders_updated_at on public.promo_orders;
create trigger trg_promo_orders_updated_at before update on public.promo_orders
  for each row execute function public.set_updated_at();

-- ---------- 7. RLS + privilegije: korisnici samo ČITAJU; sve upise rade RPC funkcije ----------
alter table public.promo_packages         enable row level security;
alter table public.promo_payment_settings enable row level security;
alter table public.promo_orders           enable row level security;
alter table public.promo_payment_events   enable row level security;

revoke all on public.promo_packages, public.promo_payment_settings, public.promo_orders, public.promo_payment_events from anon, authenticated;
revoke all on sequence public.promo_orders_ref_seq from anon, authenticated;
grant select on public.promo_packages, public.promo_payment_settings, public.promo_orders, public.promo_payment_events to authenticated;

drop policy if exists promo_packages_select on public.promo_packages;
create policy promo_packages_select on public.promo_packages for select to authenticated
  using (is_active or public.is_admin());

drop policy if exists promo_orders_select on public.promo_orders;
create policy promo_orders_select on public.promo_orders for select to authenticated
  using (user_id = auth.uid() or public.is_admin());

drop policy if exists promo_events_select_admin on public.promo_payment_events;
create policy promo_events_select_admin on public.promo_payment_events for select to authenticated
  using (public.is_admin());

drop policy if exists promo_settings_select_admin on public.promo_payment_settings;
create policy promo_settings_select_admin on public.promo_payment_settings for select to authenticated
  using (public.is_admin());

-- ---------- 8. Da li je uplata uopšte omogućena (bez otkrivanja podataka o računu) ----------
create or replace function public.promo_checkout_available()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce((
    select s.enabled
       and coalesce(btrim(s.recipient_name), '')   <> ''
       and coalesce(btrim(s.account_number), '')   <> ''
       and coalesce(btrim(s.purpose_template), '') <> ''
      from public.promo_payment_settings s where s.id
  ), false);
$$;
revoke all on function public.promo_checkout_available() from public, anon;
grant execute on function public.promo_checkout_available() to authenticated;

-- ---------- 9. Interno: istek neplaćenih porudžbina (poziva se iz drugih funkcija) ----------
create or replace function public.pzm_expire_stale_orders()
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare n integer; v_days integer;
begin
  select pending_expiry_days into v_days from public.promo_payment_settings where id;
  with x as (
    update public.promo_orders
       set status = 'expired', expired_at = now()
     where status = 'awaiting_payment'
       and created_at < now() - make_interval(days => coalesce(v_days, 7))
    returning id
  )
  insert into public.promo_payment_events (order_id, event, from_status, to_status, note)
  select id, 'expired', 'awaiting_payment', 'expired', 'Porudžbina je istekla bez uplate' from x;
  get diagnostics n = row_count;
  return n;
end;
$$;
revoke all on function public.pzm_expire_stale_orders() from public, anon, authenticated;

-- ---------- 10. Korisnik: kreiranje porudžbine (cena i trajanje se čitaju ISKLJUČIVO iz baze) ----------
create or replace function public.create_promo_order(p_listing_id uuid, p_package_id uuid, p_expected_price numeric default null)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  l  public.listings%rowtype;
  pk public.promo_packages%rowtype;
  st public.promo_payment_settings%rowtype;
  v_seq bigint; v_ref text; v_purpose text; v_id uuid; v_name text;
begin
  if v_uid is null then raise exception 'Prijava je obavezna'; end if;
  perform public.pzm_expire_stale_orders();
  if not public.promo_checkout_available() then
    raise exception 'Plaćanje uplatom na račun trenutno nije dostupno';
  end if;
  select * into st from public.promo_payment_settings where id;

  select * into l from public.listings where id = p_listing_id for update;   -- zaključava oglas: nema paralelnih porudžbina
  if not found or l.seller_id <> v_uid then raise exception 'Oglas nije pronađen'; end if;
  if l.status <> 'active' then raise exception 'Samo aktivan oglas može da se promoviše'; end if;

  select * into pk from public.promo_packages where id = p_package_id;
  if not found or not pk.is_active then raise exception 'Paket nije dostupan'; end if;
  if p_expected_price is not null and p_expected_price <> pk.price_rsd then
    raise exception 'Cena paketa se promenila. Osveži stranicu i pokušaj ponovo.';
  end if;

  if exists (select 1 from public.promo_orders o where o.listing_id = l.id and o.status in ('awaiting_payment','payment_submitted')) then
    raise exception 'Za ovaj oglas već postoji porudžbina koja čeka uplatu';
  end if;
  if (select count(*) from public.promo_orders o where o.user_id = v_uid and o.created_at > now() - interval '1 hour') >= 5 then
    raise exception 'Previše porudžbina u kratkom roku. Pokušaj ponovo kasnije.';
  end if;

  v_seq := nextval('public.promo_orders_ref_seq');
  v_ref := 'PP-' || lpad(v_seq::text, 6, '0') || '-' || upper(substr(md5(gen_random_uuid()::text), 1, 4));

  v_purpose := replace(replace(st.purpose_template, '{referenca}', v_ref), '{paket}', pk.name);
  if position(v_ref in v_purpose) = 0 then v_purpose := btrim(v_purpose) || ' ' || v_ref; end if;   -- referenca MORA biti u svrsi uplate

  select p.display_name into v_name from public.profiles p where p.id = v_uid;

  insert into public.promo_orders (reference, user_id, user_email, user_name, listing_id, listing_title,
                                   package_id, package_name, price_rsd, duration_days, payment_snapshot)
  values (v_ref, v_uid, coalesce(auth.jwt() ->> 'email', ''), v_name, l.id, l.title,
          pk.id, pk.name, pk.price_rsd, pk.duration_days,
          jsonb_build_object('recipient_name', st.recipient_name, 'account_number', st.account_number,
                             'bank_name', st.bank_name, 'instructions', st.instructions, 'purpose', v_purpose))
  returning id into v_id;

  insert into public.promo_payment_events (order_id, event, to_status, actor_id, note)
  values (v_id, 'created', 'awaiting_payment', v_uid, 'Porudžbina kreirana');

  return jsonb_build_object('id', v_id, 'reference', v_ref);
end;
$$;
revoke all on function public.create_promo_order(uuid, uuid, numeric) from public, anon;
grant execute on function public.create_promo_order(uuid, uuid, numeric) to authenticated;

-- ---------- 11. Korisnik: "Uplatio/la sam" (NE aktivira promociju — samo traži proveru) ----------
create or replace function public.submit_promo_payment(p_order_id uuid, p_note text default null)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare o public.promo_orders%rowtype; v_note text := nullif(left(btrim(coalesce(p_note, '')), 300), '');
begin
  if auth.uid() is null then raise exception 'Prijava je obavezna'; end if;
  perform public.pzm_expire_stale_orders();
  select * into o from public.promo_orders where id = p_order_id for update;
  if not found or o.user_id <> auth.uid() then raise exception 'Porudžbina nije pronađena'; end if;
  if o.status <> 'awaiting_payment' then raise exception 'Porudžbina više ne čeka uplatu'; end if;
  update public.promo_orders set status = 'payment_submitted', submitted_at = now(), user_note = v_note where id = o.id;
  insert into public.promo_payment_events (order_id, event, from_status, to_status, actor_id, note)
  values (o.id, 'submitted', 'awaiting_payment', 'payment_submitted', auth.uid(), v_note);
end;
$$;
revoke all on function public.submit_promo_payment(uuid, text) from public, anon;
grant execute on function public.submit_promo_payment(uuid, text) to authenticated;

-- ---------- 12. Korisnik: otkazivanje (samo dok uplata nije prijavljena) ----------
create or replace function public.cancel_promo_order(p_order_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare o public.promo_orders%rowtype;
begin
  if auth.uid() is null then raise exception 'Prijava je obavezna'; end if;
  perform public.pzm_expire_stale_orders();
  select * into o from public.promo_orders where id = p_order_id for update;
  if not found or o.user_id <> auth.uid() then raise exception 'Porudžbina nije pronađena'; end if;
  if o.status <> 'awaiting_payment' then raise exception 'Porudžbina više ne može da se otkaže'; end if;
  update public.promo_orders set status = 'cancelled', cancelled_at = now() where id = o.id;
  insert into public.promo_payment_events (order_id, event, from_status, to_status, actor_id, note)
  values (o.id, 'cancelled', 'awaiting_payment', 'cancelled', auth.uid(), 'Korisnik je otkazao porudžbinu');
end;
$$;
revoke all on function public.cancel_promo_order(uuid) from public, anon;
grant execute on function public.cancel_promo_order(uuid) to authenticated;

-- ---------- 13. Admin: potvrda uplate (jedina putanja koja aktivira promociju) ----------
create or replace function public.admin_confirm_promo_payment(p_order_id uuid, p_note text default null)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  o public.promo_orders%rowtype; l public.listings%rowtype;
  v_start timestamptz; v_end timestamptz; v_touch boolean := true;
  v_note text := nullif(left(btrim(coalesce(p_note, '')), 500), '');
begin
  if not public.is_admin() then raise exception 'Permission denied'; end if;
  perform public.pzm_expire_stale_orders();

  select * into o from public.promo_orders where id = p_order_id for update;      -- zaključava porudžbinu: nema dvostruke obrade
  if not found then raise exception 'Porudžbina nije pronađena'; end if;
  if o.status = 'paid' then raise exception 'Porudžbina je već potvrđena'; end if;
  if o.status not in ('awaiting_payment','payment_submitted','expired') then
    raise exception 'Porudžbina je u statusu "%" i ne može da se potvrdi', o.status;
  end if;
  if o.listing_id is null then raise exception 'Oglas više ne postoji — promocija se ne može aktivirati'; end if;

  select * into l from public.listings where id = o.listing_id for update;
  if not found or l.status <> 'active' then raise exception 'Oglas nije aktivan — promocija se ne može aktivirati'; end if;

  if l.is_featured and l.featured_until is null then
    -- oglas je već trajno izdvojen (ručno, od strane admina): oglas se ne dira, porudžbina se samo evidentira
    v_start := now(); v_end := now() + make_interval(days => o.duration_days); v_touch := false;
  else
    -- ako je oglas već izdvojen, nova promocija počinje po isteku postojeće (plaćeni dani se ne gube)
    v_start := case when l.is_featured and l.featured_until > now() then l.featured_until else now() end;
    v_end   := v_start + make_interval(days => o.duration_days);
  end if;

  if v_touch then
    perform set_config('pazarime.trusted_counter_update', 'on', true);
    update public.listings set is_featured = true, featured_until = v_end where id = l.id;
    perform set_config('pazarime.trusted_counter_update', 'off', true);
  end if;

  update public.promo_orders
     set status = 'paid', confirmed_by = auth.uid(), confirmed_at = now(),
         promo_starts_at = v_start, promo_ends_at = v_end, admin_note = v_note
   where id = o.id;

  insert into public.promo_payment_events (order_id, event, from_status, to_status, actor_id, note)
  values (o.id, 'confirmed', o.status, 'paid', auth.uid(),
          coalesce(v_note, '') || case when v_touch then '' else ' (oglas je već trajno izdvojen)' end);
  perform public.log_admin_action('confirm_promo_payment', 'promo_order', o.id::text, 'Potvrđena uplata ' || o.reference);

  return jsonb_build_object('id', o.id, 'reference', o.reference, 'starts_at', v_start, 'ends_at', v_end);
end;
$$;
revoke all on function public.admin_confirm_promo_payment(uuid, text) from public, anon;
grant execute on function public.admin_confirm_promo_payment(uuid, text) to authenticated;

-- ---------- 14. Admin: odbijanje uz obavezan razlog ----------
create or replace function public.admin_reject_promo_payment(p_order_id uuid, p_reason text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare o public.promo_orders%rowtype; v_reason text := btrim(coalesce(p_reason, ''));
begin
  if not public.is_admin() then raise exception 'Permission denied'; end if;
  if char_length(v_reason) not between 3 and 500 then raise exception 'Unesi razlog odbijanja (3–500 karaktera)'; end if;
  perform public.pzm_expire_stale_orders();
  select * into o from public.promo_orders where id = p_order_id for update;
  if not found then raise exception 'Porudžbina nije pronađena'; end if;
  if o.status = 'paid' then raise exception 'Porudžbina je već potvrđena i ne može da se odbije'; end if;
  if o.status not in ('awaiting_payment','payment_submitted','expired') then
    raise exception 'Porudžbina je u statusu "%" i ne može da se odbije', o.status;
  end if;
  update public.promo_orders
     set status = 'rejected', rejected_at = now(), rejected_by = auth.uid(), reject_reason = v_reason
   where id = o.id;
  insert into public.promo_payment_events (order_id, event, from_status, to_status, actor_id, note)
  values (o.id, 'rejected', o.status, 'rejected', auth.uid(), v_reason);
  perform public.log_admin_action('reject_promo_payment', 'promo_order', o.id::text, 'Odbijena uplata ' || o.reference);
end;
$$;
revoke all on function public.admin_reject_promo_payment(uuid, text) from public, anon;
grant execute on function public.admin_reject_promo_payment(uuid, text) to authenticated;

-- ---------- 15. Admin: paketi ----------
create or replace function public.admin_upsert_promo_package(p_id uuid, p_data jsonb)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_name text := btrim(coalesce(p_data ->> 'name', ''));
  v_desc text := nullif(btrim(coalesce(p_data ->> 'description', '')), '');
  v_price numeric; v_days numeric; v_active boolean := coalesce((p_data ->> 'is_active')::boolean, true);
  v_id uuid := p_id;
begin
  if not public.is_admin() then raise exception 'Permission denied'; end if;
  if char_length(v_name) not between 1 and 80 then raise exception 'Naziv paketa je obavezan (do 80 karaktera)'; end if;
  if v_desc is not null and char_length(v_desc) > 500 then raise exception 'Opis je predugačak (do 500 karaktera)'; end if;
  begin v_price := (p_data ->> 'price_rsd')::numeric; exception when others then raise exception 'Cena mora biti broj'; end;
  begin v_days  := (p_data ->> 'duration_days')::numeric; exception when others then raise exception 'Trajanje mora biti broj dana'; end;
  if v_price is null or v_price <= 0 or v_price > 10000000 then raise exception 'Cena mora biti veća od 0 RSD'; end if;
  if v_days is null or v_days <> trunc(v_days) or v_days < 1 or v_days > 365 then raise exception 'Trajanje mora biti ceo broj dana od 1 do 365'; end if;

  if v_id is null then
    insert into public.promo_packages (name, description, price_rsd, duration_days, is_active, sort_order)
    values (v_name, v_desc, round(v_price, 2), v_days::int, v_active,
            coalesce((select max(sort_order) from public.promo_packages), 0) + 10)
    returning id into v_id;
    perform public.log_admin_action('create_promo_package', 'promo_package', v_id::text, 'Novi paket promocije: ' || v_name);
  else
    update public.promo_packages
       set name = v_name, description = v_desc, price_rsd = round(v_price, 2), duration_days = v_days::int, is_active = v_active
     where id = v_id;
    if not found then raise exception 'Paket nije pronađen'; end if;
    perform public.log_admin_action('update_promo_package', 'promo_package', v_id::text, 'Izmenjen paket promocije: ' || v_name);
  end if;
  return v_id;
end;
$$;
revoke all on function public.admin_upsert_promo_package(uuid, jsonb) from public, anon;
grant execute on function public.admin_upsert_promo_package(uuid, jsonb) to authenticated;

create or replace function public.admin_set_promo_package_active(p_id uuid, p_active boolean)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_admin() then raise exception 'Permission denied'; end if;
  update public.promo_packages set is_active = coalesce(p_active, false) where id = p_id;
  if not found then raise exception 'Paket nije pronađen'; end if;
  perform public.log_admin_action('set_promo_package_active', 'promo_package', p_id::text, case when p_active then 'Paket uključen' else 'Paket isključen' end);
end;
$$;
revoke all on function public.admin_set_promo_package_active(uuid, boolean) from public, anon;
grant execute on function public.admin_set_promo_package_active(uuid, boolean) to authenticated;

create or replace function public.admin_reorder_promo_packages(p_ids uuid[])
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_admin() then raise exception 'Permission denied'; end if;
  if p_ids is null or cardinality(p_ids) = 0 then return; end if;
  if (select count(distinct x) from unnest(p_ids) x) <> cardinality(p_ids) then raise exception 'Neispravan redosled'; end if;
  update public.promo_packages pk set sort_order = t.ord::int * 10
    from unnest(p_ids) with ordinality as t(id, ord) where pk.id = t.id;
  perform public.log_admin_action('reorder_promo_packages', 'promo_package', p_ids[1]::text, 'Promenjen redosled paketa');
end;
$$;
revoke all on function public.admin_reorder_promo_packages(uuid[]) from public, anon;
grant execute on function public.admin_reorder_promo_packages(uuid[]) to authenticated;

-- ---------- 16. Admin: podešavanja uplate ----------
create or replace function public.admin_get_payment_settings()
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare s public.promo_payment_settings%rowtype;
begin
  if not public.is_admin() then raise exception 'Permission denied'; end if;
  select * into s from public.promo_payment_settings where id;
  return to_jsonb(s) || jsonb_build_object('configured',
           coalesce(btrim(s.recipient_name), '') <> '' and coalesce(btrim(s.account_number), '') <> '' and coalesce(btrim(s.purpose_template), '') <> '');
end;
$$;
revoke all on function public.admin_get_payment_settings() from public, anon;
grant execute on function public.admin_get_payment_settings() to authenticated;

create or replace function public.admin_save_payment_settings(p_data jsonb)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_recipient text := nullif(btrim(coalesce(p_data ->> 'recipient_name', '')), '');
  v_account   text := nullif(btrim(coalesce(p_data ->> 'account_number', '')), '');
  v_bank      text := nullif(btrim(coalesce(p_data ->> 'bank_name', '')), '');
  v_instr     text := nullif(btrim(coalesce(p_data ->> 'instructions', '')), '');
  v_purpose   text := nullif(btrim(coalesce(p_data ->> 'purpose_template', '')), '');
  v_enabled   boolean := coalesce((p_data ->> 'enabled')::boolean, false);
  v_days      integer := coalesce(nullif(p_data ->> 'pending_expiry_days', '')::int, 7);
begin
  if not public.is_admin() then raise exception 'Permission denied'; end if;
  if v_recipient is not null and char_length(v_recipient) > 120 then raise exception 'Naziv primaoca je predugačak (do 120 karaktera)'; end if;
  if v_account is not null and v_account !~ '^[0-9A-Za-z][0-9A-Za-z \-]{3,38}$' then raise exception 'Broj računa sadrži nedozvoljene karaktere ili je neispravne dužine'; end if;
  if v_bank is not null and char_length(v_bank) > 120 then raise exception 'Naziv banke je predugačak (do 120 karaktera)'; end if;
  if v_instr is not null and char_length(v_instr) > 1000 then raise exception 'Uputstvo je predugačko (do 1000 karaktera)'; end if;
  if v_purpose is not null and char_length(v_purpose) > 140 then raise exception 'Svrha uplate je predugačka (do 140 karaktera)'; end if;
  if v_days not between 1 and 60 then raise exception 'Rok za uplatu mora biti od 1 do 60 dana'; end if;
  if v_enabled and (v_recipient is null or v_account is null or v_purpose is null) then
    raise exception 'Uplate ne mogu da se uključe dok se ne unesu primalac, broj računa i svrha uplate';
  end if;
  update public.promo_payment_settings
     set enabled = v_enabled, recipient_name = v_recipient, account_number = v_account, bank_name = v_bank,
         instructions = v_instr, purpose_template = v_purpose, pending_expiry_days = v_days,
         updated_by = auth.uid(), updated_at = now()
   where id;
  -- u evidenciju ide samo činjenica izmene, bez podataka o računu
  perform public.log_admin_action('update_payment_settings', 'payment_settings', '1',
    case when v_enabled then 'Podešavanja uplate izmenjena (uplate uključene)' else 'Podešavanja uplate izmenjena (uplate isključene)' end);
end;
$$;
revoke all on function public.admin_save_payment_settings(jsonb) from public, anon;
grant execute on function public.admin_save_payment_settings(jsonb) to authenticated;

-- ---------- 17. Istek promocije (poziva se pri učitavanju sajta; opciono i iz pg_cron) ----------
-- Idempotentno i jeftino; menja samo redove kojima je featured_until već prošao.
-- Oglasi izdvojeni ručno bez roka (featured_until IS NULL) se NE diraju.
create or replace function public.expire_promotions()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare n_list integer; n_ord integer;
begin
  n_ord := public.pzm_expire_stale_orders();
  perform set_config('pazarime.trusted_counter_update', 'on', true);
  update public.listings set is_featured = false, featured_until = null
   where is_featured and featured_until is not null and featured_until <= now();
  get diagnostics n_list = row_count;
  perform set_config('pazarime.trusted_counter_update', 'off', true);
  return jsonb_build_object('listings_unfeatured', n_list, 'orders_expired', n_ord);
end;
$$;
revoke all on function public.expire_promotions() from public;
grant execute on function public.expire_promotions() to anon, authenticated;
