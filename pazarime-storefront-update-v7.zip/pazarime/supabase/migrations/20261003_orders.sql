-- ============================================================================
-- PazariMe — ORDERS for store products (no online payment yet)
-- Idempotent. Builds on the stores migration (stores / listings.store_id / stock).
--
-- Reuses : public.is_admin(), public.set_updated_at(), listings.stock/available,
--          the project's trust convention  current_user in ('anon','authenticated').
-- Design :
--   * orders / order_items are written ONLY by the SECURITY DEFINER RPC place_order().
--     Clients have no INSERT/DELETE privilege and no INSERT policy.
--   * place_order() takes NO price from the client: price + product name are read from
--     the database and stored as SNAPSHOTS on order_items. Later product edits/deletes
--     never change old orders (order_items.product_id is ON DELETE SET NULL).
--   * Customer PII is visible only to: the buyer, the seller (orders.seller_id) and admins.
--   * Sellers can change ONLY orders.status (column-level privilege + trigger).
-- ============================================================================

-- ---------- 1. tables
create table if not exists public.orders (
  id                uuid primary key default gen_random_uuid(),
  order_number      bigint generated always as identity unique,
  store_id          uuid references public.stores(id)   on delete set null,
  seller_id         uuid references public.profiles(id) on delete set null,
  buyer_id          uuid references public.profiles(id) on delete set null,
  store_name        text not null,                       -- snapshot
  store_slug        text,                                -- snapshot (for links)
  buyer_name        text not null check (char_length(buyer_name)    between 1 and 60),
  buyer_surname     text not null check (char_length(buyer_surname) between 1 and 60),
  buyer_email       text not null check (char_length(buyer_email) <= 120 and buyer_email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  buyer_phone       text not null check (char_length(buyer_phone) between 6 and 30),
  buyer_address     text not null check (char_length(buyer_address) between 3 and 200),
  buyer_city        text not null check (char_length(buyer_city) between 2 and 80),
  buyer_postal_code text not null check (char_length(buyer_postal_code) between 3 and 12),
  buyer_note        text check (buyer_note is null or char_length(buyer_note) <= 500),
  total             numeric(12,2) not null check (total >= 0),
  status            text not null default 'nova'
                    check (status in ('nova','potvrdjena','u_pripremi','poslata','zavrsena','otkazana')),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);
create index if not exists orders_seller_created_idx on public.orders (seller_id, created_at desc);
create index if not exists orders_buyer_created_idx  on public.orders (buyer_id,  created_at desc);
create index if not exists orders_store_idx          on public.orders (store_id);
create index if not exists orders_email_created_idx  on public.orders (lower(buyer_email), created_at desc);

create table if not exists public.order_items (
  id            uuid primary key default gen_random_uuid(),
  order_id      uuid not null references public.orders(id) on delete cascade,
  product_id    uuid references public.listings(id) on delete set null,
  product_name  text not null,                           -- snapshot
  product_price numeric(12,2) not null check (product_price >= 0),   -- snapshot
  product_image text,                                    -- snapshot (first photo)
  quantity      integer not null check (quantity between 1 and 99),
  subtotal      numeric(12,2) not null check (subtotal >= 0),
  created_at    timestamptz not null default now()
);
create index if not exists order_items_order_idx   on public.order_items (order_id);
create index if not exists order_items_product_idx on public.order_items (product_id) where product_id is not null;

-- ---------- 2. privileges (the project's default privileges are wide open -> lock these down)
revoke all on public.orders, public.order_items from anon, authenticated;
grant select on public.orders, public.order_items to authenticated;
grant update (status) on public.orders to authenticated;       -- sellers/admins can ONLY touch status

-- ---------- 3. triggers
drop trigger if exists orders_updated_at_trg on public.orders;
create trigger orders_updated_at_trg before update on public.orders
  for each row execute function public.set_updated_at();

-- 3a. status rules for client updates (admins/definer functions are trusted)
create or replace function public.pzm_orders_guard()
returns trigger
language plpgsql
set search_path = public
as $$
declare v_client boolean := current_user in ('anon','authenticated') and not public.is_admin();
begin
  if v_client then
    if new.status is distinct from old.status and old.status in ('zavrsena','otkazana') then
      raise exception 'Porudžbina je zaključena i status se više ne može menjati';
    end if;
    -- defence in depth (column privilege already limits this to status)
    new.id := old.id; new.order_number := old.order_number; new.store_id := old.store_id;
    new.seller_id := old.seller_id; new.buyer_id := old.buyer_id; new.total := old.total;
    new.buyer_name := old.buyer_name; new.buyer_surname := old.buyer_surname; new.buyer_email := old.buyer_email;
    new.buyer_phone := old.buyer_phone; new.buyer_address := old.buyer_address; new.buyer_city := old.buyer_city;
    new.buyer_postal_code := old.buyer_postal_code; new.buyer_note := old.buyer_note;
    new.store_name := old.store_name; new.store_slug := old.store_slug; new.created_at := old.created_at;
  end if;
  return new;
end;
$$;
drop trigger if exists pzm_orders_guard_trg on public.orders;
create trigger pzm_orders_guard_trg before update on public.orders
  for each row execute function public.pzm_orders_guard();

-- 3b. cancelling returns the reserved stock; re-opening a cancelled order (admin only) reserves it again
create or replace function public.pzm_orders_stock_sync()
returns trigger
language plpgsql security definer
set search_path = public
as $$
begin
  if new.status = 'otkazana' and old.status <> 'otkazana' then
    update public.listings l set stock = l.stock + i.quantity
      from public.order_items i
     where i.order_id = new.id and i.product_id = l.id and l.stock is not null;
  elsif old.status = 'otkazana' and new.status <> 'otkazana' then
    update public.listings l set stock = greatest(l.stock - i.quantity, 0)
      from public.order_items i
     where i.order_id = new.id and i.product_id = l.id and l.stock is not null;
  end if;
  return null;
end;
$$;
revoke all on function public.pzm_orders_stock_sync() from public, anon, authenticated;
drop trigger if exists pzm_orders_stock_sync_trg on public.orders;
create trigger pzm_orders_stock_sync_trg after update of status on public.orders
  for each row execute function public.pzm_orders_stock_sync();

-- 3c. a seller can't delete a store while customers still wait for their orders
create or replace function public.pzm_stores_delete_guard()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  if current_user in ('anon','authenticated') and not public.is_admin() then
    if exists (select 1 from public.orders o
                where o.store_id = old.id and o.status in ('nova','potvrdjena','u_pripremi','poslata')) then
      raise exception 'Ne možeš obrisati prodavnicu dok imaš nezavršene porudžbine';
    end if;
  end if;
  return old;
end;
$$;
drop trigger if exists pzm_stores_delete_guard_trg on public.stores;
create trigger pzm_stores_delete_guard_trg before delete on public.stores
  for each row execute function public.pzm_stores_delete_guard();

-- ---------- 4. RLS
alter table public.orders      enable row level security;
alter table public.order_items enable row level security;

drop policy if exists orders_select on public.orders;
create policy orders_select on public.orders for select to authenticated
  using (buyer_id = auth.uid() or seller_id = auth.uid() or public.is_admin());

drop policy if exists orders_update on public.orders;
create policy orders_update on public.orders for update to authenticated
  using      (seller_id = auth.uid() or public.is_admin())
  with check (seller_id = auth.uid() or public.is_admin());

-- items inherit visibility from their order (the sub-select is itself filtered by orders RLS)
drop policy if exists order_items_select on public.order_items;
create policy order_items_select on public.order_items for select to authenticated
  using (exists (select 1 from public.orders o where o.id = order_id));
-- no INSERT / DELETE policies on either table: only place_order() writes.

-- ---------- 5. place_order RPC
create or replace function public.place_order(
  p_product_id  uuid,
  p_quantity    integer,
  p_name        text,
  p_surname     text,
  p_email       text,
  p_phone       text,
  p_address     text,
  p_city        text,
  p_postal_code text,
  p_note        text default null
) returns jsonb
language plpgsql security definer
set search_path = public
as $$
declare
  l        public.listings%rowtype;
  s        public.stores%rowtype;
  v_buyer  uuid := auth.uid();
  v_name   text := btrim(coalesce(p_name,''));
  v_surn   text := btrim(coalesce(p_surname,''));
  v_email  text := lower(btrim(coalesce(p_email,'')));
  v_phone  text := btrim(coalesce(p_phone,''));
  v_addr   text := btrim(coalesce(p_address,''));
  v_city   text := btrim(coalesce(p_city,''));
  v_zip    text := btrim(coalesce(p_postal_code,''));
  v_note   text := nullif(btrim(coalesce(p_note,'')), '');
  v_total  numeric(12,2);
  v_oid    uuid;
  v_num    bigint;
begin
  if p_quantity is null or p_quantity < 1 or p_quantity > 99 then raise exception 'Neispravna količina'; end if;
  if char_length(v_name)  not between 1 and 60  then raise exception 'Unesi ime'; end if;
  if char_length(v_surn)  not between 1 and 60  then raise exception 'Unesi prezime'; end if;
  if char_length(v_email) > 120 or v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'Email adresa nije ispravna'; end if;
  if char_length(v_phone) not between 6 and 30  then raise exception 'Broj telefona nije ispravan'; end if;
  if char_length(v_addr)  not between 3 and 200 then raise exception 'Unesi adresu'; end if;
  if char_length(v_city)  not between 2 and 80  then raise exception 'Unesi grad'; end if;
  if char_length(v_zip)   not between 3 and 12  then raise exception 'Unesi poštanski broj'; end if;
  if v_note is not null and char_length(v_note) > 500 then raise exception 'Napomena je predugačka (maks 500 karaktera)'; end if;

  -- lock the product row so concurrent buyers can't oversell the stock
  select * into l from public.listings where id = p_product_id for update;
  if not found or l.store_id is null then raise exception 'Proizvod nije dostupan za kupovinu'; end if;
  if l.status <> 'active' or l.available is false then raise exception 'Proizvod trenutno nije dostupan'; end if;

  select * into s from public.stores where id = l.store_id;
  if not found or s.status <> 'active' then raise exception 'Prodavnica trenutno ne prima porudžbine'; end if;
  if v_buyer is not null and v_buyer = s.owner_id then raise exception 'Ne možeš da kupiš sopstveni proizvod'; end if;

  -- anti-spam: max 5 orders / hour per e-mail, and per logged-in user
  if (select count(*) from public.orders o
       where o.created_at > now() - interval '1 hour'
         and (lower(o.buyer_email) = v_email or (v_buyer is not null and o.buyer_id = v_buyer))) >= 5 then
    raise exception 'Previše porudžbina u kratkom roku. Pokušaj ponovo kasnije.';
  end if;

  if l.stock is not null then
    if l.stock < p_quantity then
      raise exception 'Nema dovoljno proizvoda na stanju (dostupno: %)', l.stock;
    end if;
    update public.listings set stock = stock - p_quantity where id = l.id;
  end if;

  v_total := round(l.price * p_quantity, 2);

  insert into public.orders (store_id, seller_id, buyer_id, store_name, store_slug,
                             buyer_name, buyer_surname, buyer_email, buyer_phone,
                             buyer_address, buyer_city, buyer_postal_code, buyer_note, total)
  values (s.id, s.owner_id, v_buyer, s.name, s.slug,
          v_name, v_surn, v_email, v_phone, v_addr, v_city, v_zip, v_note, v_total)
  returning id, order_number into v_oid, v_num;

  insert into public.order_items (order_id, product_id, product_name, product_price, product_image, quantity, subtotal)
  values (v_oid, l.id, l.title, l.price, l.images->>0, p_quantity, v_total);

  return jsonb_build_object('id', v_oid, 'order_number', v_num, 'total', v_total);
end;
$$;
revoke all on function public.place_order(uuid,integer,text,text,text,text,text,text,text,text) from public;
grant execute on function public.place_order(uuid,integer,text,text,text,text,text,text,text,text) to anon, authenticated;
