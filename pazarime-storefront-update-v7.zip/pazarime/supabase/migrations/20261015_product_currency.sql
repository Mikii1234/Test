-- PazariMe: per-product currency (RSD / EUR). ADDITIVE and idempotent. No data is deleted or rewritten.
-- Every existing price in the app was EUR (the UI hardcoded "€"), so existing rows default to 'EUR' and display exactly as before.
-- REFERENCE RATE: 117.5 RSD = 1 EUR (NBS mid-rate was ~117.4 in Oct 2026). It is used ONLY by price_eur, for cross-currency
-- sorting/filtering. It never changes a seller's stored price. Must match EUR_RSD_REF in app.js. To change it later, drop and re-add price_eur.

alter table public.listings add column if not exists currency text not null default 'EUR';
do $$ begin
  alter table public.listings add constraint listings_currency_chk check (currency in ('RSD','EUR'));
exception when duplicate_object then null; end $$;

alter table public.listings add column if not exists price_eur numeric
  generated always as (case when currency = 'RSD' then round(price / 117.5, 2) else price end) stored;
create index if not exists listings_price_eur_idx on public.listings (price_eur);

-- Orders keep a currency SNAPSHOT next to their price snapshot, so later edits to a product never change history.
alter table public.orders      add column if not exists currency text not null default 'EUR';
alter table public.order_items add column if not exists currency text not null default 'EUR';
do $$ begin
  alter table public.orders add constraint orders_currency_chk check (currency in ('RSD','EUR'));
exception when duplicate_object then null; end $$;
do $$ begin
  alter table public.order_items add constraint order_items_currency_chk check (currency in ('RSD','EUR'));
exception when duplicate_object then null; end $$;

-- place_order(): identical to 20261003_orders.sql except it also snapshots the product's currency.
create or replace function public.place_order(
  p_product_id  uuid,
  p_quantity    integer,
  p_name        text,
  p_surname     text,
  p_email       text,
  p_phone       text,
  p_address     text,
  p_city        text,
  p_postal_code text,
  p_note        text default null
) returns jsonb
language plpgsql security definer
set search_path = public
as $$
declare
  l        public.listings%rowtype;
  s        public.stores%rowtype;
  v_buyer  uuid := auth.uid();
  v_name   text := btrim(coalesce(p_name,''));
  v_surn   text := btrim(coalesce(p_surname,''));
  v_email  text := lower(btrim(coalesce(p_email,'')));
  v_phone  text := btrim(coalesce(p_phone,''));
  v_addr   text := btrim(coalesce(p_address,''));
  v_city   text := btrim(coalesce(p_city,''));
  v_zip    text := btrim(coalesce(p_postal_code,''));
  v_note   text := nullif(btrim(coalesce(p_note,'')), '');
  v_total  numeric(12,2);
  v_oid    uuid;
  v_num    bigint;
begin
  if p_quantity is null or p_quantity < 1 or p_quantity > 99 then raise exception 'Neispravna količina'; end if;
  if char_length(v_name)  not between 1 and 60  then raise exception 'Unesi ime'; end if;
  if char_length(v_surn)  not between 1 and 60  then raise exception 'Unesi prezime'; end if;
  if char_length(v_email) > 120 or v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'Email adresa nije ispravna'; end if;
  if char_length(v_phone) not between 6 and 30  then raise exception 'Broj telefona nije ispravan'; end if;
  if char_length(v_addr)  not between 3 and 200 then raise exception 'Unesi adresu'; end if;
  if char_length(v_city)  not between 2 and 80  then raise exception 'Unesi grad'; end if;
  if char_length(v_zip)   not between 3 and 12  then raise exception 'Unesi poštanski broj'; end if;
  if v_note is not null and char_length(v_note) > 500 then raise exception 'Napomena je predugačka (maks 500 karaktera)'; end if;

  -- lock the product row so concurrent buyers can't oversell the stock
  select * into l from public.listings where id = p_product_id for update;
  if not found or l.store_id is null then raise exception 'Proizvod nije dostupan za kupovinu'; end if;
  if l.status <> 'active' or l.available is false then raise exception 'Proizvod trenutno nije dostupan'; end if;

  select * into s from public.stores where id = l.store_id;
  if not found or s.status <> 'active' then raise exception 'Prodavnica trenutno ne prima porudžbine'; end if;
  if v_buyer is not null and v_buyer = s.owner_id then raise exception 'Ne možeš da kupiš sopstveni proizvod'; end if;

  -- anti-spam: max 5 orders / hour per e-mail, and per logged-in user
  if (select count(*) from public.orders o
       where o.created_at > now() - interval '1 hour'
         and (lower(o.buyer_email) = v_email or (v_buyer is not null and o.buyer_id = v_buyer))) >= 5 then
    raise exception 'Previše porudžbina u kratkom roku. Pokušaj ponovo kasnije.';
  end if;

  if l.stock is not null then
    if l.stock < p_quantity then
      raise exception 'Nema dovoljno proizvoda na stanju (dostupno: %)', l.stock;
    end if;
    update public.listings set stock = stock - p_quantity where id = l.id;
  end if;

  v_total := round(l.price * p_quantity, 2);

  insert into public.orders (store_id, seller_id, buyer_id, store_name, store_slug,
                             buyer_name, buyer_surname, buyer_email, buyer_phone,
                             buyer_address, buyer_city, buyer_postal_code, buyer_note, total, currency)
  values (s.id, s.owner_id, v_buyer, s.name, s.slug,
          v_name, v_surn, v_email, v_phone, v_addr, v_city, v_zip, v_note, v_total, l.currency)
  returning id, order_number into v_oid, v_num;

  insert into public.order_items (order_id, product_id, product_name, product_price, product_image, quantity, subtotal, currency)
  values (v_oid, l.id, l.title, l.price, l.images->>0, p_quantity, v_total, l.currency);

  return jsonb_build_object('id', v_oid, 'order_number', v_num, 'total', v_total, 'currency', l.currency);
end;
$$;
revoke all on function public.place_order(uuid,integer,text,text,text,text,text,text,text,text) from public;
grant execute on function public.place_order(uuid,integer,text,text,text,text,text,text,text,text) to anon, authenticated;
