-- PazariMe 20261019: PREMIUM listing priority in the database query (view columns only; NO table or data is changed).
-- Reuses what already exists live: promo_packages.is_premium, promo_orders.is_premium, listings.premium_until and the
-- admin_confirm_promo_payment() workflow (premium_until is written ONLY there, guarded by protect_listing_counters()).
-- Why this migration: public.listings_search was created before listings.premium_until existed, so the database could not
-- sort Premium first. Views cannot gain a column in the middle, so view + its dependent function are recreated atomically.
--   promo_rank: 2 = active PREMIUM (premium_until in the future), 1 = active standard featured, 0 = ordinary.
--   Evaluated with now() at query time => expired promotions lose priority by themselves (no cron needed).

drop function if exists public.search_listings_by_specs(jsonb);
drop view if exists public.listings_search;

create or replace function public.pzm_is_premium_now(p_until timestamptz)
returns boolean
language sql stable parallel safe
set search_path = public, pg_temp
as $$ select p_until is not null and p_until > now() $$;

create view public.listings_search with (security_invoker = true) as
select l.*,
       public.pzm_is_featured_now(l.is_featured, l.featured_until) as featured_active,
       public.pzm_is_premium_now(l.premium_until)                  as premium_active,
       case when public.pzm_is_premium_now(l.premium_until) then 2
            when public.pzm_is_featured_now(l.is_featured, l.featured_until) then 1
            else 0 end                                             as promo_rank
from public.listings l;

revoke all on public.listings_search from public, anon, authenticated;
grant select on public.listings_search to anon, authenticated;

create or replace function public.search_listings_by_specs(p_filters jsonb)
returns setof public.listings_search
language sql stable security invoker
set search_path = public, pg_temp
as $$
  select ls.*
  from public.listings_search ls
  where not exists (
    select 1
    from jsonb_array_elements(case when jsonb_typeof(p_filters) = 'array' then p_filters else '[]'::jsonb end) f
    where exists (select 1 from public.category_specifications s0
                  where s0.id::text = f->>'id' and s0.is_active and s0.is_filterable)
      and (coalesce(nullif(f->>'min',''), nullif(f->>'max',''), nullif(f->>'text',''), f->>'bool') is not null
           or jsonb_array_length(coalesce(f->'values', '[]'::jsonb)) > 0)
      and not exists (
        select 1
        from public.listing_specification_values v
        join public.category_specifications s on s.id = v.specification_id
        where v.listing_id = ls.id
          and v.specification_id::text = f->>'id'
          and case s.field_type
                when 'number'      then v.value_number is not null
                                        and (nullif(f->>'min','') is null or v.value_number >= (f->>'min')::numeric)
                                        and (nullif(f->>'max','') is null or v.value_number <= (f->>'max')::numeric)
                when 'decimal'     then v.value_number is not null
                                        and (nullif(f->>'min','') is null or v.value_number >= (f->>'min')::numeric)
                                        and (nullif(f->>'max','') is null or v.value_number <= (f->>'max')::numeric)
                when 'select'      then v.value_text = any (array(select jsonb_array_elements_text(coalesce(f->'values','[]'::jsonb))))
                when 'multiselect' then v.value_options && array(select jsonb_array_elements_text(coalesce(f->'values','[]'::jsonb)))
                when 'boolean'     then v.value_boolean is not null and v.value_boolean = (f->>'bool')::boolean
                when 'text'        then v.value_text is not null and position(lower(f->>'text') in lower(v.value_text)) > 0
                else false
              end
      )
  )
$$;

revoke all on function public.search_listings_by_specs(jsonb) from public;
grant execute on function public.search_listings_by_specs(jsonb) to anon, authenticated;

notify pgrst, 'reload schema';
