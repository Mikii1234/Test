-- PazariMe 20261021: seller status (fizičko lice / trgovac) + buyer-protection notice support.
--
-- ADDITIVE and backward-compatible. Nothing is dropped, reset or retyped and no data is modified.
-- Re-uses what already exists LIVE in PazariMe-v2 (these objects are NOT created here):
--   * profiles.trader_status (enum trader_status_type: undeclared | trader | non_trader), declaration_timestamp,
--     declaration_version and the business_* columns
--   * trigger protect_profile_admin_fields (clients cannot write the declaration columns directly)
--   * table trader_status_history (RLS: owner or admin)
--   * the insert gate on listings (policy "declared users insert own listings") and create_store_order()
--   * admin_list_users(), admin_get_trader_detail(), admin_get_trader_history()
--
-- What this migration does:
--   1. declare_trader_status(): SAME signature and return type, stricter server-side validation for traders
--      (registration number, PIB, e-mail, phone). Private sellers still store NO business data.
--   2. CHECK constraint: only a trader may carry business_* data (no stray business data on private sellers).
--      The live data already satisfies it (verified before applying).
--   3. get_seller_public_info(uuid[]): the ONLY thing the public notice on a listing needs. Business details are
--      returned for declared traders only, and only for people who actually have listings or a store.
--   4. get_my_seller_status(): the signed-in user's own declaration (account settings / pre-filled form).
--
-- Nothing here "verifies" any business data. All values are exactly what the seller declared.

-- 1) declaration RPC -------------------------------------------------------------------------------------------
create or replace function public.declare_trader_status(p_status text, p_business jsonb default null::jsonb)
returns public.profiles
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  result public.profiles;
  prev_status trader_status_type;
  v_name text; v_legal_form text; v_address text; v_regnum text; v_pib text; v_email text; v_phone text;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_status not in ('trader','non_trader') then raise exception 'Invalid trader status'; end if;

  select trader_status into prev_status from public.profiles where id = auth.uid();

  if p_status = 'trader' then
    v_name       := nullif(btrim(coalesce(p_business->>'business_name','')), '');
    v_legal_form := nullif(btrim(coalesce(p_business->>'business_legal_form','')), '');
    v_address    := nullif(btrim(coalesce(p_business->>'business_address','')), '');
    v_regnum     := nullif(regexp_replace(coalesce(p_business->>'business_registration_number',''), '\s', '', 'g'), '');
    v_pib        := nullif(regexp_replace(coalesce(p_business->>'business_pib',''), '\s', '', 'g'), '');
    v_email      := nullif(btrim(coalesce(p_business->>'business_email','')), '');
    v_phone      := nullif(btrim(coalesce(p_business->>'business_phone','')), '');

    if v_name is null or char_length(v_name) not between 2 and 120 then
      raise exception 'Izjava: poslovno ime je obavezno (2–120 karaktera).';
    end if;
    if v_legal_form is null or char_length(v_legal_form) > 80 then
      raise exception 'Izjava: pravna forma je obavezna.';
    end if;
    if v_address is null or char_length(v_address) not between 5 and 200 then
      raise exception 'Izjava: adresa sedišta je obavezna (5–200 karaktera).';
    end if;
    if v_regnum is null or v_regnum !~ '^[0-9]{8}$' then
      raise exception 'Izjava: matični broj mora imati 8 cifara.';
    end if;
    if v_pib is null or v_pib !~ '^[0-9]{9}$' then
      raise exception 'Izjava: PIB mora imati 9 cifara.';
    end if;
    if v_email is null or char_length(v_email) > 120 or v_email !~ '^[^\s@]+@[^\s@]+\.[^\s@]+$' then
      raise exception 'Izjava: unesi ispravnu e-adresu.';
    end if;
    if v_phone is null or v_phone !~ '^\+?[0-9][0-9 ()./-]{5,29}$' then
      raise exception 'Izjava: unesi ispravan broj telefona.';
    end if;
  else
    -- a private seller stores NO business data (and re-declaring as private clears any earlier business data)
    v_name:=null; v_legal_form:=null; v_address:=null; v_regnum:=null; v_pib:=null; v_email:=null; v_phone:=null;
  end if;

  perform set_config('pazarime.trusted_admin_update','on', true);
  update public.profiles set
    trader_status = p_status::trader_status_type,
    declaration_timestamp = now(),
    declaration_version = 1,
    business_name = v_name, business_legal_form = v_legal_form, business_address = v_address,
    business_registration_number = v_regnum, business_pib = v_pib, business_email = v_email, business_phone = v_phone
  where id = auth.uid()
  returning * into result;

  -- the record of every (re)declaration; readable only by the user and admins (RLS on the history table)
  insert into public.trader_status_history (user_id, previous_status, new_status, declaration_version, business_snapshot)
  values (auth.uid(), prev_status, p_status::trader_status_type, 1,
    case when p_status='trader' then jsonb_build_object(
      'business_name',v_name,'business_legal_form',v_legal_form,'business_address',v_address,
      'business_registration_number',v_regnum,'business_pib',v_pib,'business_email',v_email,'business_phone',v_phone
    ) else null end);

  return result;
end;
$function$;

-- 2) business data only for traders -----------------------------------------------------------------------------
do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'profiles_business_data_only_for_traders'
                   and conrelid = 'public.profiles'::regclass) then
    alter table public.profiles add constraint profiles_business_data_only_for_traders
      check (trader_status = 'trader'::trader_status_type
             or (business_name is null and business_legal_form is null and business_address is null
                 and business_registration_number is null and business_pib is null
                 and business_email is null and business_phone is null));
  end if;
end $$;

-- 3) public seller notice data ---------------------------------------------------------------------------------
create or replace function public.get_seller_public_info(p_user_ids uuid[])
returns table(user_id uuid, trader_status text, business_name text, business_legal_form text, business_address text,
              business_registration_number text, business_pib text, business_email text, business_phone text)
language sql
stable
security definer
set search_path to 'public', 'pg_temp'
as $$
  select p.id,
         p.trader_status::text,
         case when p.trader_status = 'trader' then p.business_name end,
         case when p.trader_status = 'trader' then p.business_legal_form end,
         case when p.trader_status = 'trader' then p.business_address end,
         case when p.trader_status = 'trader' then p.business_registration_number end,
         case when p.trader_status = 'trader' then p.business_pib end,
         case when p.trader_status = 'trader' then p.business_email end,
         case when p.trader_status = 'trader' then p.business_phone end
  from public.profiles p
  where p.id = any (p_user_ids[1:50])          -- hard cap per call
    and ( p.id = auth.uid()
          or public.is_admin()
          or exists (select 1 from public.listings l where l.seller_id = p.id)
          or exists (select 1 from public.stores s where s.owner_id = p.id) );
$$;

-- 4) the signed-in user's own declaration ----------------------------------------------------------------------
create or replace function public.get_my_seller_status()
returns table(trader_status text, declaration_timestamp timestamptz, declaration_version integer,
              business_name text, business_legal_form text, business_address text,
              business_registration_number text, business_pib text, business_email text, business_phone text)
language sql
stable
security definer
set search_path to 'public', 'pg_temp'
as $$
  select p.trader_status::text, p.declaration_timestamp, p.declaration_version,
         p.business_name, p.business_legal_form, p.business_address,
         p.business_registration_number, p.business_pib, p.business_email, p.business_phone
  from public.profiles p
  where p.id = auth.uid();
$$;

-- grants -------------------------------------------------------------------------------------------------------
revoke all on function public.get_seller_public_info(uuid[]) from public;
grant execute on function public.get_seller_public_info(uuid[]) to anon, authenticated;

revoke all on function public.get_my_seller_status() from public, anon;
grant execute on function public.get_my_seller_status() to authenticated;

notify pgrst, 'reload schema';
