-- Applied to PazariMe-v2 as migration "fix_admin_list_users_email_cast".
-- Pre-existing bug fix: auth.users.email is varchar(255) but the function declares `email text`,
-- so every call failed ("structure of query does not match function result type") and the
-- admin Users tab silently showed an empty list. Body unchanged except for u.email::text.
CREATE OR REPLACE FUNCTION public.admin_list_users(p_search text DEFAULT NULL::text)
 RETURNS TABLE(id uuid, email text, display_name text, avatar_url text, is_admin boolean, account_status text, created_at timestamp with time zone, listing_count bigint, favorite_count bigint, trader_status text, declaration_timestamp timestamp with time zone, business_name text)
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not is_admin() then raise exception 'Permission denied'; end if;
  return query
    select u.id, u.email::text, p.display_name, p.avatar_url, p.is_admin, p.account_status, u.created_at,
      (select count(*) from public.listings l where l.seller_id = u.id) as listing_count,
      (select count(*) from public.favorites f where f.user_id = u.id) as favorite_count,
      p.trader_status::text, p.declaration_timestamp, p.business_name
    from auth.users u
    join public.profiles p on p.id = u.id
    where p_search is null or p_search = '' or
      u.email ilike '%'||p_search||'%' or
      p.display_name ilike '%'||p_search||'%' or
      u.id::text = p_search
    order by u.created_at desc;
end;
$function$;
