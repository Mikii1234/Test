-- PazariMe OPTIONAL hardening (NOT applied by default): stop the PUBLIC API from reading profiles.business_* directly.
--
-- Why: profiles has a "publicly readable" SELECT policy and anon/authenticated hold table-level SELECT, so anyone
-- can run  /rest/v1/profiles?select=business_email,business_pib,...  for ALL traders in bulk. Trader details are meant
-- to be public on that trader's own listings (get_seller_public_info does exactly that, per seller), but bulk
-- harvesting through the table API is not necessary.
--
-- WHEN to run: only AFTER the frontend that contains this release (20261021) is deployed. That frontend reads business
-- data only through RPCs (get_seller_public_info / get_my_seller_status / admin_get_trader_detail) and no longer uses
-- select("*") on profiles. An older frontend still does select("*") for the admin dashboard user count, which would
-- start failing with "permission denied for table profiles".
--
-- Side effects to know about:
--   * Any NEW column added to public.profiles later is NOT readable through the API until you GRANT SELECT on it.
--   * select("*") on profiles (or an embedded profiles(*)) stops working for anon/authenticated.
-- Rollback:  grant select on public.profiles to anon, authenticated;

revoke select on public.profiles from anon, authenticated;
grant select (id, display_name, avatar_url, is_admin, created_at, account_status, last_seen,
              trader_status, declaration_timestamp, declaration_version)
  on public.profiles to anon, authenticated;
