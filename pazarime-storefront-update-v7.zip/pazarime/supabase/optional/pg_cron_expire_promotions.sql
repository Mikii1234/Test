-- OPCIONO — nije deo migracija i nije potrebno da bi sistem radio.
-- Istek promocija već radi bez cron-a (sajt poziva expire_promotions() pri učitavanju, a aplikacija
-- ionako ne prikazuje "Izdvojeno" kada je featured_until prošao). Ovaj raspored samo dodatno
-- čisti bazu čak i kada niko ne posećuje sajt.
--
-- 1) Supabase Dashboard -> Database -> Extensions -> uključi "pg_cron"
-- 2) U SQL Editoru pokreni:
select cron.schedule('pazarime-expire-promotions', '5 * * * *', $$select public.expire_promotions();$$);
-- Uklanjanje rasporeda:  select cron.unschedule('pazarime-expire-promotions');
