-- PazariMe: READ-ONLY checks. Safe to run any time in the Supabase SQL Editor (changes nothing).
-- Run BEFORE the fix to see what is missing, and AFTER to confirm. Every row in the result should say ok = true.
select 'table public.store_promotions exists' as check, to_regclass('public.store_promotions') is not null as ok
union all select 'view public.active_promotions exists', to_regclass('public.active_promotions') is not null
union all select 'column listings.currency (20261015)', exists(select 1 from information_schema.columns where table_schema='public' and table_name='listings' and column_name='currency')
union all select 'column listings.price_eur (20261015)', exists(select 1 from information_schema.columns where table_schema='public' and table_name='listings' and column_name='price_eur')
union all select 'column listings.is_store_featured (20261017)', exists(select 1 from information_schema.columns where table_schema='public' and table_name='listings' and column_name='is_store_featured')
union all select 'column stores.welcome_title (20261017)', exists(select 1 from information_schema.columns where table_schema='public' and table_name='stores' and column_name='welcome_title')
union all select 'columns order_items.list_price/discount_percent (20261016)', (select count(*) = 2 from information_schema.columns where table_schema='public' and table_name='order_items' and column_name in ('list_price','discount_percent'))
union all select 'RPC save_store_promotion', to_regprocedure('public.save_store_promotion(uuid,uuid,integer,timestamptz,timestamptz)') is not null
union all select 'RPC delete_store_promotion', to_regprocedure('public.delete_store_promotion(uuid)') is not null
union all select 'function pzm_active_percent', to_regprocedure('public.pzm_active_percent(uuid)') is not null
union all select 'RLS enabled on store_promotions', coalesce((select relrowsecurity from pg_class where oid = to_regclass('public.store_promotions')), false)
union all select 'view public.listings_search (20261018)', to_regclass('public.listings_search') is not null
union all select 'function search_listings_by_specs (20261018)', to_regprocedure('public.search_listings_by_specs(jsonb)') is not null
union all select 'function pzm_is_featured_now (20261018)', to_regprocedure('public.pzm_is_featured_now(boolean,timestamptz)') is not null
union all select 'place_order() uses promotions (20261016)', coalesce((select prosrc like '%pzm_active_percent%' from pg_proc where oid = to_regprocedure('public.place_order(uuid,integer,text,text,text,text,text,text,text,text)')), false);

-- Detail (only returns rows once the table exists): columns, constraints, policies, and who can write directly.
-- select column_name, data_type, is_nullable from information_schema.columns where table_schema='public' and table_name='store_promotions' order by ordinal_position;
-- select conname, pg_get_constraintdef(oid) from pg_constraint where conrelid = 'public.store_promotions'::regclass;
-- select policyname, cmd, roles, qual from pg_policies where schemaname='public' and tablename='store_promotions';
-- select grantee, privilege_type from information_schema.role_table_grants where table_schema='public' and table_name in ('store_promotions','active_promotions') and grantee in ('anon','authenticated') order by 1,2;
--   expected: store_promotions -> authenticated SELECT only;  active_promotions -> anon + authenticated SELECT only.
