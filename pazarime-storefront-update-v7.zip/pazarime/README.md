# PazariMe — deployment guide

## Why this needs real hosting

Claude's published-artifact sandbox blocks outbound `fetch()` calls to any
domain outside a short script/font allow-list. Supabase isn't on that list,
so every request the frontend makes (signup, login, listings, everything)
fails with `Failed to fetch` — not because of a code bug, but because the
browser refuses to make the request at all inside that sandbox.

This folder is the same, unmodified app as two plain files. Deployed to any
normal static host, there is no such restriction and it will talk to
Supabase directly, exactly as designed.

## Deploy in ~1 minute (pick one)

**Netlify (easiest):**
1. Go to https://app.netlify.com/drop
2. Drag this folder onto the page.
3. Done — you get a live URL immediately.

**Vercel:**
1. `npm i -g vercel` (if you don't have it)
2. `cd` into this folder, run `vercel --prod`

**GitHub Pages:**
1. Push `index.html` and `app.js` to a repo.
2. Repo Settings → Pages → deploy from the branch root.

**Your own server / any static host:**
Just upload `index.html` and `app.js` to the same directory — no build
step, no server-side code, no environment variables needed (the Supabase
URL and anon key are already in `app.js`, which is safe: it's the public
anon key, not the service-role key, and it's meant to be public — access
control happens via Row Level Security in Postgres, not by hiding the key).

## Before you test signup

Supabase projects require email confirmation by default. Either:
- Confirm the account via the email Supabase sends, then log in, **or**
- In Supabase Dashboard → Authentication → Providers → Email, turn off
  "Confirm email" for faster local testing.

## Testing checklist (do this after deploying)

1. Register a new account → should redirect into the app immediately
   (or prompt to check email, depending on the setting above) — **not**
   "Failed to fetch".
2. Open browser dev tools → Network tab while registering, confirm you see
   a request to `juzjzmaxyemwbvdmocdn.supabase.co/auth/v1/signup` returning
   `200`.
3. Post a listing with real photos (camera + gallery), confirm it appears
   in "Najnoviji oglasi" for a second account/browser.
4. Favorite a listing, refresh, confirm it's still favorited.
5. Rate a seller 👍, then try again as the same user — confirm it updates
   rather than duplicating.
6. Open a listing from a different browser/incognito window — view count
   should go up by exactly 1 per day per visitor, not per refresh.

## Admin access

`profiles.is_admin` defaults to `false` for everyone. After you've signed
up once, run this in the Supabase SQL editor to make yourself an admin:

```sql
update profiles set is_admin = true where id = '<your-user-id-from-auth-users>';
```

## Seller stores (multi-vendor shops)

**Database status:** the migrations in `supabase/migrations/` (`20261002_*`) are ALREADY APPLIED to
PazariMe-v2 (project `juzjzmaxyemwbvdmocdn`). They are idempotent; do not run them again unless
rebuilding a fresh project (then run `stores_v2` first).

- `20261002_stores_v2.sql` — `stores`, `store_categories`, `store_views`, new nullable columns on
  `listings`, RLS, guard triggers, RPCs (`record_store_view`, `store_product_counts`,
  `admin_set_store_status`), public `store-images` bucket + owner-only storage policies.
  Reuses the project's `is_admin()` and `log_admin_action()`.
- `20261002_fix_admin_list_users_email_cast.sql` — fixes a pre-existing bug (admin Users tab was empty).
- `20261002_stores_revoke_trigger_fn_execute.sql` — hardening.

**Legal gate:** the database only lets users who completed the trader declaration
(`profiles.trader_status <> 'undeclared'`) publish listings or open a store. The app now has a
declaration screen (`#/deklaracija`, calls the existing `declare_trader_status` RPC) and gates the
listing wizard / store creation on it.

Routes: `#/prodavnice`, `#/prodavnica/<slug>`, `#/prodavnica/<slug>/proizvod/<product-slug>`,
`#/moja-prodavnica[/proizvodi|kategorije|podesavanja]`, `#/deklaracija`, admin: `#/admin/stores`.

Store products are rows in `listings` with `store_id` set, so search, favorites, messages, reports
and admin moderation work for them unchanged.

## Orders ("Kupi" -> checkout -> Porudžbine)

**Database status:** `supabase/migrations/20261003_orders.sql` is ALREADY APPLIED to PazariMe-v2
(migration name `orders_system`). Idempotent.

- Tables `orders`, `order_items`. Orders are created ONLY by the `place_order()` RPC, which reads the
  price and product name from the database (the client never sends a price) and stores them as
  snapshots. Stock is reserved at order time and returned when an order is cancelled.
- RLS: an order is readable only by its buyer (`buyer_id`), its seller (`seller_id`) and admins.
  Anonymous users have no privileges on the order tables. Sellers/admins can update ONLY `status`
  (column-level privilege + trigger); a finished/cancelled order is locked for sellers.
- Guests can order (no account needed) but cannot look orders up later; logged-in buyers see theirs
  under `#/moje-porudzbine`.

Routes: `#/kupi/<product-id>`, `#/porudzbina-primljena`, `#/moje-porudzbine`,
`#/moja-prodavnica/porudzbine[/<status>]`, admin: `#/admin/orders[/<id>]`.

No online payment: the order is submitted to the seller, who arranges payment/delivery directly.

## Responsive / mobile layer
All responsive CSS lives in `index.html` (search for "RESPONSIVE LAYER" plus the in-place root-cause fixes
near `.section`, `.detail-grid`, `.gallery-thumbs`, `.search-bar`). Small JS helpers (drawer menu, search toggle,
keyboard handling, admin table labels) are at the end of `app.js` under "MOBILE UX". No data/business logic touched.
Breakpoints: 1100px (hamburger), 980px (tablet/stacking), 680px (phone: bottom nav, sheets, cards), 359px (very small).

## Responsive / mobile layer
All responsive CSS lives in `index.html` (search for "RESPONSIVE LAYER", plus the in-place root-cause fixes near
`.section`, `.detail-grid`, `.gallery-thumbs`, `.search-bar`). Small UI-only JS helpers (drawer menu, search toggle,
keyboard handling, admin table labels) are at the end of `app.js` under "MOBILE UX". No data/business logic touched.
Breakpoints: 1100px (hamburger menu), 980px (tablet / stacking), 680px (phone: bottom nav, sheets, cards), 359px (very small).

## Images: lightbox, logo/banner removal, photo management
No database change. Authorization relies on the existing RLS + storage policies (owner-folder only).
- **Lightbox** (`openLightbox`, end of `app.js`): click/tap the listing photo -> overlay on the same page; prev/next, swipe,
  Esc, X, tap outside, browser/Android Back to close; images use `object-fit:contain` (never distorted).
- **Store logo / banner**: `Moja prodavnica -> Podešavanja -> Izgled prodavnice` has "Promeni/Ukloni logo" and "Promeni/Ukloni baner".
  Removal = `UPDATE stores SET logo_url|cover_url = NULL WHERE id=? AND owner_id=me`, then the file is deleted from `store-images`.
- **Listing photos**: the normal "Uredi oglas" form now manages photos (add / replace / "Ukloni sliku" / reorder / cover),
  sharing one component with the store-product form and the wizard.
- **Storage cleanup** only deletes files inside the *current user's own* folder, only after the DB no longer references them,
  never external URLs, and never a file still used by another of the user's listings.

## Listing types + dynamic category specifications
The live project (juzjzmaxyemwbvdmocdn, PazariMe-v2) ALREADY contains the listing-type and specification schema
(migrations 20261009210205 and 20261010060305). The app uses that design:
- `listings.listing_type`; `category_specifications` (global rows: `label`, `key`, `field_type`, `options` as `[{value,label}]`,
  `unit`, `help_text`, `min_value/max_value`, `is_required`, `is_active`, `is_filterable`, `sort_order`, `category_ids[]`,
  `listing_types[]` — an empty array means "all"); `listing_specification_values`.
- Writes go only through SECURITY DEFINER RPCs: `admin_upsert_specification`, `admin_delete_specification`,
  `admin_set_specification_active`, `admin_reorder_specifications`, `set_listing_specifications`.
- Only missing piece: `supabase/migrations/20261010_admin_delete_category.sql` (run once in the SQL Editor). Until then,
  deleting a category shows the database error and nothing is deleted.
- Admin: **Kategorije** (create / edit / enable-disable / delete) and **Specifikacije** (pick a category; add / edit / delete /
  reorder / enable / require; a spec can apply to one, several or all categories and to chosen listing types).
- Posting/editing: category -> type -> that category's specs for that type; the public page shows them in "Karakteristike".
  "Prodajem"/"Kupujem" are never a badge on cards/pages; services show "Nudim uslugu" / "Tražim uslugu".

## Legal pages (Uslovi korišćenja / Politika privatnosti / Pravila oglašavanja)
`#/uslovi`, `#/privatnost`, `#/pravila-oglasavanja` are public (no login) and linked from the footer. Their text lives in `LEGAL_DOCS`
in `app.js`. The only support address used anywhere on the site is `podrska.pazarime@gmail.com`.
No database, auth, admin, listing or messaging code is involved.

## Promocija oglasa uplatom na račun (ručna provera)
Migration `supabase/migrations/20261012_promo_bank_transfer.sql` (**already applied to PazariMe-v2**; idempotent) adds
`promo_packages`, `promo_payment_settings` (admin-only, one row), `promo_orders`, `promo_payment_events` and the RPCs
`create_promo_order`, `submit_promo_payment`, `cancel_promo_order`, `admin_confirm_promo_payment`, `admin_reject_promo_payment`,
`admin_upsert_promo_package`, `admin_set_promo_package_active`, `admin_reorder_promo_packages`, `admin_get_payment_settings`,
`admin_save_payment_settings`, `promo_checkout_available`, `expire_promotions`.
- Users can only READ their own orders (RLS). Every write goes through an RPC that reads price/duration from the database.
- Only `admin_confirm_promo_payment` activates a promotion (via `listings.is_featured` + `featured_until`). "Uplatio/la sam" only asks for review.
- Payments stay disabled until an admin enters recipient, account number and payment purpose in **Admin → Uplate → Podešavanja računa**.
- Expiry: the site calls `expire_promotions()` on load and the UI ignores `is_featured` once `featured_until` has passed.
  Optional hourly cron: `supabase/optional/pg_cron_expire_promotions.sql` (needs the pg_cron extension; not required).
- Also closes a hole where a listing could be INSERTed with `is_featured = true` (free, never-expiring promotion).

## Plaćene prodavnice (otvaranje i obnova pretplate uplatom na račun)
Migration `supabase/migrations/20261013_paid_stores.sql` (**already applied to PazariMe-v2**; idempotent; requires 20261012) extends the
existing payment system instead of adding a parallel one:
- `promo_packages.kind` (`listing_promo` | `store_subscription`) and `promo_orders.kind` (`listing_promo` | `store_open` | `store_renew`) + store fields.
  Same bank settings, references, history, admin screens and confirm/reject path.
- `stores.paid_until` + `stores.grandfathered`. A store is entitled only if `grandfathered OR paid_until > now()`.
- A store is **created only inside `admin_confirm_promo_payment`**, after an admin confirms the money arrived. Direct INSERT into `stores` is revoked/blocked;
  clients can no longer edit `paid_until`/`grandfathered` or re-activate an unentitled store (`pzm_stores_guard`); products of an unentitled store cannot be published.
- `stores_select` RLS is time-aware, so an expired store is hidden from visitors immediately. `expire_promotions()` (called on site load; optional pg_cron)
  sets expired stores to `inactive`; the existing cascade pauses their products and a confirmed renewal restores them.
- Renewal extends from the CURRENT expiry (or from confirmation if already expired). A pending renewal never extends anything.

### GRANDFATHERING (existing stores)
Every store that existed when the migration ran (currently `velvoro-parfume`) was marked `grandfathered = true`: free, no expiry, never auto-deactivated,
no renewal offered. New stores default to `grandfathered = false`. An admin can switch a store with `admin_set_store_grandfathered(store_id, false, <expiry>)`
(Admin → Prodavnice → detalj → „Prebaci na plaćenu pretplatu“) or back to free („Označi kao besplatnu“).

### Admin setup
Admin → Uplate → Podešavanja računa (recipient, account, purpose, enable) and → Paketi prodavnice (price + duration). Until both exist, users cannot start checkout.
Notifications: there is no e-mail/notification system in the project, so expiry warnings are in-app (banner on Moj PazariMe and the store dashboard, 7 days before and after expiry).

## Akcije (popusti na proizvode) — DATABASE STATUS: APPLIED & VERIFIED on PazariMe-v2 (tables/policies/functions present; run optional/verify_store_promotions.sql to re-check)
Migrations `20261015_product_currency.sql`, `20261016_store_promotions.sql` and `20261017_store_storefront.sql` exist in the repo but a missing
`public.store_promotions` (PGRST205) means they were never run on PazariMe-v2. Run `supabase/apply_20261015_to_20261017.sql` once in the SQL Editor
(idempotent), then `supabase/optional/verify_store_promotions.sql` (read-only, every row must be `true`).
All writes to `store_promotions` go through `save_store_promotion` / `delete_store_promotion` (owner of the store, or admin); direct table writes are revoked.

## Filteri po specifikacijama + prioritet izdvojenih oglasa (20261018 — applied to PazariMe-v2)
- Admin → Specifikacije → opcija „Prikaži kao filter u pretrazi“ (`category_specifications.is_filterable`). Samo aktivne + filterable specifikacije se prikazuju kao filteri, i samo u svojim kategorijama
  (number/decimal → od/do, select → dropdown, multiselect → checkbox, boolean → Svejedno/Da/Ne, text → tekst). URL: `sf_<specId>[_min|_max]`.
- Filtriranje radi baza: `search_listings_by_specs(jsonb)` (SECURITY INVOKER, poštuje RLS). Promena kategorije briše filtere stare kategorije.
- Izdvojeni oglasi: view `listings_search` (security_invoker, samo SELECT) ima kolonu `featured_active` = `is_featured AND (featured_until IS NULL OR featured_until > now())`.
  Pretraga sortira `featured_active DESC` pa izabrano sortiranje; istekle promocije gube prioritet odmah, bez cron-a. Početna ima sekciju „Izdvojeni oglasi“ (sakrivena kada je prazna) i „Najnoviji oglasi“ bez duplikata.
- Napomena: pretraga prikazuje do 200 rezultata (nema straničenja); prioritet se primenjuje u upitu pa izdvojeni oglasi uvek ostaju u tih 200.


## Premium promocija oglasa (20261019)
- Tip paketa: admin panel → Paketi promocija → „Vrsta promocije“ (Standardna / Premium). Čuva se u `promo_packages.is_premium`
  (kolona već postoji u bazi – migracija `premium_listings`); posle čuvanja aplikacija čita red nazad i prijavi grešku ako tip nije sačuvan.
- Premium status postoji samo kada je `listings.premium_until` u budućnosti. Postavlja ga ISKLJUČIVO `admin_confirm_promo_payment()`
  (admin potvrda uplate); korisnik ga ne može postaviti (trigger `protect_listing_counters`).
- Prioritet je u bazi: `listings_search.promo_rank` (2 = Premium, 1 = standardno izdvojen, 0 = običan), sortira se PRE limita.
  Računa se sa `now()`, pa istekla promocija sama gubi prioritet (cron nije potreban).
- Primena: `supabase/migrations/20261019_premium_priority.sql` (samo view + funkcija, ne dira podatke). Već primenjeno na PazariMe-v2.
- Napomena: migracija `premium_listings` (is_premium, premium_until, admin_* funkcije) postoji u bazi, ali nije u ovom repozitorijumu.

## Valuta oglasa (20261020)
- Create/edit forma: izbor RSD ili EUR pored cene; podrazumevano RSD. Čuva se u `listings.currency` (kolona i CHECK već postoje).
- Postojeći oglasi zadržavaju sačuvanu valutu (EUR iz 20261015). Nova kolona-default je RSD (`20261020_listing_currency_default_rsd.sql`).
- Sortiranje/filter po ceni koristi `price_eur` (RSD / 117.5, samo za poređenje); originalna cena i valuta se ne menjaju.


## Status prodavca i zaštita kupaca (20261021)
Seller declaration (**Fizičko lice – privatni prodavac** / **Trgovac**) + notice on every listing + legal page `#/zastita-kupaca`.

**Database status:** `supabase/migrations/20261021_seller_status_buyer_protection.sql` is APPLIED to PazariMe-v2 (migration name `seller_status_buyer_protection`); additive and idempotent.
It re-uses what already existed live: `profiles.trader_status` / `declaration_*` / `business_*`, the `declare_trader_status` RPC, the guard trigger (clients cannot write the declaration columns),
`trader_status_history` (owner/admin only), the listing/store insert gate, `admin_list_users`, `admin_get_trader_detail`, `admin_get_trader_history`. It adds:
- `declare_trader_status` – same signature, stricter server-side validation for traders (poslovno ime, pravna forma, adresa sedišta, matični broj = 8 cifara, PIB = 9 cifara, e-pošta, telefon – all required). Private sellers store NO business data.
- CHECK `profiles_business_data_only_for_traders` – only a trader can carry `business_*`.
- `get_seller_public_info(uuid[])` (public notice data; business fields only for declared traders who have listings/a store) and `get_my_seller_status()` (own declaration).

**Flow:** the declaration is NOT asked at registration. It is asked the first time a user starts publishing a listing (`#/postavi-oglas`) or opens a store (`#/moja-prodavnica`); the DB gate (RLS) enforces it. Users can view/change it in *Moj PazariMe → Podešavanja → Status prodavca* (`#/deklaracija`).
**Where the notice is shown (single renderer `sellerStatusBoxHtml`):** listing page (also store products), checkout `#/kupi/<id>` (before the confirm button), seller profile, storefront header. Legacy sellers who never declared show a neutral "Status nije izjavljen". Business data is shown "prema izjavi prodavca" – nothing is described as verified.
**Admin:** *Korisnici* has a "Status prodavca" column; the user detail shows the full declaration + history (admin-only RPCs).
**Legal page:** text lives in `LEGAL_DOCS["zastita-kupaca"]` in `app.js`; linked from the footer, mobile menu and (ranking section) from the search-results page.

### Optional hardening – NOT applied
`supabase/optional/lock_down_profile_business_columns.sql` stops anyone from reading `profiles.business_*` in bulk via the table API (today `profiles` is publicly readable, so trader contact data of ALL traders can be listed with one request).
Run it only AFTER deploying this frontend (older builds use `select("*")` on `profiles` for the admin user count). Tested in a rolled-back transaction; rollback: `grant select on public.profiles to anon, authenticated;`.

### Needs professional legal review before launch
Serbian wording on the legal page and in the declaration screen, the private-seller notice text (see report), the required-field set for traders, and Uslovi korišćenja §2/§9 (see report).
