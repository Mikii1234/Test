/* ======================================================================
   PAZARIME — real marketplace on Supabase.
   Auth: Supabase Auth (email/password). Data: Postgres with RLS.
   Photos: Supabase Storage (listing-images bucket, path {uid}/{listingId}/*).
   Views: secure record_listing_view() RPC (server-side, spam-guarded).
   Ratings: secure rate_seller() RPC + get_seller_reputation() RPC.
   No demo/mock data anywhere — every screen reads real rows.
   ====================================================================== */

const SUPABASE_URL = "https://juzjzmaxyemwbvdmocdn.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp1emp6bWF4eWVtd2J2ZG1vY2RuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk3NzA4NDUsImV4cCI6MjEwNTM0Njg0NX0.8qRTBO2yRnkAENMgDskrQ6xvO9CdnMYtoahWnUjx8Ds";
let sb = null;

/* ---------------- TAXONOMY (fixed menu, not marketplace data) -------- */
const CITIES = ["Beograd","Novi Sad","Niš","Kragujevac","Subotica","Zrenjanin","Pančevo","Čačak","Kraljevo","Novi Pazar","Leskovac","Smederevo","Valjevo","Kruševac","Sombor"];
const CATEGORIES = [
  {id:"telefoni", name:"Telefoni", emoji:"📱", brands:["Apple","Samsung","Xiaomi","Google","OnePlus","Huawei","Ostalo"]},
  {id:"laptopovi", name:"Laptopovi", emoji:"💻", brands:["Apple","Lenovo","Dell","HP","Asus","Acer","Ostalo"]},
  {id:"racunari", name:"Računari i komponente", emoji:"🖥️", brands:["MSI","Gigabyte","NVIDIA","AMD","Intel","Ostalo"]},
  {id:"gaming", name:"Gaming", emoji:"🎮", brands:["Sony","Microsoft","Nintendo","Razer","Logitech","Ostalo"]},
  {id:"automobili", name:"Automobili", emoji:"🚗", brands:["Volkswagen","Opel","Audi","BMW","Renault","Fiat","Škoda","Ford","Ostalo"]},
  {id:"dom", name:"Dom", emoji:"🏠", brands:["IKEA","Bosch","Samsung","Gorenje","Tefal","Ostalo"]},
  {id:"garderoba", name:"Garderoba", emoji:"👕", brands:["Zara","Nike","Adidas","H&M","Levi's","Ostalo"]},
  {id:"foto", name:"Foto i video", emoji:"📷", brands:["Canon","Nikon","Sony","GoPro","DJI","Ostalo"]},
  {id:"satovi", name:"Satovi", emoji:"⌚", brands:["Apple","Garmin","Casio","Samsung","Fossil","Ostalo"]},
  {id:"oprema", name:"Oprema", emoji:"🎧", brands:["Sony","Bose","JBL","Sennheiser","Beats","Ostalo"]},
  {id:"alati", name:"Alati", emoji:"🔧", brands:["Bosch","Makita","DeWalt","Stanley","Ostalo"]},
  {id:"ostalo", name:"Ostalo", emoji:"📦", brands:["Razno"]},
];
const CATBYID = Object.fromEntries(CATEGORIES.map(c=>[c.id,c]));
const CONDITIONS = ["Novo","Kao novo","Polovno","Korišćeno"];

/* ---------------- AUTH STATE ---------------- */
let ME = {id:null, email:"", name:"", avatarUrl:"", isAdmin:false, resolved:false};
let favoriteIds = new Set();
let viewedThisSession = new Set();
let reportFormOpenFor = null;
let busyKeys = new Set();

/* ---------------- REALTIME MESSAGING + PRESENCE ----------------
   One shared Realtime channel per logged-in session (not one per open
   conversation) — Realtime enforces the messages table's RLS per
   subscriber, so this channel only ever receives INSERT/UPDATE events
   for messages in conversations the current user actually participates
   in. Set up once after login, torn down once on logout — no
   subscription churn while navigating between screens. */
let msgChannel = null;
let currentOpenConvId = null;          // which conversation's chat pane is on screen right now
let renderedMsgIds = new Set();        // dedupes optimistic-render vs realtime-echo, per open conversation
let unreadMessages = [];               // [{id, conversation_id}] — refreshed from DB, source of truth for the badge
const HEARTBEAT_INTERVAL_MS = 30000;
const ONLINE_THRESHOLD_MS = 90000;     // "online" = last_seen within this window
let heartbeatTimer = null;

function setupMessagingRealtime(){
  teardownMessagingRealtime();
  if(!ME.id || !sb) return;
  msgChannel = sb.channel("pzm-msgs-"+ME.id)
    .on("postgres_changes", {event:"INSERT", schema:"public", table:"messages"}, payload => handleRealtimeMessageInsert(payload.new))
    .on("postgres_changes", {event:"UPDATE", schema:"public", table:"messages"}, payload => handleRealtimeMessageUpdate(payload.new))
    .subscribe();
}
function teardownMessagingRealtime(){
  if(msgChannel){ sb.removeChannel(msgChannel); msgChannel = null; }
}

function startHeartbeat(){
  stopHeartbeat();
  if(!ME.id) return;
  const beat = async ()=>{
    if(document.visibilityState!=="visible" || !ME.id) return;
    try{ await sb.from("profiles").update({last_seen: new Date().toISOString()}).eq("id", ME.id); }catch(e){}
  };
  beat();
  heartbeatTimer = setInterval(beat, HEARTBEAT_INTERVAL_MS);
  document.addEventListener("visibilitychange", beat);
  heartbeatTimer_visHandler = beat; // keep reference for cleanup
}
let heartbeatTimer_visHandler = null;
function stopHeartbeat(){
  if(heartbeatTimer){ clearInterval(heartbeatTimer); heartbeatTimer=null; }
  if(heartbeatTimer_visHandler){ document.removeEventListener("visibilitychange", heartbeatTimer_visHandler); heartbeatTimer_visHandler=null; }
}
function formatPresence(lastSeenIso){
  if(!lastSeenIso) return {online:false, label:"Nikad aktivan/na"};
  const diffMs = Date.now() - new Date(lastSeenIso).getTime();
  if(diffMs < ONLINE_THRESHOLD_MS) return {online:true, label:"Aktivan/na sada"};
  const mins = Math.floor(diffMs/60000);
  if(mins<1) return {online:false, label:"Aktivan/na pre manje od minut"};
  if(mins<60) return {online:false, label:`Aktivan/na pre ${mins} min.`};
  const hrs = Math.floor(mins/60);
  if(hrs<24) return {online:false, label:`Aktivan/na pre ${hrs} h`};
  const days = Math.floor(hrs/24);
  if(days===1) return {online:false, label:"Aktivan/na juče"};
  if(days<7) return {online:false, label:`Aktivan/na pre ${days} dana`};
  return {online:false, label:`Aktivan/na ${fmtDate(lastSeenIso)}`};
}
function presenceDotHtml(lastSeenIso){
  const p = formatPresence(lastSeenIso);
  return `<span class="presence-dot ${p.online?'online':''}" title="${p.label}"></span>`;
}

/* ---- Unread badge (DB-derived, never localStorage) ---- */
async function fetchUnreadMessages(){
  if(!ME.id){ unreadMessages = []; return; }
  try{
    const { data, error } = await sb.from("messages").select("id,conversation_id").is("read_at", null).neq("sender_id", ME.id);
    if(error) throw error;
    unreadMessages = data||[];
  }catch(e){ unreadMessages = []; }
}
function renderUnreadBadge(){
  const n = unreadMessages.length;
  const label = n>99 ? "99+" : String(n);
  [document.getElementById("msgDot"), document.getElementById("msgDotMobile")].forEach(el=>{
    if(!el) return;
    el.textContent = label;
    el.style.display = n>0 ? "flex" : "none";
    el.style.alignItems = "center"; el.style.justifyContent = "center";
  });
}
async function refreshUnreadBadge(){
  await fetchUnreadMessages();
  renderUnreadBadge();
}

/* ---- Realtime event handlers ---- */
async function handleRealtimeMessageInsert(msg){
  if(renderedMsgIds.has(msg.id)) return; // our own optimistic insert already rendered this one
  if(msg.conversation_id === currentOpenConvId){
    appendMessageBubble(msg);
    if(msg.sender_id !== ME.id) markConversationRead(msg.conversation_id);
  }
  if(msg.sender_id !== ME.id){
    await refreshUnreadBadge();
    if(location.hash.startsWith("#/poruke")) refreshConversationListPreview();
  }
}
function handleRealtimeMessageUpdate(msg){
  // Read-receipt arrived for a message I sent — update the "Viđeno" line
  // under it if it's the currently open conversation.
  if(msg.conversation_id === currentOpenConvId && msg.sender_id === ME.id && msg.read_at){
    updateSeenIndicator(msg.conversation_id);
  }
}
async function markConversationRead(convId){
  try{
    await sb.from("messages").update({read_at: new Date().toISOString()}).eq("conversation_id", convId).is("read_at", null).neq("sender_id", ME.id);
    await refreshUnreadBadge();
  }catch(e){}
}


function guarded(key, fn){
  return async (...args)=>{
    if(busyKeys.has(key)) return;
    busyKeys.add(key);
    try{ await fn(...args); } finally { busyKeys.delete(key); }
  };
}

async function boot(){
  document.getElementById("app").innerHTML = `<div class="wrap section"><div class="empty"><div class="glyph">⏳</div><h3>Povezivanje...</h3><p>Učitavamo PazariMe.</p></div></div>`;
  sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    auth: { persistSession: true, autoRefreshToken: true, storageKey: "pzm-auth" }
  });
  const { data: { session } } = await sb.auth.getSession();
  await syncMe(session);
  sb.auth.onAuthStateChange(async (event, session) => {
    const hadUser = !!ME.id;
    await syncMe(session);
    if(ME.id && !hadUser){ setupMessagingRealtime(); startHeartbeat(); await refreshUnreadBadge(); }
    if(!ME.id && hadUser){ teardownMessagingRealtime(); stopHeartbeat(); unreadMessages=[]; renderUnreadBadge(); }
    if (event === "SIGNED_IN" || event === "SIGNED_OUT") route();
  });
  await loadFavoriteIds();
  await loadCategories();
  expirePromotionsOnce();
  if(ME.id){ setupMessagingRealtime(); startHeartbeat(); await refreshUnreadBadge(); }
  window.addEventListener("hashchange", route);
  route();
}
window.addEventListener("DOMContentLoaded", boot);

async function syncMe(session){
  if(!session || !session.user){ ME = {id:null,email:"",name:"",avatarUrl:genericAvatar("guest"),isAdmin:false,resolved:true}; return; }
  const u = session.user;
  ME.id = u.id; ME.email = u.email; ME.resolved = true;
  try{
    const { data } = await sb.from("profiles").select("display_name,avatar_url,is_admin,account_status,trader_status").eq("id", u.id).maybeSingle();
    if(data && data.account_status && data.account_status !== "active"){
      // Enforced here (not just hidden in the UI): a suspended/banned user is
      // signed out the moment their profile is loaded — on fresh login AND
      // on restoring an existing session, since both paths call syncMe().
      const msg = data.account_status === "banned"
        ? "Tvoj nalog je blokiran. Kontaktiraj podršku na podrska.pazarime@gmail.com ako smatraš da je ovo greška."
        : "Tvoj nalog je privremeno suspendovan. Kontaktiraj podršku na podrska.pazarime@gmail.com za više informacija.";
      await sb.auth.signOut();
      ME = {id:null,email:"",name:"",avatarUrl:genericAvatar("guest"),isAdmin:false,resolved:true};
      toast(msg);
      return;
    }
    ME.name = (data && data.display_name) || (u.email||"").split("@")[0];
    ME.avatarUrl = (data && data.avatar_url) || genericAvatar(u.id);
    ME.isAdmin = !!(data && data.is_admin);
    ME.traderStatus = (data && data.trader_status) || null;
  }catch(e){
    ME.name = (u.email||"").split("@")[0]; ME.avatarUrl = genericAvatar(u.id); ME.isAdmin = false;
  }
}
function isAdmin(){ return !!ME.isAdmin; }

/* ---------------- CATEGORIES (DB-backed, static list as fallback) ------
   The public wizard/filters keep using CATEGORIES/CATBYID exactly as
   before (including the static `brands` sub-lists, which have no DB
   equivalent yet) — this just overlays live name/emoji/active-state from
   Supabase on boot, with silent fallback to the shipped defaults if the
   fetch fails, so nothing breaks if this ever can't reach the DB. */
const DEFAULT_BRANDS = Object.fromEntries(CATEGORIES.map(c=>[c.id, c.brands]));
const DEFAULT_CAT_ORDER = CATEGORIES.map(c=>c.id);
async function loadCategories(){
  try{
    const { data, error } = await sb.from("categories").select("*").order("name");
    if(error || !data || !data.length) return;   // keep shipped defaults if the DB can't answer
    const rows = data.slice().sort((a,b)=>{
      const ia = DEFAULT_CAT_ORDER.indexOf(a.id), ib = DEFAULT_CAT_ORDER.indexOf(b.id);
      return (ia<0?1e6:ia)-(ib<0?1e6:ib) || String(a.name).localeCompare(String(b.name));
    });
    CATEGORIES.splice(0, CATEGORIES.length, ...rows.map(c=>({id:c.id, name:c.name, emoji:c.emoji||"📦", brands:DEFAULT_BRANDS[c.id]||["Ostalo"], isActive:c.is_active!==false})));
    Object.keys(CATBYID).forEach(k=>delete CATBYID[k]);
    CATEGORIES.forEach(c=>{ CATBYID[c.id]=c; });
  }catch(e){ /* keep static defaults */ }
}
function activeCategories(){ return CATEGORIES.filter(c=>c.isActive!==false); }
function genericAvatar(seed){
  return `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 60 60'%3E%3Crect width='60' height='60' rx='30' fill='%232F5FFF'/%3E%3C/svg%3E`;
}

/* localStorage — only per-viewer conveniences (session token, an unsent
   listing draft, anon view-tracking id, "return here after login"). */
const Store = {
  get(key,fallback){ try{ const v=localStorage.getItem("pzm:"+key); return v?JSON.parse(v):fallback; }catch(e){ return fallback; } },
  set(key,val){ try{ localStorage.setItem("pzm:"+key, JSON.stringify(val)); }catch(e){} },
  del(key){ try{ localStorage.removeItem("pzm:"+key); }catch(e){} }
};
function getAnonViewerKey(){
  let k = Store.get("anonViewerKey", null);
  if(!k){ k = "a:" + crypto.randomUUID(); Store.set("anonViewerKey", k); }
  return k;
}
function getViewerKey(){ return ME.id ? ("u:"+ME.id) : getAnonViewerKey(); }
function requireAuthRedirect(msg){
  toast(msg || "Potrebna je prijava");
  Store.set("postLoginRedirect", location.hash || "#/");
  location.hash = "/prijava";
}

function toast(msg){
  const t = document.getElementById("toast");
  t.textContent = msg; t.classList.add("show");
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(()=>t.classList.remove("show"), 2600);
}
// Currency per product: "EUR" (default, all legacy data) or "RSD". Amounts are NEVER converted for display.
const EUR_RSD_REF = 117.5; // reference rate (NBS ~117.4 in Oct 2026). Used ONLY for cross-currency sort/filter; must match price_eur in the DB migration.
// ---- Store promotions (the DB is the source of truth; the browser only displays) ----
let PROMOS = {}, PROMOS_AT = 0;
async function loadPromos(force){
  if(!force && Date.now()-PROMOS_AT < 60000) return;
  try{
    const { data, error } = await sb.from("active_promotions").select("listing_id,percent,starts_at,ends_at");
    if(error) throw error;
    PROMOS = {}; (data||[]).forEach(p=>{ PROMOS[p.listing_id] = p; }); PROMOS_AT = Date.now();
  }catch(e){ PROMOS = {}; PROMOS_AT = Date.now(); console.error("[PazariMe] Učitavanje aktivnih akcija nije uspelo (view active_promotions):", e && (e.message||e), e && e.code ? "["+e.code+"]" : ""); }   // no fake promotions are shown on failure, but the error is NOT hidden
}
function promoOf(l){ const p = l && l.id ? PROMOS[l.id] : null; return (p && new Date(p.ends_at) > new Date() && new Date(p.starts_at) <= new Date()) ? p : null; }
function discountedPrice(price, pct){ return Math.round(Number(price||0) * (100 - pct)) / 100; }   // same math as the DB: round(price*(100-pct)/100, 2)
function effPrice(l){ const p = promoOf(l); return p ? discountedPrice(l.price, p.percent) : Number(l.price||0); }
function promoState(p, now){ now = now || new Date(); return new Date(p.ends_at) <= now ? "expired" : new Date(p.starts_at) > now ? "scheduled" : "active"; }
function fmtPrice(p, cur){ const n = Number(p||0); return cur==="EUR" ? "€ " + n.toLocaleString("de-DE") : n.toLocaleString("sr-RS",{maximumFractionDigits:2}) + " RSD"; }   // default currency = RSD
function fmtDate(ts){
  if(!ts) return "";
  const t = typeof ts === "number" ? ts : new Date(ts).getTime();
  const days = Math.floor((Date.now()-t)/86400000);
  if(days<=0) return "danas";
  if(days===1) return "juče";
  if(days<7) return `pre ${days} dana`;
  if(days<30) return `pre ${Math.floor(days/7)} ned.`;
  return `pre ${Math.floor(days/30)} mes.`;
}
function esc(s){ return String(s==null?"":s).replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function statusLabel(s){ return {draft:"Nacrt",active:"Aktivan",sold:"Prodato",paused:"Pauzirano",removed:"Uklonjen"}[s]||s; }
function statusClass(s){ return s==="sold"?"status-sold":s==="active"?"status-active":"status-pending"; }
function emptyState(glyph,title,body,cta){ return `<div class="empty"><div class="glyph">${glyph}</div><h3>${title}</h3><p>${body||""}</p>${cta||""}</div>`; }

/* ---------------- FAVORITES ---------------- */
async function loadFavoriteIds(){
  if(!ME.id){ favoriteIds = new Set(); return; }
  try{
    const { data, error } = await sb.from("favorites").select("listing_id").eq("user_id", ME.id);
    if(error) throw error;
    favoriteIds = new Set((data||[]).map(r=>r.listing_id));
  }catch(e){ favoriteIds = new Set(); }
}
const toggleFavorite = guarded("fav", async (listingId)=>{
  if(!ME.id){ requireAuthRedirect("Prijavi se da bi sačuvao oglas"); return; }
  try{
    if(favoriteIds.has(listingId)){
      const { error } = await sb.from("favorites").delete().eq("user_id", ME.id).eq("listing_id", listingId);
      if(error) throw error;
      favoriteIds.delete(listingId);
      toast("Uklonjeno iz omiljenih");
    }else{
      const { error } = await sb.from("favorites").insert({ user_id: ME.id, listing_id: listingId });
      if(error) throw error;
      favoriteIds.add(listingId);
      toast("Dodato u omiljene");
    }
  }catch(e){ toast("Greška — pokušaj ponovo"); }
  refreshFavButtons();
});
function refreshFavButtons(){
  document.querySelectorAll("[data-fav-id]").forEach(btn=>{
    btn.classList.toggle("active", favoriteIds.has(btn.getAttribute("data-fav-id")));
  });
}

/* ---------------- LISTING CARD / GRID ---------------- */
/* ---------------- LISTING TYPES + DYNAMIC SPECIFICATIONS ----------------
   listing_type is an internal column on `listings`. "Prodajem"/"Kupujem" are
   NEVER shown as a badge on normal cards/pages (only as a search filter and in
   the posting form); only the two service types get a visible label.
   Specification definitions (category_specifications) and values
   (listing_specification_values) come entirely from Supabase — nothing hardcoded. */
const LISTING_TYPES = [
  {id:"offer_sale",      label:"Prodajem",      emoji:"🏷️", hint:"Prodaješ proizvod"},
  {id:"wanted_purchase", label:"Kupujem",       emoji:"🛒", hint:"Tražiš proizvod da kupiš"},
  {id:"service_offer",   label:"Nudim uslugu",  emoji:"🛠️", hint:"Nudiš svoju uslugu"},
  {id:"service_request", label:"Tražim uslugu", emoji:"🙋", hint:"Treba ti neko da uradi uslugu"},
];
const LISTING_TYPE_IDS = LISTING_TYPES.map(t=>t.id);
const SPEC_FIELD_TYPES = [["text","Tekst"],["number","Broj"],["decimal","Decimalni broj"],["select","Izbor (jedan)"],["multiselect","Višestruki izbor"],["boolean","Da / Ne"]];

function isMissingListingTypeColumn(e){ return !!e && /listing_type/i.test(e.message||"") && (e.code==="PGRST204" || e.code==="42703" || /schema cache|does not exist|Could not find/i.test(e.message||"")); }
function listingTypeOf(l){ return (l && LISTING_TYPE_IDS.includes(l.listing_type)) ? l.listing_type : "offer_sale"; }
function listingTypeLabel(t){ const f = LISTING_TYPES.find(x=>x.id===t); return f ? f.label : t; }
function isServiceType(t){ return t==="service_offer" || t==="service_request"; }
function listingTypeBadgeHtml(t){
  if(!isServiceType(t)) return "";   // sale/buy: intentionally no badge
  const st = t==="service_offer" ? "background:var(--blue-dim);color:var(--blue);border-color:transparent;" : "background:var(--bg);color:var(--warn);";
  return `<span class="chip" style="${st}">${listingTypeLabel(t)}</span>`;
}
function listingPriceText(l){ return (listingTypeOf(l)!=="offer_sale" && !Number(l.price)) ? "Po dogovoru" : (function(){ const pm = promoOf(l); return !pm ? fmtPrice(l.price, l.currency) : `<span class="promo-now">${fmtPrice(effPrice(l), l.currency)}</span> <s class="promo-old">${fmtPrice(l.price, l.currency)}</s> <span class="promo-badge">-${pm.percent}%</span> <span class="promo-tag">NA AKCIJI</span>`; })(); }
function contactLabelFor(t){ return {offer_sale:"Kontaktiraj prodavca", wanted_purchase:"Kontaktiraj kupca", service_offer:"Kontaktiraj pružaoca usluge", service_request:"Kontaktiraj korisnika"}[t] || "Kontaktiraj prodavca"; }
function priceLabelFor(t, cur){ const c = cur==="EUR" ? "EUR" : "RSD"; return ({offer_sale:"Cena", wanted_purchase:"Maksimalni budžet", service_offer:"Cena usluge", service_request:"Budžet"}[t] || "Cena") + " (" + c + ")"; }
function currencySelectHtml(id, cur, onchange){ return `<select id="${id}" aria-label="Valuta" style="width:auto; flex:0 0 auto;" ${onchange?`onchange="${onchange}"`:""}><option value="RSD" ${cur!=="EUR"?"selected":""}>RSD</option><option value="EUR" ${cur==="EUR"?"selected":""}>€ EUR</option></select>`; }

/* --- spec definitions & values (all read from Supabase) ---
   Live schema: category_specifications is a GLOBAL list; each row has category_ids[] and listing_types[]
   (an empty array means "all"). Options are [{value,label}]. Writes go through SECURITY DEFINER RPCs. */
function specOptions(s){
  return (Array.isArray(s.options)?s.options:[]).map(o=> (o && typeof o==="object") ? {value:String(o.value), label:String(o.label!=null?o.label:o.value)} : {value:String(o), label:String(o)});
}
function specApplies(s, category, type){
  const c = s.category_ids || [], lt = s.listing_types || [];
  return (!c.length || c.includes(category)) && (!lt.length || lt.includes(type));
}
async function fetchCategorySpecs(catId, type){
  if(!catId) return [];
  try{
    const { data, error } = await sb.from("category_specifications").select("*")
      .eq("is_active", true).order("sort_order").order("created_at");
    if(error) throw error;
    return (data||[]).filter(s=>specApplies(s, catId, type||"offer_sale"));
  }catch(e){ console.error(e); return []; }
}
// public detail page: stored values joined with their (active, still-applicable) definitions
async function fetchListingSpecs(listing){
  try{
    const { data, error } = await sb.from("listing_specification_values")
      .select("*, spec:category_specifications(id,label,field_type,unit,options,sort_order,is_active,category_ids,listing_types)")
      .eq("listing_id", listing.id);
    if(error) throw error;
    const t = listingTypeOf(listing);
    return (data||[]).filter(r=>r.spec && r.spec.is_active!==false && specApplies(r.spec, listing.category, t))
      .sort((a,b)=>(a.spec.sort_order||0)-(b.spec.sort_order||0));
  }catch(e){ return []; }
}
function specValueText(r){
  const s = r.spec;
  if(s.field_type==="boolean") return r.value_boolean===true ? "Da" : r.value_boolean===false ? "Ne" : null;
  const lab = v => { const o = specOptions(s).find(x=>x.value===v); return o ? o.label : v; };
  if(s.field_type==="select") return r.value_text ? lab(r.value_text) : null;
  if(s.field_type==="multiselect") return (r.value_options||[]).length ? r.value_options.map(lab).join(", ") : null;
  if(s.field_type==="number" || s.field_type==="decimal"){
    if(r.value_number==null) return null;
    const n = Number(r.value_number);
    const txt = Math.abs(n)>=10000 ? n.toLocaleString("de-DE",{maximumFractionDigits:6}) : String(n).replace(".",",");
    return txt + (s.unit ? " "+s.unit : "");
  }
  return r.value_text || null;
}
function specRowsHtml(rows){
  return rows.map(r=>{ const v = specValueText(r); return v==null ? "" : `<tr><td>${esc(r.spec.label)}</td><td>${esc(v)}</td></tr>`; }).join("");
}
function specValuesFromRows(defs, rows){
  const byId = Object.fromEntries((rows||[]).map(r=>[r.specification_id, r]));
  const out = {};
  defs.forEach(s=>{
    const r = byId[s.id]; if(!r) return;
    if(s.field_type==="boolean") out[s.id] = r.value_boolean;
    else if(s.field_type==="multiselect") out[s.id] = r.value_options || [];
    else if(s.field_type==="number" || s.field_type==="decimal") out[s.id] = r.value_number==null ? "" : String(r.value_number);
    else out[s.id] = r.value_text || "";
  });
  return out;
}
function specIsEmpty(v){ return v==null || v==="" || (Array.isArray(v) && !v.length); }
function specMissing(defs, vals){ return (defs||[]).find(s=>s.is_required && specIsEmpty((vals||{})[s.id])) || null; }
function specBadNumber(defs, vals){
  return (defs||[]).find(s=>{
    if(s.field_type!=="number" && s.field_type!=="decimal") return false;
    const v = (vals||{})[s.id]; if(specIsEmpty(v)) return false;
    const n = Number(String(v).replace(",",".")); if(!isFinite(n)) return true;
    if(s.field_type==="number" && !Number.isInteger(n)) return true;
    if(s.min_value!=null && n < Number(s.min_value)) return true;
    if(s.max_value!=null && n > Number(s.max_value)) return true;
    return false;
  }) || null;
}
function specPayload(defs, vals){
  const out = {};
  (defs||[]).forEach(s=>{
    let v = (vals||{})[s.id];
    if(specIsEmpty(v) && v!==false){ out[s.id] = null; return; }
    if((s.field_type==="number"||s.field_type==="decimal") && typeof v==="string") v = v.replace(",",".");
    out[s.id] = v;
  });
  return out;
}
async function saveListingSpecs(listingId, defs, vals){
  const { error } = await sb.rpc("set_listing_specifications", { p_listing_id: listingId, p_values: specPayload(defs, vals) });
  if(error) throw error;
}

/* --- shared form fields (wizard + edit). scope: "wiz" | "edit" --- */
function specDefsFor(scope){ return scope==="wiz" ? wizSpecDefs : (editSpec ? editSpec.defs : []); }
function specStoreFor(scope){ return scope==="wiz" ? wizState.specValues : (editSpec ? editSpec.values : {}); }
function specChange(scope, id, val){
  specStoreFor(scope)[id] = val;
  if(scope==="wiz") wizFieldChanged("specifikacije");
}
function specToggle(scope, id, idx, checked){
  const s = specDefsFor(scope).find(x=>x.id===id); if(!s) return;
  const opt = specOptions(s)[idx]; if(!opt) return;
  const st = specStoreFor(scope);
  let arr = Array.isArray(st[id]) ? st[id].slice() : [];
  arr = arr.filter(o=>o!==opt.value); if(checked) arr.push(opt.value);
  st[id] = arr;
  if(scope==="wiz") wizFieldChanged("specifikacije");
}
function specFieldHtml(scope, s, val){
  const id = s.id;
  const opts = specOptions(s);
  const label = `<label>${esc(s.label)}${s.unit?` (${esc(s.unit)})`:""}${s.is_required?` <span style="color:var(--danger);">*</span>`:""}</label>`;
  const help = s.help_text ? `<div style="font-size:11.5px;color:var(--ink-faint);margin-top:4px;">${esc(s.help_text)}</div>` : "";
  const mm = (s.min_value!=null?` min="${esc(s.min_value)}"`:"") + (s.max_value!=null?` max="${esc(s.max_value)}"`:"");
  let input = "";
  if(s.field_type==="text"){
    input = `<input type="text" maxlength="200" value="${esc(val==null?"":val)}" oninput="specChange('${scope}','${id}',this.value)">`;
  } else if(s.field_type==="number"){
    input = `<input type="number" inputmode="numeric" step="1"${mm} value="${esc(val==null?"":val)}" oninput="specChange('${scope}','${id}',this.value)">`;
  } else if(s.field_type==="decimal"){
    input = `<input type="number" inputmode="decimal" step="any"${mm} value="${esc(val==null?"":val)}" oninput="specChange('${scope}','${id}',this.value)">`;
  } else if(s.field_type==="select"){
    input = `<select onchange="specChange('${scope}','${id}',this.value)"><option value="">Izaberi</option>${opts.map(o=>`<option value="${esc(o.value)}" ${val===o.value?"selected":""}>${esc(o.label)}</option>`).join("")}</select>`;
  } else if(s.field_type==="multiselect"){
    const arr = Array.isArray(val) ? val : [];
    input = `<div class="spec-multi">${opts.map((o,i)=>`<label class="f-check"><input type="checkbox" ${arr.includes(o.value)?"checked":""} onchange="specToggle('${scope}','${id}',${i},this.checked)"> ${esc(o.label)}</label>`).join("")}</div>`;
  } else if(s.field_type==="boolean"){
    input = `<select onchange="specChange('${scope}','${id}',this.value===''?null:this.value==='true')"><option value="">Izaberi</option><option value="true" ${val===true?"selected":""}>Da</option><option value="false" ${val===false?"selected":""}>Ne</option></select>`;
  }
  return `<div class="form-group">${label}${input}${help}</div>`;
}
function specFieldsHtml(scope, defs, vals){
  return (defs||[]).map(s=>specFieldHtml(scope, s, (vals||{})[s.id])).join("");
}

function listingCard(l){
  const isFav = favoriteIds.has(l.id);
  const images = l.images || [];
  const cover = images.length ? images[Math.min(l.cover_index||0, images.length-1)] : null;
  const cat = CATBYID[l.category];
  const href = listingHref(l);
  const st = l.store_id ? STORE_CACHE[l.store_id] : null;
  return `<div class="card${isPremiumNow(l)?" card-premium":""}">
    <a href="${href}">
      <div class="thumb">
        ${isPremiumNow(l)?'<span class="badge badge-premium">PREMIUM OGLAS</span>':(isFeaturedNow(l)?'<span class="badge">Izdvojeno</span>':'')}
        ${productUnavailable(l)?'<span class="badge" style="top:auto;bottom:10px;background:var(--danger);color:#fff;">Nedostupno</span>':''}
        ${cover?`<img src="${cover}" alt="" loading="lazy" style="width:100%;height:100%;object-fit:cover;">`:`<span>${cat?cat.emoji:"📦"}</span>`}
      </div>
    </a>
    <button class="fav ${isFav?'active':''}" data-fav-id="${l.id}" onclick="event.preventDefault();toggleFavorite('${l.id}')" aria-label="Sačuvaj oglas">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="${isFav?'currentColor':'none'}" stroke="currentColor" stroke-width="2"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 1 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z"/></svg>
    </button>
    <a href="${href}">
      <div class="body">
        <div class="price">${listingPriceText(l)}</div>
        <div class="title">${esc(l.title)}</div>
        <div class="cond">${isServiceType(listingTypeOf(l)) ? listingTypeBadgeHtml(listingTypeOf(l)) : ((listingTypeOf(l)==="offer_sale"||l.condition) ? `<span class="chip">${esc(l.condition||"")}</span>` : "")}${l.store_id?` <span class="chip" style="background:var(--blue-dim);color:var(--blue);border-color:transparent;">🏪 ${st?esc(st.name):"Prodavnica"}</span>`:""}</div>
        <div class="meta"><span>${esc(l.city||"")}</span><span>${fmtDate(l.created_at)}</span></div>
      </div>
    </a>
    ${l.store_id && l.status==="active" && !productUnavailable(l) ? `<a class="btn btn-primary btn-sm" href="#/kupi/${esc(l.id)}" style="display:block; margin:0 12px 12px; text-align:center;">🛒 Kupi</a>` : ""}
  </div>`;
}
function listingGrid(list){
  if(!list.length) return emptyState("🔍","Nema rezultata za izabrane filtere.","Pokušaj da promeniš pretragu ili ukloniš neke filtere.");
  return `<div class="listing-grid">${list.map(listingCard).join("")}</div>`;
}

/* ---------------- LISTING QUERIES (Supabase / Postgres) ---------------- */
/* Featured priority lives in the DATABASE: view public.listings_search exposes `featured_active`
   (is_featured AND (featured_until IS NULL OR featured_until > now())) so expired promotions lose priority even
   if nobody ran the cleanup job, and the ordering/limit are applied by Postgres (not by styling). */
async function queryActiveListings(limitN=8, opts){
  try{
    let q = sb.from("listings_search").select("*").eq("status","active");
    if(opts && opts.excludeFeatured) q = q.eq("promo_rank", 0);   // homepage: no duplicates with the featured section
    const { data, error } = await q.order("promo_rank",{ascending:false}).order("created_at",{ascending:false}).limit(limitN);
    if(error) throw error;
    await cacheStoresFor(data);
    return data||[];
  }catch(e){ console.error(e); return []; }
}
async function queryFeaturedListings(limitN=8){
  try{
    const { data, error } = await sb.from("listings_search").select("*").eq("status","active").gte("promo_rank", 1)
      .order("promo_rank",{ascending:false}).order("created_at",{ascending:false}).limit(limitN);
    if(error) throw error;
    await cacheStoresFor(data);
    return data||[];
  }catch(e){ console.error(e); return []; }
}
async function fetchFilteredListings(filters, sort){
  try{
    // admin-configured specification filters go through search_listings_by_specs (returns the same rows as listings_search,
    // so every other filter / order / limit below chains onto it exactly as before)
    let q = (filters.specFilters && filters.specFilters.length)
      ? sb.rpc("search_listings_by_specs", { p_filters: filters.specFilters }).select("*")
      : sb.from("listings_search").select("*");
    q = q.eq("status","active");
    if(filters.category) q = q.eq("category", filters.category);
    if(filters.listingType) q = q.eq("listing_type", filters.listingType);
    if(filters.city) q = q.eq("city", filters.city);
    if(filters.priceMin) q = q.gte("price_eur", filters.priceMin);
    if(filters.priceMax) q = q.lte("price_eur", filters.priceMax);
    if(filters.cond && filters.cond.length) q = q.in("condition", filters.cond);
    if(filters.exchange) q = q.eq("exchange", true);
    if(filters.q){
      // products of stores whose NAME matches the query are found too
      let storeClause = "";
      try{
        const { data: ms } = await sb.from("stores").select("id").eq("status","active").ilike("name", `%${filters.q.replace(/[%,()]/g," ")}%`).limit(20);
        if(ms && ms.length) storeClause = `,store_id.in.(${ms.map(x=>x.id).join(",")})`;
      }catch(e){}
      q = q.or(`title.ilike.%${filters.q}%,description.ilike.%${filters.q}%,brand.ilike.%${filters.q}%${storeClause}`);
    }
    let field="created_at", asc=false;
    if(sort==="cheap"){field="price_eur";asc=true;}
    else if(sort==="expensive"){field="price_eur";asc=false;}
    else if(sort==="views"){field="views_count";asc=false;}
    // PREMIUM first, then standard featured, then ordinary (promo_rank 2/1/0) - ALWAYS in the DB query, before the row limit; inside each group the chosen sort applies
    q = q.order("promo_rank",{ascending:false}).order(field,{ascending:asc});
    if(field!=="created_at") q = q.order("created_at",{ascending:false});
    q = q.limit(200);
    const { data, error } = await q;
    if(error) throw error;
    await cacheStoresFor(data);
    return data||[];
  }catch(e){ console.error(e); return []; }
}
async function fetchListing(id){
  try{
    const { data, error } = await sb.from("listings").select("*").eq("id", id).maybeSingle();
    if(error) throw error;
    return data;
  }catch(e){ return null; }
}
async function fetchMyListings(){
  if(!ME.id) return [];
  try{
    const { data, error } = await sb.from("listings").select("*").eq("seller_id", ME.id).order("created_at",{ascending:false});
    if(error) throw error;
    return data||[];
  }catch(e){ return []; }
}
async function fetchSellerActiveListings(sellerId){
  try{
    const { data, error } = await sb.from("listings").select("*").eq("seller_id", sellerId).eq("status","active").order("created_at",{ascending:false});
    if(error) throw error;
    await cacheStoresFor(data);
    return data||[];
  }catch(e){ return []; }
}
async function recordView(listingId){
  if(viewedThisSession.has(listingId)) return;
  viewedThisSession.add(listingId);
  try{ await sb.rpc("record_listing_view", { p_listing_id: listingId, p_viewer_key: getViewerKey() }); }catch(e){}
}

/* ---------------- PROFILES ---------------- */
async function resolveProfiles(ids){
  const clean = [...new Set((ids||[]).filter(Boolean))];
  if(!clean.length) return {};
  try{
    const { data, error } = await sb.from("profiles").select("id,display_name,avatar_url,created_at,last_seen").in("id", clean);
    if(error) throw error;
    const map = {};
    clean.forEach(id=>{ map[id] = {id, name:"Korisnik", avatarUrl:genericAvatar(id), createdAt:null, lastSeen:null}; });
    (data||[]).forEach(p=>{ map[p.id] = {id:p.id, name:p.display_name||"Korisnik", avatarUrl:p.avatar_url||genericAvatar(p.id), createdAt:p.created_at, lastSeen:p.last_seen}; });
    return map;
  }catch(e){
    const map={}; clean.forEach(id=>{ map[id]={id,name:"Korisnik",avatarUrl:genericAvatar(id),createdAt:null,lastSeen:null}; }); return map;
  }
}

/* ---------------- SELLER STATUS (fizičko lice / trgovac) ----------------
   Source of truth: profiles.trader_status + business_* (written ONLY by the declare_trader_status RPC).
   Public pages read it through get_seller_public_info(): business details come back for declared traders only.
   Nothing here claims the data is verified - it is shown as declared by the seller ("prema izjavi prodavca"). */
const SELLER_NOTICE_PRIVATE = "Prodavac je fizičko lice koje se izjasnilo da ne nastupa kao trgovac. Propisi o zaštiti potrošača koji se primenjuju na odnos između trgovca i potrošača ne primenjuju se na isti način na ovu kupoprodaju.";
function sellerStatusLabel(s){ return s==="trader" ? "Trgovac" : s==="non_trader" ? "Fizičko lice – privatni prodavac" : "Status nije izjavljen"; }
async function fetchSellerStatuses(ids){
  const clean = [...new Set((ids||[]).filter(Boolean))];
  const out = {};
  if(!clean.length) return out;
  try{
    const { data, error } = await sb.rpc("get_seller_public_info", { p_user_ids: clean });
    if(error) throw error;
    (data||[]).forEach(r=>{ out[r.user_id] = r; });
  }catch(e){
    console.error("[seller status]", e);
    clean.forEach(id=>{ out[id] = {__error:true}; });
  }
  return out;
}
async function fetchMySellerStatus(){
  if(!ME.id) return null;
  try{
    const { data, error } = await sb.rpc("get_my_seller_status");
    if(error) throw error;
    return (data && data[0]) || null;
  }catch(e){ console.error("[my seller status]", e); return null; }
}
function sellerBusinessRows(b){
  return [["Poslovno ime",b.business_name],["Pravna forma",b.business_legal_form],["Adresa sedišta",b.business_address],
          ["Matični broj",b.business_registration_number],["PIB",b.business_pib],["E-pošta",b.business_email],["Telefon",b.business_phone]]
    .filter(r=>r[1]);
}
function sellerBusinessDlHtml(b){
  const rows = sellerBusinessRows(b);
  if(!rows.length) return "";
  return `<dl class="ss-dl">${rows.map(([k,v])=>{
    let val = esc(v);
    if(k==="E-pošta") val = `<a href="mailto:${esc(v)}">${esc(v)}</a>`;
    if(k==="Telefon") val = `<a href="tel:${esc(String(v).replace(/[^\d+]/g,""))}">${esc(v)}</a>`;
    return `<div><dt>${k}</dt><dd>${val}</dd></div>`;
  }).join("")}</dl>`;
}
/* The notice shown next to seller information (listing, checkout, seller profile, storefront). */
function sellerStatusBoxHtml(info){
  const more = `<a href="#/zastita-kupaca" class="ss-more">Saznaj više</a>`;
  let kind = "undecl", label = "Status nije izjavljen", body = "";
  if(!info || info.__error){
    body = `<p>Podaci o statusu prodavca trenutno nisu dostupni. ${more}</p>`;
  }else if(info.trader_status==="trader"){
    kind = "trader"; label = sellerStatusLabel("trader");
    body = `<p style="margin-bottom:6px;">Prodavac je izjavio da nastupa kao trgovac.</p>${sellerBusinessDlHtml(info)}<p class="ss-note">Podaci su navedeni prema izjavi prodavca. ${more}</p>`;
  }else if(info.trader_status==="non_trader"){
    kind = "private"; label = sellerStatusLabel("non_trader");
    body = `<p>${esc(SELLER_NOTICE_PRIVATE)} ${more}</p>`;
  }else{
    body = `<p>Prodavac još nije izjavio da li nastupa kao trgovac. ${more}</p>`;
  }
  return `<div class="ss-box" role="note" aria-label="Status prodavca"><div class="ss-head"><span class="ss-label">STATUS PRODAVCA</span><span class="ss-chip ${kind}">${esc(label)}</span></div>${body}</div>`;
}
/* Account settings card (the user's own declaration). */
function mySellerStatusCardHtml(s){
  const st = s && s.trader_status;
  const declared = st==="trader" || st==="non_trader";
  const kind = st==="trader" ? "trader" : st==="non_trader" ? "private" : "undecl";
  const inner = !declared
    ? `<p>Još nisi izjavio/la svoj status. Izjava se traži kada prvi put objaviš oglas ili otvoriš prodavnicu, ali je možeš popuniti i sada.</p>`
    : (st==="trader"
        ? `<p style="margin-bottom:6px;">Ovi podaci su vidljivi kupcima na tvojim oglasima i u prodavnici.</p>${sellerBusinessDlHtml(s)}`
        : `<p>Kupci na tvojim oglasima vide ovo obaveštenje: ${esc(SELLER_NOTICE_PRIVATE)}</p>`)
      + (declared && s.declaration_timestamp ? `<p class="ss-note">Izjava data: ${fmtDate(s.declaration_timestamp)}</p>` : "");
  return `<div class="ss-box" style="margin:0 0 16px; padding:16px;">
    <div class="ss-head"><span class="ss-label">STATUS PRODAVCA</span><span class="ss-chip ${kind}">${esc(sellerStatusLabel(st))}</span></div>
    ${inner}
    <div style="display:flex; gap:12px; align-items:center; flex-wrap:wrap; margin-top:10px;">
      <a class="btn btn-outline btn-sm" href="#/deklaracija" onclick="Store.set('declReturn','#/moj-pazarime/podesavanja')">${declared?"Izmeni izjavu":"Izjavi status"}</a>
      <a href="#/zastita-kupaca" class="ss-more">Saznaj više</a>
    </div>
  </div>`;
}
/* Admin: declaration details + history for one user (admin-only RPCs that already exist in the database). */
async function adminSellerStatusHtml(userId){
  try{
    const [d, h] = await Promise.all([
      sb.rpc("admin_get_trader_detail", { p_user_id:userId }),
      sb.rpc("admin_get_trader_history", { p_user_id:userId })
    ]);
    if(d.error) throw d.error;
    const x = (d.data && d.data[0]) || {};
    const hist = (h && !h.error && h.data) || [];
    const kind = x.trader_status==="trader" ? "trader" : x.trader_status==="non_trader" ? "private" : "undecl";
    return `<div class="ss-box" style="margin:0 0 24px; padding:16px; max-width:640px;">
      <div class="ss-head"><span class="ss-label">STATUS PRODAVCA</span><span class="ss-chip ${kind}">${esc(sellerStatusLabel(x.trader_status))}</span></div>
      ${x.declaration_timestamp?`<p>Izjava data: ${fmtDateTime(x.declaration_timestamp)}</p>`:((x.trader_status==="trader"||x.trader_status==="non_trader")?"":`<p>Korisnik još nije dao izjavu.</p>`)}
      ${x.trader_status==="trader"?sellerBusinessDlHtml(x):""}
      <p class="ss-note">Podaci su onakvi kakve je korisnik uneo; nisu proveravani u registrima.</p>
      ${hist.length?`<div style="margin-top:8px; font-size:12px;"><b>Istorija izjava</b>${hist.map(r=>`<div>${fmtDateTime(r.created_at)}: ${esc(sellerStatusLabel(r.previous_status))} → ${esc(sellerStatusLabel(r.new_status))}</div>`).join("")}</div>`:""}
    </div>`;
  }catch(e){
    console.error("[admin seller status]", e);
    return `<div class="notice warn">Status prodavca trenutno nije moguće učitati.</div>`;
  }
}

/* ---------------- SELLER RATINGS ---------------- */
async function fetchReputation(sellerId){
  try{
    const { data, error } = await sb.rpc("get_seller_reputation", { p_seller_user_id: sellerId });
    if(error) throw error;
    const row = (data && data[0]) || null;
    return row ? {positive:Number(row.positive_count)||0, negative:Number(row.negative_count)||0, total:Number(row.total_count)||0}
                : {positive:0, negative:0, total:0};
  }catch(e){ return {positive:0,negative:0,total:0}; }
}
async function fetchMyRatingFor(sellerId){
  if(!ME.id) return null;
  try{
    const { data } = await sb.from("seller_ratings").select("rating").eq("rater_user_id", ME.id).eq("seller_user_id", sellerId).maybeSingle();
    return data ? data.rating : null;
  }catch(e){ return null; }
}
const rateSeller = guarded("rate", async (sellerId, rating)=>{
  if(!ME.id){ requireAuthRedirect("Prijavi se da bi ocenio prodavca"); return; }
  if(ME.id===sellerId){ toast("Ne možeš oceniti samog sebe"); return; }
  try{
    const { error } = await sb.rpc("rate_seller", { p_seller_user_id: sellerId, p_rating: rating });
    if(error) throw error;
    toast("Ocena je sačuvana");
    route();
  }catch(e){ toast("Greška: " + (e.message||"pokušaj ponovo")); }
});
function ratingWidget(sellerId, rep, myRating){
  const canRate = ME.id && ME.id!==sellerId;
  return `<div style="display:flex; align-items:center; gap:10px; margin-top:8px; flex-wrap:wrap;">
    <button class="chip" style="${myRating===1?'background:var(--success-bg);color:var(--success);border-color:var(--success);':''} ${canRate?'cursor:pointer;':'cursor:default;'}" ${canRate?`onclick="rateSeller('${sellerId}',1)"`:''}>👍 ${rep.positive}</button>
    <button class="chip" style="${myRating===-1?'background:var(--danger-bg);color:var(--danger);border-color:var(--danger);':''} ${canRate?'cursor:pointer;':'cursor:default;'}" ${canRate?`onclick="rateSeller('${sellerId}',-1)"`:''}>👎 ${rep.negative}</button>
    ${rep.total?`<span style="font-size:12px;color:var(--ink-faint);">${rep.total} ukupno ocena</span>`:`<span style="font-size:12px;color:var(--ink-faint);">Još nema ocena</span>`}
  </div>`;
}

/* ---------------- ROUTER ---------------- */
async function route(){
  await loadPromos();
  const hash = location.hash.slice(1) || "/";
  const [pathPart, queryPart] = hash.split("?");
  const segs = pathPart.split("/").filter(Boolean);
  const params = new URLSearchParams(queryPart||"");
  if(segs[0]!=="poruke") currentOpenConvId = null; // stale chat pane no longer on screen — stop auto-marking it read
  if(segs[0]!=="oglasi"){ window.__pzmSheet = false; }
  window.scrollTo(0,0);
  updateNavActive(pathPart||"/");
  document.getElementById("app").innerHTML = `<div class="wrap section"><div class="skel" style="height:220px;"></div></div>`;

  let html = "";
  try{
    if(segs.length===0) html = await viewHome();
    else if(segs[0]==="oglasi") html = await viewListings(params);
    else if(segs[0]==="oglas" && segs[1]) html = await viewListingDetail(segs[1]);
    else if(segs[0]==="postavi-oglas") html = await viewWizard(segs[1]?parseInt(segs[1]):1);
    else if(segs[0]==="uredi-oglas" && segs[1]) html = await viewEditListing(segs[1]);
    else if(segs[0]==="moj-pazarime") html = await viewDashboard(segs[1]||"pregled");
    else if(segs[0]==="promocija" && segs[1]==="porudzbina" && segs[2]) html = await viewPromoOrder(segs[2]);
    else if(segs[0]==="promocija" && segs[1]) html = await viewPromote(segs[1]);
    else if(segs[0]==="poruke") html = await viewMessages(params.get("c"));
    else if(segs[0]==="omiljeni") html = await viewFavorites();
    else if(segs[0]==="prodavac" && segs[1]) html = await viewSeller(segs[1]);
    else if(segs[0]==="prodavnice") html = await viewStores(params);
    else if(segs[0]==="prodavnica" && segs[1]) html = await viewStore(segs[1], segs[2]||null, segs[3]||null, params);
    else if(segs[0]==="moja-prodavnica") html = await viewMyStore(segs[1]||"pregled", segs[2]||null);
    else if(segs[0]==="deklaracija") html = await viewDeclaration();
    else if(segs[0]==="kupi" && segs[1]) html = await viewCheckout(segs[1]);
    else if(segs[0]==="porudzbina-primljena") html = viewOrderPlaced();
    else if(segs[0]==="moje-porudzbine") html = await viewMyOrders();
    else if(segs[0]==="prijava") html = viewAuth("login");
    else if(segs[0]==="registracija") html = viewAuth("register");
    else if(segs[0]==="verifikacija") html = viewVerificationPending(params.get("email")||"");
    else if(segs[0]==="bezbednost") html = viewSafety();
    else if(segs[0]==="kako-radi") html = viewHowItWorks();
    else if(segs[0]==="admin") html = await viewAdmin(segs[1]||"dashboard", segs[2]||null, params);
    else if(segs[0]==="kontakt") html = viewContact();
    else if(segs[0]==="faq") html = viewFaq();
    else if(segs[0]==="uslovi") html = viewLegal("uslovi");
    else if(segs[0]==="privatnost") html = viewLegal("privatnost");
    else if(segs[0]==="pravila-oglasavanja") html = viewLegal("pravila-oglasavanja");
    else if(segs[0]==="zastita-kupaca") html = viewLegal("zastita-kupaca");
    else html = view404();
  }catch(e){
    console.error(e);
    html = `<div class="wrap section">${emptyState("⚠️","Greška pri učitavanju","Nešto nije u redu. Pokušaj ponovo.")}</div>`;
  }
  document.getElementById("app").innerHTML = html;
  if(segs[0]==="zastita-kupaca" && params.get("s")){ const t = document.getElementById("zk-"+params.get("s")); if(t) t.scrollIntoView(); }
  enhanceUI();
  refreshFavButtons();
  updateMsgDot();
  clearResendCountdown();
  if(segs[0]==="verifikacija"){
    const email = params.get("email")||"";
    if(email) startResendCountdown(email);
  }
}
function updateNavActive(path){
  document.querySelectorAll("[data-route]").forEach(a=>{
    a.classList.toggle("active", a.getAttribute("data-route")===("/"+(path.split("/")[1]||"")) || (path==="/" && a.getAttribute("data-route")==="/"));
  });
}
async function updateMsgDot(){
  if(!ME.id){ unreadMessages=[]; renderUnreadBadge(); return; }
  await refreshUnreadBadge();
}
function doHeaderSearch(){ const q=document.getElementById("headerSearchInput").value.trim(); location.hash="/oglasi"+(q?`?q=${encodeURIComponent(q)}`:""); }
function doHeroSearch(){ const q=document.getElementById("heroSearchInput").value.trim(); location.hash="/oglasi"+(q?`?q=${encodeURIComponent(q)}`:""); }

/* ---------------- HOME ---------------- */
async function viewHome(){
  const [featured, latest] = await Promise.all([queryFeaturedListings(8), queryActiveListings(8, {excludeFeatured:true})]);
  const homeStores = await fetchActiveStores({limit:4});
  const homeStoreCounts = await fetchStoreCounts(homeStores.map(x=>x.id));
  return `
  <section class="hero">
    <div class="wrap">
      <h1>Sve što tražiš.<br>Na jednom mestu.</h1>
      <p class="sub">Kupi, prodaj ili zameni — jednostavno i brzo.</p>
      <div class="search-bar">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#8A96B0" stroke-width="2" style="margin-left:6px;flex:0 0 auto;"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4-4"/></svg>
        <input id="heroSearchInput" placeholder="Šta tražiš?" onkeydown="if(event.key==='Enter')doHeroSearch()">
        <button class="btn btn-primary" onclick="doHeroSearch()">Pretraži</button>
      </div>
      <div class="pill-row">
        <span class="label">Kategorije:</span>
        ${activeCategories().slice(0,6).map(c=>`<a class="pill" href="#/oglasi?cat=${c.id}">${c.emoji} ${c.name}</a>`).join("")}
      </div>
      <div class="hero-ctas">
        <a href="#/postavi-oglas" class="btn btn-navy">Postavi oglas</a>
        <a href="#/oglasi" class="btn btn-outline">Pregledaj oglase</a>
        <a href="#/prodavnice" class="btn btn-outline">🏪 Prodavnice</a>
      </div>
    </div>
  </section>

  ${featured.length ? `<section class="section wrap" id="featuredSection" style="padding-bottom:0;">
    <div class="section-head"><h2>⭐ Izdvojeni oglasi</h2><a class="link" href="#/oglasi">Svi oglasi →</a></div>
    ${listingGrid(featured)}
  </section>` : ""}

  <section class="section wrap">
    <div class="section-head"><h2>Kategorije</h2></div>
    <div class="cat-grid">
      ${activeCategories().map(c=>`<a class="cat-card" href="#/oglasi?cat=${c.id}"><div class="emoji">${c.emoji}</div><div class="name">${c.name}</div></a>`).join("")}
    </div>
  </section>

  <section class="section wrap" style="padding-bottom:0;">
    <div class="section-head"><h2>Prodavnice</h2><a class="link" href="#/prodavnice">Sve prodavnice →</a></div>
    ${homeStores.length ? storeGrid(homeStores, homeStoreCounts)
      : `<div class="notice" style="display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap;"><span>🏪 Imaš šta da prodaješ? Otvori svoju prodavnicu na PazariMe.</span><a href="#/moja-prodavnica" class="btn btn-primary btn-sm">Otvori prodavnicu</a></div>`}
  </section>

  <section class="section wrap">
    <div class="section-head"><h2>Najnoviji oglasi</h2>${latest.length?`<a class="link" href="#/oglasi">Prikaži sve oglase →</a>`:''}</div>
    ${latest.length
      ? listingGrid(latest) + `<div style="text-align:center; margin-top:24px;"><a href="#/oglasi" class="btn btn-outline">Prikaži sve oglase</a></div>`
      : emptyState("🌱","PazariMe tek počinje.","Budi među prvima koji će postaviti oglas.", `<a href="#/postavi-oglas" class="btn btn-primary" style="margin-top:16px;">Postavi prvi oglas</a>`)
    }
  </section>
  `;
}

/* ---------------- SPECIFICATION FILTERS (search page) ----------------
   Everything is driven by category_specifications rows that the admin marked is_filterable (+ active) for the chosen
   category — nothing is hardcoded per category. URL state: sf_<specId>[_min|_max]. */
async function fetchFilterSpecs(catId, tip){
  if(!catId) return [];
  try{
    const { data, error } = await sb.from("category_specifications").select("*")
      .eq("is_active", true).eq("is_filterable", true).order("sort_order").order("created_at");
    if(error) throw error;
    return (data||[]).filter(s=>{ const c=s.category_ids||[], lt=s.listing_types||[]; return (!c.length || c.includes(catId)) && (!tip || !lt.length || lt.includes(tip)); });
  }catch(e){ console.error("[PazariMe] Učitavanje filtera specifikacija nije uspelo:", e); return []; }
}
function sfSafeDecode(v){ try{ return decodeURIComponent(v); }catch(_){ return v; } }
function sfNum(v){ if(v==null || String(v).trim()==="") return null; const n = Number(String(v).replace(",",".")); return isFinite(n) ? n : null; }
// URL params -> { filters: payload for the DB function, tags: removable chips }
function specFilterFromParams(defs, params){
  const filters = [], tags = [];
  (defs||[]).forEach(s=>{
    const k = "sf_"+s.id, t = s.field_type, un = s.unit ? " "+s.unit : "";
    if(t==="number" || t==="decimal"){
      const mn = sfNum(params.get(k+"_min")), mx = sfNum(params.get(k+"_max"));
      if(mn==null && mx==null) return;
      const f = {id:s.id}; if(mn!=null) f.min = mn; if(mx!=null) f.max = mx; filters.push(f);
      tags.push({label: `${s.label}: ${mn!=null&&mx!=null ? mn+"–"+mx : mn!=null ? "od "+mn : "do "+mx}${un}`, clear:k});
    }else if(t==="select" || t==="multiselect"){
      const opts = specOptions(s);
      const vals = (params.get(k)||"").split(",").filter(Boolean).map(sfSafeDecode).filter(v=>opts.some(o=>o.value===v));
      if(!vals.length) return;
      filters.push({id:s.id, values:vals});
      tags.push({label: `${s.label}: ${vals.map(v=>(opts.find(o=>o.value===v)||{label:v}).label).join(", ")}`, clear:k});
    }else if(t==="boolean"){
      const v = params.get(k); if(v!=="1" && v!=="0") return;
      filters.push({id:s.id, bool: v==="1"});
      tags.push({label: `${s.label}: ${v==="1"?"Da":"Ne"}`, clear:k});
    }else{
      const txt = (params.get(k)||"").trim().slice(0,80); if(!txt) return;
      filters.push({id:s.id, text:txt});
      tags.push({label: `${s.label}: ${txt}`, clear:k});
    }
  });
  return {filters, tags};
}
function specFilterGroupHtml(s, params){
  const k = "sf_"+s.id, t = s.field_type;
  const unit = s.unit ? ` <span style="font-weight:400;color:var(--ink-faint);font-size:11px;">(${esc(s.unit)})</span>` : "";
  const head = `<label>${esc(s.label)}${unit}</label>`;
  if(t==="number" || t==="decimal"){
    return `<div class="f-group">${head}
      <div class="f-range"><input type="number" step="any" inputmode="decimal" placeholder="Od" id="sfmin_${s.id}" value="${esc(params.get(k+"_min")||"")}" onkeydown="if(event.key==='Enter')applySpecRange('${s.id}')"><input type="number" step="any" inputmode="decimal" placeholder="Do" id="sfmax_${s.id}" value="${esc(params.get(k+"_max")||"")}" onkeydown="if(event.key==='Enter')applySpecRange('${s.id}')"></div>
      <button class="btn btn-outline btn-sm" style="margin-top:8px;width:100%" onclick="applySpecRange('${s.id}')">Primeni</button></div>`;
  }
  if(t==="select"){
    const cur = sfSafeDecode((params.get(k)||"").split(",")[0]||"");
    return `<div class="f-group">${head}<select onchange="setSpecSingle('${s.id}',this.value)"><option value="">Sve</option>${specOptions(s).map(o=>`<option value="${esc(o.value)}" ${cur===o.value?"selected":""}>${esc(o.label)}</option>`).join("")}</select></div>`;
  }
  if(t==="multiselect"){
    const cur = (params.get(k)||"").split(",").filter(Boolean).map(sfSafeDecode);
    return `<div class="f-group">${head}${specOptions(s).map((o,i)=>`<label class="f-check"><input type="checkbox" onchange="toggleSpecMulti('${s.id}',${i},this.checked)" ${cur.includes(o.value)?"checked":""}> ${esc(o.label)}</label>`).join("")}</div>`;
  }
  if(t==="boolean"){
    const cur = params.get(k);
    return `<div class="f-group">${head}<select onchange="setSpecSingle('${s.id}',this.value)"><option value="">Svejedno</option><option value="1" ${cur==="1"?"selected":""}>Da</option><option value="0" ${cur==="0"?"selected":""}>Ne</option></select></div>`;
  }
  return `<div class="f-group">${head}<div class="f-range"><input type="text" maxlength="80" placeholder="Pretraži…" id="sftxt_${s.id}" value="${esc(params.get(k)||"")}" onkeydown="if(event.key==='Enter')applySpecText('${s.id}')"></div>
    <button class="btn btn-outline btn-sm" style="margin-top:8px;width:100%" onclick="applySpecText('${s.id}')">Primeni</button></div>`;
}
function specSetParams(fn){ const p = new URLSearchParams(location.hash.split("?")[1]||""); fn(p); location.hash = "/oglasi?"+p.toString(); }
function applySpecRange(id){
  const mn = (document.getElementById("sfmin_"+id)||{}).value, mx = (document.getElementById("sfmax_"+id)||{}).value;
  specSetParams(p=>{ const k="sf_"+id; [["_min",mn],["_max",mx]].forEach(([suf,v])=>{ if(sfNum(v)!=null) p.set(k+suf, String(v).trim()); else p.delete(k+suf); }); });
}
function applySpecText(id){ const v = ((document.getElementById("sftxt_"+id)||{}).value||"").trim(); specSetParams(p=>{ if(v) p.set("sf_"+id, v); else p.delete("sf_"+id); }); }
function setSpecSingle(id, val){ specSetParams(p=>{ if(val==="" || val==null) p.delete("sf_"+id); else p.set("sf_"+id, val); }); }
function toggleSpecMulti(id, idx, checked){
  const s = (window.__sfDefs||{})[id]; if(!s) return;
  const o = specOptions(s)[idx]; if(!o) return;
  specSetParams(p=>{ const k="sf_"+id; let arr=(p.get(k)||"").split(",").filter(Boolean); const enc=encodeURIComponent(o.value);
    if(checked){ if(!arr.includes(enc)) arr.push(enc); } else arr = arr.filter(x=>x!==enc);
    if(arr.length) p.set(k, arr.join(",")); else p.delete(k); });
}
// changing the category drops every specification filter (they belong to the old category) and reloads the filters of the new one
function setCategoryFilter(val){
  const p = new URLSearchParams(location.hash.split("?")[1]||"");
  [...p.keys()].filter(k=>k.startsWith("sf_")).forEach(k=>p.delete(k));
  if(val) p.set("cat", val); else p.delete("cat");
  location.hash = "/oglasi?"+p.toString();
}

/* ---------------- LISTINGS + FILTERS ---------------- */
async function viewListings(params){
  const q = params.get("q")||"";
  const cat = params.get("cat")||"";
  const city = params.get("city")||"";
  const cond = (params.get("cond")||"").split(",").filter(Boolean);
  const priceMin = parseInt(params.get("pmin")||"0");
  const priceMax = parseInt(params.get("pmax")||"0");
  const exchange = params.get("exchange")==="1";
  const tipRaw = params.get("tip")||"";
  const tip = LISTING_TYPE_IDS.includes(tipRaw) ? tipRaw : "";
  const sort = params.get("sort")||"newest";
  const filterSpecs = await fetchFilterSpecs(cat, tip);                       // only active + is_filterable specs of THIS category
  window.__sfDefs = Object.fromEntries(filterSpecs.map(x=>[x.id, x]));
  const sfx = specFilterFromParams(filterSpecs, params);
  const results = await fetchFilteredListings({q,category:cat,city,cond,priceMin,priceMax,exchange,listingType:tip,specFilters:sfx.filters}, sort);
  const matchedStores = q ? await fetchActiveStores({q, limit:4}) : [];
  const matchedCounts = matchedStores.length ? await fetchStoreCounts(matchedStores.map(x=>x.id)) : {};

  const catObj = CATBYID[cat];
  const activeTags = [];
  if(q) activeTags.push({label:`"${q}"`, clear:"q"});
  if(tip) activeTags.push({label:listingTypeLabel(tip), clear:"tip"});
  if(cat) activeTags.push({label:catObj?catObj.name:cat, clear:"cat"});   // clearing it also drops sf_* (no category => no spec filters are applied)
  if(city) activeTags.push({label:city, clear:"city"});
  if(priceMin) activeTags.push({label:`od €${priceMin}`, clear:"pmin"});
  if(priceMax) activeTags.push({label:`do €${priceMax}`, clear:"pmax"});
  cond.forEach(c=>activeTags.push({label:c, clear:"cond", val:c}));
  if(exchange) activeTags.push({label:"Zamena moguća", clear:"exchange"});
  sfx.tags.forEach(t=>activeTags.push(t));

  const isMobileViewport = typeof window!=="undefined" && window.innerWidth <= 980;
  const isPhone = typeof window!=="undefined" && window.innerWidth <= 680;
  const storedFiltersOpen = Store.get("filtersOpen", null);
  // phones: filters are a bottom sheet (transient). tablets/desktop: unchanged persisted panel.
  const filtersOpen = isPhone ? !!window.__pzmSheet : (storedFiltersOpen !== null ? storedFiltersOpen : !isMobileViewport);

  return `
  <div class="wrap section">
    <div style="display:flex; justify-content:flex-end; margin-bottom:12px;">
      <button id="filtersToggleBtn" class="btn btn-outline btn-sm filters-toggle-btn" onclick="toggleFiltersPanel()">
        <span class="ftlabel">${filtersOpen?"Sakrij filtere":"Prikaži filtere"}</span>
        ${activeTags.length?`<span class="chip" style="background:var(--blue);color:#fff;border:none;">${activeTags.length}</span>`:""}
      </button>
    </div>
    <div class="listings-layout${filtersOpen?"":" filters-hidden"}" id="listingsLayout">
      <aside class="filters-panel${filtersOpen?" open":""}" id="filtersPanel">
        <div class="sheet-head"><h3>Filteri</h3><button type="button" class="sheet-close" onclick="toggleFiltersPanel()" aria-label="Zatvori filtere">✕</button></div>
        <div class="f-group"><label>Kategorija</label>
          <select onchange="setCategoryFilter(this.value)">
            <option value="">Sve kategorije</option>
            ${activeCategories().map(c=>`<option value="${c.id}" ${cat===c.id?"selected":""}>${c.emoji} ${c.name}</option>`).join("")}
          </select></div>
        <div class="f-group"><label>Cena (€) <span style="font-weight:400;color:var(--ink-faint);font-size:11px;">· RSD se poredi po ref. kursu</span></label>
          <div class="f-range"><input type="number" placeholder="Od" id="fPmin" value="${priceMin||''}"><input type="number" placeholder="Do" id="fPmax" value="${priceMax||''}"></div>
          <button class="btn btn-outline btn-sm" style="margin-top:8px;width:100%" onclick="applyPriceFilter()">Primeni</button></div>
        <div class="f-group"><label>Lokacija</label>
          <select onchange="location.hash='/oglasi?'+mkFilter('city',this.value)">
            <option value="">Sve lokacije</option>
            ${CITIES.map(c=>`<option value="${c}" ${city===c?"selected":""}>${c}</option>`).join("")}
          </select></div>
        <div class="f-group"><label>Stanje</label>
          ${CONDITIONS.map(c=>`<label class="f-check"><input type="checkbox" onchange="toggleCondFilter('${c}',this.checked)" ${cond.includes(c)?"checked":""}> ${c}</label>`).join("")}
        </div>
        <div class="f-group"><label>Zamena</label>
          <label class="f-check"><input type="checkbox" onchange="location.hash='/oglasi?'+mkFilter('exchange',this.checked?'1':null)" ${exchange?"checked":""}> Moguća zamena</label>
        </div>
        ${filterSpecs.length ? `<div class="f-group"><label style="color:var(--ink);">Specifikacije${catObj?` · ${esc(catObj.name)}`:""}</label></div>${filterSpecs.map(x=>specFilterGroupHtml(x, params)).join("")}` : ""}
        ${activeTags.length?`<div class="f-group"><a href="#/oglasi" class="btn btn-ghost btn-sm" style="padding-left:0;">Resetuj filtere</a></div>`:""}
        <div class="sheet-foot"><button type="button" class="btn btn-primary btn-block" onclick="toggleFiltersPanel()">Prikaži ${results.length} oglasa</button></div>
      </aside>
      <div class="sheet-backdrop" onclick="toggleFiltersPanel()"></div>
      <div>
        <div class="type-tabs" role="tablist" aria-label="Tip oglasa">
          ${[["","Svi"]].concat(LISTING_TYPES.map(x=>[x.id,x.label])).map(([v,lab])=>`<button type="button" role="tab" aria-selected="${tip===v}" class="type-tab${tip===v?" active":""}" onclick="location.hash='/oglasi?'+mkFilter('tip','${v}')">${lab}</button>`).join("")}
        </div>
        <div class="results-bar">
          <div>
            <div class="count"><strong>${results.length}</strong> oglasa ${q?`za „${esc(q)}“`:""}</div>
            <a class="rank-info" href="#/zastita-kupaca?s=rangiranje">Kako se određuje redosled oglasa</a>
            ${activeTags.length?`<div class="active-filters">${activeTags.map(t=>`<span class="tag-x">${esc(t.label)}<button onclick="clearTag('${t.clear}','${t.val||''}')">✕</button></span>`).join("")}</div>`:""}
          </div>
          <select onchange="location.hash='/oglasi?'+mkFilter('sort',this.value)">
            <option value="newest" ${sort==="newest"?"selected":""}>Najnoviji</option>
            <option value="cheap" ${sort==="cheap"?"selected":""}>Najjeftiniji</option>
            <option value="expensive" ${sort==="expensive"?"selected":""}>Najskuplji</option>
            <option value="views" ${sort==="views"?"selected":""}>Najgledaniji</option>
          </select>
        </div>
        ${matchedStores.length?`<div style="margin-bottom:18px;"><h3 style="font-size:14px; margin-bottom:10px;">Prodavnice za „${esc(q)}“</h3>${storeGrid(matchedStores, matchedCounts)}</div>`:""}
        ${results.length ? listingGrid(results) : emptyState("🌱", q||cat||city||cond.length ? "Nema rezultata za izabrane filtere." : "Još nema oglasa.", q||cat||city||cond.length ? "Pokušaj da promeniš pretragu ili ukloniš neke filtere." : "Budi prvi koji će postaviti oglas u ovoj kategoriji.", `<a href="#/postavi-oglas" class="btn btn-primary" style="margin-top:14px;">Postavi oglas</a>`)}
      </div>
    </div>
  </div>`;
}
function mkFilter(key,val){ const p=new URLSearchParams(location.hash.split("?")[1]||""); if(val===null||val==="")p.delete(key); else p.set(key,val); return p.toString(); }
function applyPriceFilter(){
  const min=document.getElementById("fPmin").value, max=document.getElementById("fPmax").value;
  const p=new URLSearchParams(mkFilter("pmin", min||null));
  if(max) p.set("pmax",max); else p.delete("pmax");
  location.hash="/oglasi?"+p.toString();
}
function toggleCondFilter(cond, checked){
  const p=new URLSearchParams(location.hash.split("?")[1]||"");
  let arr=(p.get("cond")||"").split(",").filter(Boolean);
  if(checked) arr.push(cond); else arr=arr.filter(c=>c!==cond);
  if(arr.length) p.set("cond",arr.join(",")); else p.delete("cond");
  location.hash="/oglasi?"+p.toString();
}
function clearTag(key,val){
  const p=new URLSearchParams(location.hash.split("?")[1]||"");
  if(key==="cond"){ let arr=(p.get("cond")||"").split(",").filter(Boolean).filter(c=>c!==val); if(arr.length)p.set("cond",arr.join(",")); else p.delete("cond"); }
  else if(key==="cat"){ p.delete("cat"); [...p.keys()].filter(k=>k.startsWith("sf_")).forEach(k=>p.delete(k)); }   // no category => its spec filters go too
  else if(key.startsWith("sf_")){ [...p.keys()].filter(k=>k===key || k.startsWith(key+"_")).forEach(k=>p.delete(k)); }   // spec filter: value / _min / _max
  else p.delete(key);
  location.hash="/oglasi?"+p.toString();
}
// Pure DOM class toggle — no re-render, no refetch, so the listings and
// all selected filter values stay exactly as they were.
function toggleFiltersPanel(){
  const panel = document.getElementById("filtersPanel");
  const layout = document.getElementById("listingsLayout");
  const btn = document.getElementById("filtersToggleBtn");
  if(!panel || !layout) return;
  const nowOpen = !panel.classList.contains("open");
  panel.classList.toggle("open", nowOpen);
  layout.classList.toggle("filters-hidden", !nowOpen);
  if(window.innerWidth <= 680) window.__pzmSheet = nowOpen;   // phone bottom sheet: transient state
  else Store.set("filtersOpen", nowOpen);
  if(btn){ const label = btn.querySelector(".ftlabel"); if(label) label.textContent = nowOpen ? "Sakrij filtere" : "Prikaži filtere"; }
}

/* ---------------- LISTING DETAIL ---------------- */
async function viewListingDetail(id){
  const l = await fetchListing(id);
  if(!l || (l.status!=="active" && l.seller_id!==ME.id && !isAdmin())){
    return `<div class="wrap section">${emptyState("🔎","Oglas nije pronađen","Oglas je možda uklonjen, prodat ili pauziran.", `<a href="#/oglasi" class="btn btn-primary" style="margin-top:14px;">Nazad na oglase</a>`)}</div>`;
  }
  if(l.status==="active") recordView(id);
  const [profiles, sellerSt, similarAll, sellerOther, rep, myRating, storeInfo, specRows] = await Promise.all([
    resolveProfiles([l.seller_id]),
    fetchSellerStatuses([l.seller_id]),
    fetchFilteredListings({category:l.category, listingType:listingTypeOf(l)}, "newest").then(all=>all.filter(x=>x.id!==l.id).slice(0,4)),
    fetchSellerActiveListings(l.seller_id).then(list=>list.filter(x=>x.id!==l.id).slice(0,4)),
    fetchReputation(l.seller_id),
    fetchMyRatingFor(l.seller_id),
    l.store_id ? (STORE_CACHE[l.store_id] && STORE_CACHE[l.store_id].owner_id ? Promise.resolve(STORE_CACHE[l.store_id]) : fetchStoreById(l.store_id)) : Promise.resolve(null),
    fetchListingSpecs(l),
  ]);
  if(storeInfo) STORE_CACHE[storeInfo.id] = storeInfo;
  const seller = profiles[l.seller_id] || {id:l.seller_id, name:"Korisnik", avatarUrl:genericAvatar(l.seller_id)};
  const isFav = favoriteIds.has(l.id);
  const cat = CATBYID[l.category];
  const images = l.images || [];
  const cover = images.length ? images[Math.min(l.cover_index||0, images.length-1)] : null;
  const galleryStart = images.length ? Math.min(l.cover_index||0, images.length-1) : 0;
  galleryState = { images: images.filter(Boolean), i: galleryStart };
  const isMine = ME.id===l.seller_id;
  const ltype = listingTypeOf(l);
  const isSale = ltype==="offer_sale";

  return `
  <div class="wrap section">
    <div style="font-size:12.5px; color:var(--ink-faint); margin-bottom:16px;">
      ${storeInfo ? `<a href="#/prodavnice">Prodavnice</a> / <a href="#/prodavnica/${esc(storeInfo.slug)}">${esc(storeInfo.name)}</a>` : `<a href="#/oglasi">Oglasi</a> / <a href="#/oglasi?cat=${l.category}">${cat?cat.name:l.category}</a>`} / ${esc(l.title)}
    </div>
    <div class="detail-grid">
      <div class="detail-gallery">
        <div class="gallery-main${images.length?" zoomable":""}" id="galleryMain"${images.length?` role="button" tabindex="0" aria-label="Uvećaj sliku" onclick="openGalleryLightbox()" onkeydown="galleryKey(event)"`:""}>${cover?`<img id="galleryImg" src="${esc(cover)}" style="width:100%;height:100%;object-fit:cover;" alt="${esc(l.title)}">`:(cat?cat.emoji:"📦")}${images.length?`<span class="zoom-hint" aria-hidden="true">⤢ Uvećaj</span>`:""}</div>
        ${images.length>1?`<div class="gallery-thumbs">${images.map((src,i)=>`<div class="t ${i===galleryStart?'active':''}" role="button" tabindex="0" aria-label="Slika ${i+1} od ${images.length}" onclick="galleryShow(${i})" onkeydown="if(event.key==='Enter'){galleryShow(${i})}"><img src="${esc(src)}" style="width:100%;height:100%;object-fit:cover;border-radius:8px;" alt=""></div>`).join("")}</div>`:""}
      </div>
      <div class="detail-info">
        <div style="margin-top:30px;">
          <h3 style="font-size:16px; margin-bottom:12px;">Karakteristike</h3>
          <table class="spec-table">
            ${(isSale||l.condition)?`<tr><td>Stanje</td><td>${esc(l.condition||"—")}</td></tr>`:""}
            ${l.brand?`<tr><td>Brend</td><td>${esc(l.brand)}</td></tr>`:""}
            ${specRowsHtml(specRows)}
            <tr><td>Kategorija</td><td>${cat?cat.name:l.category}</td></tr>
          </table>
        </div>

        <div style="margin-top:26px;">
          <h3 style="font-size:16px; margin-bottom:10px;">Opis</h3>
          <p style="font-size:14px; color:var(--ink-dim); line-height:1.7; white-space:pre-wrap;">${esc(l.description||(isSale?"Prodavac nije dodao opis.":"Korisnik nije dodao opis."))}</p>
        </div>

        ${isSale?`<div style="margin-top:26px; display:flex; gap:24px; flex-wrap:wrap;">
          <div><div style="font-size:12px;color:var(--ink-faint);font-weight:600;">DOSTAVA</div><div style="font-size:13.5px;margin-top:4px;">${esc(l.delivery||"—")}</div></div>
          <div><div style="font-size:12px;color:var(--ink-faint);font-weight:600;">ZAMENA</div><div style="font-size:13.5px;margin-top:4px;">${l.exchange?"Moguća":"Nije moguća"}</div></div>
        </div>`:""}

        ${reportFormOpenFor===l.id ? reportFormHtml(l.id) : ""}
        ${similarAll.length?`<div style="margin-top:40px;"><h3 style="font-size:16px; margin-bottom:14px;">Slični oglasi</h3><div class="listing-grid">${similarAll.map(listingCard).join("")}</div></div>`:""}
      </div>

      <div class="detail-side">
        <div class="price-box${isPremiumNow(l)?" price-box-premium":""}">
          ${isPremiumNow(l)?'<span class="badge-premium-inline">PREMIUM OGLAS</span>':""}
          <div class="price">${listingPriceText(l)}</div>
          <h2 style="font-size:17px; margin-top:8px;">${esc(l.title)}</h2>
          <div style="display:flex; gap:8px; margin-top:8px; flex-wrap:wrap;">
            ${listingTypeBadgeHtml(ltype)}${(isSale||l.condition)?`<span class="chip">${esc(l.condition||"")}</span>`:""}<span class="chip">📍 ${esc(l.city||"")}</span><span class="chip">👁 ${l.views_count||0} pregleda</span>
            ${storeInfo?(productUnavailable(l)?'<span class="chip" style="color:var(--danger);">Nedostupno</span>':(l.stock!=null?`<span class="chip" style="color:var(--success);">Na stanju: ${l.stock}</span>`:'<span class="chip" style="color:var(--success);">Dostupno</span>')):""}
            ${l.status!=="active"?`<span class="chip" style="color:var(--warn);">${statusLabel(l.status)}</span>`:""}
          </div>
          <div style="font-size:12px; color:var(--ink-faint); margin-top:8px;">Objavljeno ${fmtDate(l.created_at)}</div>

          ${isMine ? "" : `<div style="display:flex; gap:8px; margin-top:18px;${l.store_id?" flex-direction:column;":""}">${l.store_id ? ((l.status!=="active"||productUnavailable(l)) ? `<button class="btn btn-primary btn-block" disabled>Nedostupno</button>` : `<a class="btn btn-primary btn-block" href="#/kupi/${esc(l.id)}">🛒 Kupi</a>`) : ""}<button class="btn ${l.store_id?"btn-outline":"btn-primary"} btn-block" onclick="openContactSeller('${l.id}')">${contactLabelFor(ltype)}</button></div>`}
          <div style="display:flex; gap:8px; margin-top:8px;">
            <button class="btn btn-outline" style="flex:1" data-fav-id="${l.id}" onclick="toggleFavorite('${l.id}')">${isFav?"✓ Sačuvano":"♡ Sačuvaj oglas"}</button>
            <button class="btn btn-ghost" onclick="toggleReportForm('${l.id}')" title="Prijavi oglas">🚩 Prijavi</button>
          </div>

          ${storeBlockHtml(storeInfo)}
          <a href="#/prodavac/${l.seller_id}" class="seller-card">
            <div class="avatar-wrap"><img src="${seller.avatarUrl}" class="avatar" style="object-fit:cover;" alt="">${presenceDotHtml(seller.lastSeen)}</div>
            <div style="flex:1;">
              <div style="font-weight:600; font-size:13.5px;">${esc(seller.name)}</div>
              <div style="font-size:11px; color:var(--ink-faint); margin-bottom:2px;">${formatPresence(seller.lastSeen).label}</div>
              ${ratingWidget(l.seller_id, rep, myRating)}
            </div>
          </a>
          ${sellerStatusBoxHtml(sellerSt[l.seller_id])}
        </div>

        ${sellerOther.length?`<div style="margin-top:20px;"><h3 style="font-size:14px; margin-bottom:10px;">Ostali oglasi prodavca</h3><div style="display:flex; flex-direction:column; gap:8px;">${sellerOther.map(x=>`<a href="${listingHref(x)}" class="list-row" style="margin-bottom:0;"><div class="thumb-sm">${x.images&&x.images.length?`<img src="${x.images[0]}" style="width:100%;height:100%;object-fit:cover;border-radius:9px;">`:(CATBYID[x.category]?CATBYID[x.category].emoji:"📦")}</div><div class="info"><div class="t">${esc(x.title)}</div><div class="stats">${fmtPrice(x.price,x.currency)}</div></div></a>`).join("")}</div></div>`:""}
      </div>
    </div>
  </div>`;
}
function toggleReportForm(id){ reportFormOpenFor = (reportFormOpenFor===id)?null:id; route(); }
function reportFormHtml(listingId){
  const reasons = ["Prevara","Lažan proizvod","Netačan status prodavca","Pogrešna kategorija","Neprimeren sadržaj","Duplikat","Sumnjivo ponašanje","Ostalo"];
  return `<div style="margin-top:24px; background:var(--danger-bg); border:1px solid #f3c7c7; border-radius:var(--radius-m); padding:16px;">
    <h4 style="font-size:14px; margin-bottom:10px;">Prijavi ovaj oglas</h4>
    <div class="form-group"><label>Razlog</label><select id="reportReason">${reasons.map(r=>`<option>${r}</option>`).join("")}</select></div>
    <div class="form-group"><label>Objašnjenje (opciono)</label><textarea id="reportDesc" style="min-height:60px;"></textarea></div>
    <div style="display:flex; gap:8px;"><button id="reportSubmitBtn" class="btn btn-danger btn-sm" onclick="submitReport('${listingId}')">Pošalji prijavu</button><button class="btn btn-ghost btn-sm" onclick="toggleReportForm('${listingId}')">Otkaži</button></div>
  </div>`;
}
const submitReport = guarded("report", async (listingId)=>{
  if(!ME.id){ requireAuthRedirect("Prijavi se da bi prijavio oglas"); return; }
  const btn = document.getElementById("reportSubmitBtn");
  const reason = document.getElementById("reportReason").value;
  const description = document.getElementById("reportDesc").value.trim();
  if(btn){ btn.disabled = true; btn.textContent = "Slanje..."; }
  try{
    const l = await fetchListing(listingId);
    const { error } = await sb.from("reports").insert({
      reporter_id: ME.id, listing_id: listingId, reported_user_id: l ? l.seller_id : null,
      reason, description: description || null,
    });
    if(error) throw error;
    toast("Hvala! Oglas je prijavljen administraciji na proveru.");
    reportFormOpenFor = null; route();
  }catch(e){
    toast("Greška pri slanju prijave — pokušaj ponovo");
    if(btn){ btn.disabled=false; btn.textContent="Pošalji prijavu"; }
  }
});
async function openContactSeller(listingId){
  if(!ME.id){ requireAuthRedirect("Prijavi se da bi kontaktirao prodavca"); return; }
  const l = await fetchListing(listingId);
  if(!l) return;
  if(l.seller_id===ME.id){ toast("Ovo je tvoj sopstveni oglas"); return; }
  try{
    const { data: existing } = await sb.from("conversations").select("id").eq("listing_id", listingId).eq("buyer_id", ME.id).maybeSingle();
    let convId = existing && existing.id;
    if(!convId){
      const { data, error } = await sb.from("conversations").insert({ listing_id: listingId, buyer_id: ME.id, seller_id: l.seller_id }).select("id").single();
      if(error) throw error;
      convId = data.id;
    }
    location.hash = "/poruke?c="+convId;
  }catch(e){ toast("Greška pri otvaranju razgovora"); }
}

/* ---------------- SELLER PROFILE ---------------- */
async function viewSeller(id){
  const [profiles, listings, rep, myRating, sellerSt, sellerStore] = await Promise.all([
    resolveProfiles([id]), fetchSellerActiveListings(id), fetchReputation(id), fetchMyRatingFor(id), fetchSellerStatuses([id]),
    sb.from("stores").select("*").eq("owner_id", id).eq("status","active").maybeSingle().then(r=>r.data||null, ()=>null)
  ]);
  const seller = profiles[id] || {id,name:"Korisnik",avatarUrl:genericAvatar(id),createdAt:null};
  return `
  <div class="wrap section">
    <div style="display:flex; gap:20px; align-items:center; flex-wrap:wrap;">
      <div class="avatar-wrap"><img src="${seller.avatarUrl}" class="avatar lg" style="object-fit:cover;" alt="">${presenceDotHtml(seller.lastSeen)}</div>
      <div style="flex:1;">
        <h2 style="font-size:22px;">${esc(seller.name)}</h2>
        <div style="font-size:12.5px; color:var(--ink-faint); margin:2px 0 6px;">${formatPresence(seller.lastSeen).label}</div>
        ${ratingWidget(id, rep, myRating)}
        ${sellerStore?`<a href="#/prodavnica/${esc(sellerStore.slug)}" class="chip" style="margin-top:10px; padding:5px 12px; font-size:12.5px; background:var(--blue-dim); color:var(--blue); border-color:transparent;">🏪 Prodavnica: ${esc(sellerStore.name)} →</a>`:""}
        <div style="font-size:13px; color:var(--ink-faint); margin-top:8px;">${listings.length} aktivnih oglasa${seller.createdAt?` · član od ${new Date(seller.createdAt).getFullYear()}.`:""}</div>
      </div>
    </div>
    <div style="margin-top:16px; max-width:640px;">${sellerStatusBoxHtml(sellerSt[id])}</div>
    <div class="tabs" style="margin-top:26px;"><button class="active">Oglasi (${listings.length})</button></div>
    ${listingGrid(listings)}
  </div>`;
}

/* ---------------- IMAGE UPLOAD (Supabase Storage) ---------------- */
function compressImageToBlob(file, maxDim=1600, quality=0.78){
  return new Promise((resolve,reject)=>{
    const reader = new FileReader();
    reader.onerror = ()=>reject(reader.error);
    reader.onload = ()=>{
      const img = new Image();
      img.onload = ()=>{
        let w=img.width, h=img.height;
        if(w>h){ if(w>maxDim){h=Math.round(h*maxDim/w); w=maxDim;} } else { if(h>maxDim){w=Math.round(w*maxDim/h); h=maxDim;} }
        const canvas = document.createElement("canvas");
        canvas.width=w; canvas.height=h;
        canvas.getContext("2d").drawImage(img,0,0,w,h);
        canvas.toBlob(blob=>{ blob?resolve(blob):reject(new Error("Neuspešna obrada slike")); }, "image/jpeg", quality);
      };
      img.onerror = ()=>reject(new Error("Neispravna slika"));
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}
async function uploadListingPhoto(file){
  const blob = await compressImageToBlob(file);
  const path = `${ME.id}/${wizState.draftId}/${crypto.randomUUID()}.jpg`;
  const { error } = await sb.storage.from("listing-images").upload(path, blob, { contentType:"image/jpeg", upsert:false });
  if(error) throw error;
  const { data } = sb.storage.from("listing-images").getPublicUrl(path);
  return { url: data.publicUrl, path };
}

/* ---------------- CREATE LISTING WIZARD ---------------- */
const WIZ_LABELS = {kategorija:"Kategorija", tip:"Tip oglasa", brend:"Podkategorija", detalji:"Detalji", specifikacije:"Specifikacije", cena:"Cena", lokacija:"Lokacija", dostava:"Dostava", zamena:"Zamena", opis:"Opis", fotografije:"Fotografije", pregled:"Pregled"};
let wizSpecDefs = [];
function freshWizState(){ return {draftId: crypto.randomUUID(), category:"", listingType:"", specValues:{}, subBrand:"", title:"", condition:"", price:"", currency:"RSD", city:"", delivery:"", exchange:"", desc:"", photos:[], coverIndex:0, uploading:false}; }
let wizState = Store.get("wizDraft", null) || freshWizState();
if(!wizState.draftId) wizState.draftId = crypto.randomUUID();
if(!wizState.specValues) wizState.specValues = {};
if(wizState.listingType===undefined) wizState.listingType = "";
function wizSave(){ Store.set("wizDraft", wizState); }
// Steps depend on the listing type: only plain sales ask for brand, condition, delivery and exchange.
function wizSteps(){
  const t = wizState.listingType || "offer_sale";
  const keys = ["kategorija","tip"];
  if(t==="offer_sale") keys.push("brend");
  keys.push("detalji");
  if(wizSpecDefs.length) keys.push("specifikacije");
  keys.push("cena","lokacija");
  if(t==="offer_sale") keys.push("dostava","zamena");
  keys.push("opis","fotografije","pregled");
  return keys;
}

async function viewWizard(step){
  if(!ME.id){
    Store.set("postLoginRedirect", "#/postavi-oglas/"+(step||1));
    return `<div class="wrap"><div class="auth-card">
      <h2>Prijava potrebna</h2>
      <p class="sub">Nalog je potreban da bi postavio oglas na PazariMe.</p>
      <a href="#/prijava" class="btn btn-primary btn-block">Prijavi se</a>
      <a href="#/registracija" class="btn btn-outline btn-block" style="margin-top:8px;">Napravi nalog</a>
    </div></div>`;
  }
  if(ME.traderStatus==="undeclared") return declarationGateHtml("#/postavi-oglas/"+(step||1), "objavljivanje oglasa");
  wizSpecDefs = (wizState.category && wizState.listingType) ? await fetchCategorySpecs(wizState.category, wizState.listingType) : [];
  const steps = wizSteps();
  step = Math.min(Math.max(step,1), steps.length+1);
  if(step === steps.length+1) return wizardSuccess();
  const guardIdx = !wizState.category ? 0 : !wizState.listingType ? 1 : -1;
  if(guardIdx>=0 && step-1>guardIdx){ location.hash = "/postavi-oglas/"+(guardIdx+1); return ""; }
  const key = steps[step-1];
  const t = wizState.listingType || "offer_sale";
  const cat = CATBYID[wizState.category];
  let body = "";
  if(key==="kategorija"){
    body = `<h2>Izaberi kategoriju</h2><p class="sub" style="text-align:left;margin-bottom:20px;">U kojoj kategoriji je tvoj oglas?</p>
      <div class="choice-grid">${activeCategories().map(c=>`<div class="choice-card ${wizState.category===c.id?'selected':''}" onclick="wizSetCategory('${c.id}')"><div class="emoji">${c.emoji}</div>${c.name}</div>`).join("")}</div>`;
  } else if(key==="tip"){
    body = `<h2>Tip oglasa</h2><p class="sub" style="text-align:left;margin-bottom:20px;">Šta želiš da uradiš?</p>
      <div class="choice-grid" style="grid-template-columns:1fr 1fr;">${LISTING_TYPES.map(x=>`<div class="choice-card ${wizState.listingType===x.id?'selected':''}" onclick="wizSetType('${x.id}')"><div class="emoji">${x.emoji}</div>${x.label}<div style="font-size:11.5px;color:var(--ink-faint);font-weight:400;margin-top:4px;">${x.hint}</div></div>`).join("")}</div>`;
  } else if(key==="brend"){
    body = `<h2>Izaberi brend</h2><p class="sub" style="text-align:left;margin-bottom:20px;">Podkategorija / brend za ${cat?cat.name.toLowerCase():"proizvod"}</p>
      <div class="choice-grid">${(cat?cat.brands:[]).map(b=>`<div class="choice-card ${wizState.subBrand===b?'selected':''}" onclick="wizSet('subBrand','${b}')">${b}</div>`).join("")}</div>`;
  } else if(key==="detalji"){
    const ph = {offer_sale:"npr. iPhone 13 mini 128GB", wanted_purchase:"npr. iPhone 13 mini 128GB", service_offer:"npr. Krečenje stanova", service_request:"npr. Potreban električar"}[t];
    body = `<h2>${t==="offer_sale"||t==="wanted_purchase"?"Detalji proizvoda":"Detalji usluge"}</h2>
      <div class="form-group"><label>Naziv oglasa</label><input type="text" value="${esc(wizState.title)}" oninput="wizState.title=this.value; wizFieldChanged('detalji');" placeholder="${ph}"></div>
      ${t==="offer_sale"?`<div class="form-group"><label>Stanje</label><select onchange="wizState.condition=this.value; wizFieldChanged('detalji');"><option value="">Izaberi</option>${CONDITIONS.map(c=>`<option ${wizState.condition===c?"selected":""}>${c}</option>`).join("")}</select></div>`:""}`;
  } else if(key==="specifikacije"){
    body = `<h2>Specifikacije</h2><p class="sub" style="text-align:left;margin-bottom:16px;">Polja označena zvezdicom (*) su obavezna.</p>${specFieldsHtml("wiz", wizSpecDefs, wizState.specValues)}`;
  } else if(key==="cena"){
    body = `<h2>${t==="offer_sale"?"Cena":(t==="service_offer"?"Cena usluge":"Budžet")}</h2><div class="form-group"><label id="wizPriceLabel">${priceLabelFor(t, wizState.currency)}</label><div style="display:flex; gap:8px; align-items:stretch;"><input type="number" inputmode="numeric" style="flex:1 1 140px; min-width:0;" value="${esc(wizState.price)}" oninput="wizState.price=this.value; wizFieldChanged('cena');" placeholder="${wizState.currency==='EUR'?'npr. 450':'npr. 45000'}">${currencySelectHtml("wizCurrency", wizState.currency, "wizSetCurrency(this.value)")}</div></div>
      ${t!=="offer_sale"?`<p style="font-size:12px;color:var(--ink-faint);">Ostavi prazno ako je cena „po dogovoru“.</p>`:""}`;
  } else if(key==="lokacija"){
    body = `<h2>Lokacija</h2><div class="form-group"><label>Grad</label><select onchange="wizState.city=this.value; wizFieldChanged('lokacija');"><option value="">Izaberi grad</option>${CITIES.map(c=>`<option ${wizState.city===c?"selected":""}>${c}</option>`).join("")}</select></div>`;
  } else if(key==="dostava"){
    body = `<h2>Dostava</h2><div class="choice-grid" style="grid-template-columns:1fr;">${["Lično preuzimanje","Kurirska služba","Obe opcije"].map(o=>`<div class="choice-card" style="text-align:left; padding:14px 16px;${wizState.delivery===o?'border-color:var(--blue);background:var(--blue-dim);':''}" onclick="wizSet('delivery','${o}')">${o}</div>`).join("")}</div>`;
  } else if(key==="zamena"){
    body = `<h2>Zamena</h2><div class="choice-grid" style="grid-template-columns:1fr 1fr;">
        <div class="choice-card ${wizState.exchange==='Moguća'?'selected':''}" onclick="wizSet('exchange','Moguća')">Moguća</div>
        <div class="choice-card ${wizState.exchange==='Nije moguća'?'selected':''}" onclick="wizSet('exchange','Nije moguća')">Nije moguća</div></div>`;
  } else if(key==="opis"){
    const dl = {offer_sale:"Opiši proizvod detaljno", wanted_purchase:"Opiši šta tačno tražiš", service_offer:"Opiši uslugu koju nudiš", service_request:"Opiši šta ti je potrebno"}[t];
    body = `<h2>Opis</h2><div class="form-group"><label>${dl}</label><textarea oninput="wizState.desc=this.value; wizFieldChanged('opis');">${esc(wizState.desc)}</textarea></div>`;
  } else if(key==="fotografije"){
    body = `<h2>Fotografije</h2><p class="sub" style="text-align:left;margin-bottom:16px;">Dodaj do 10 pravih fotografija${t!=="offer_sale"?" (opciono)":""}. Zvezdicom označi naslovnu.</p>
      <div style="display:flex; gap:8px; margin-bottom:14px; flex-wrap:wrap;">
        <label class="btn btn-outline btn-sm" style="cursor:pointer;">📷 Snimi fotografiju<input type="file" accept="image/jpeg,image/png,image/webp" capture="environment" style="display:none" onchange="handleFiles(this.files)"></label>
        <label class="btn btn-outline btn-sm" style="cursor:pointer;">🖼️ Izaberi iz galerije<input type="file" accept="image/jpeg,image/png,image/webp" multiple style="display:none" onchange="handleFiles(this.files)"></label>
        ${wizState.uploading?`<span style="font-size:12.5px; color:var(--ink-faint); align-self:center;">Otpremanje...</span>`:""}
      </div>
      <div class="upload-grid" ondragover="event.preventDefault();" ondrop="handleDrop(event)">
        ${wizState.photos.map((p,i)=>photoSlotHtml(p.url,i,i===wizState.coverIndex,"setCoverPhoto","movePhoto","removePhoto","wizPreview")).join("")}
        ${wizState.photos.length<10?`<label class="upload-slot" style="cursor:pointer;">+<input type="file" accept="image/jpeg,image/png,image/webp" multiple style="display:none" onchange="handleFiles(this.files)"></label>`:""}
      </div>`;
  } else if(key==="pregled"){
    body = `<h2>Pregled oglasa</h2><p class="sub" style="text-align:left;margin-bottom:16px;">Proveri podatke pre objavljivanja. Oglas će odmah biti vidljiv svim korisnicima.</p>
      <div class="card" style="max-width:280px;">
        <div class="thumb">${wizState.photos.length?`<img src="${(wizState.photos[wizState.coverIndex]||wizState.photos[0]).url}" style="width:100%;height:100%;object-fit:cover;">`:`<span>${cat?cat.emoji:"📦"}</span>`}</div>
        <div class="body"><div class="price">${listingPriceText({listing_type:t, price:parseInt(wizState.price)||0, currency:wizState.currency})}</div><div class="title">${esc(wizState.title||"(bez naziva)")}</div><div class="cond">${isServiceType(t)?listingTypeBadgeHtml(t):(t==="offer_sale"?`<span class="chip">${esc(wizState.condition||"—")}</span>`:"")}</div><div class="meta"><span>${wizState.city||"—"}</span><span>sada</span></div></div>
      </div>`;
  }
  const canNext = wizCanProceed(key);
  const last = step===steps.length;
  return `<div class="wrap section">
    <div class="wizard-steps">${steps.map((k,i)=>`<div class="s ${i+1<step?'done':i+1===step?'active':''}">${i+1}. ${WIZ_LABELS[k]}</div>`).join("")}</div>
    <div class="wizard-card">
      ${body}
      <div class="wizard-actions">
        ${step>1?`<a href="#/postavi-oglas/${step-1}" class="btn btn-outline">Nazad</a>`:`<span></span>`}
        ${!last
          ? `<button id="wizNextBtn" class="btn btn-primary" ${canNext?'':'disabled'} style="${canNext?'':'opacity:.5;'}" onclick="wizGo(${step+1})">Dalje</button>`
          : `<button id="wizPublishBtn" class="btn btn-primary" onclick="wizPublish()">Objavi oglas</button>`}
      </div>
      ${!canNext && key!=="fotografije" ? `<p style="font-size:12px; color:var(--ink-faint); margin-top:10px;">Popuni obavezno polje da bi nastavio.</p>` : ""}
      ${!canNext && key==="fotografije" ? `<p style="font-size:12px; color:var(--ink-faint); margin-top:10px;">Dodaj bar jednu fotografiju da bi nastavio.</p>` : ""}
    </div>
  </div>`;
}
// Every field on every step goes through this, so "Dalje" unlocks the
// moment requirements are met — never only after navigating Back/Next.
function wizSetCurrency(v){ wizState.currency = v==="EUR" ? "EUR" : "RSD"; const l = document.getElementById("wizPriceLabel"); if(l) l.textContent = priceLabelFor(wizState.listingType, wizState.currency); wizFieldChanged("cena"); }
function wizFieldChanged(key){
  wizSave();
  const btn = document.getElementById("wizNextBtn");
  if(btn){
    const ok = wizCanProceed(key);
    btn.disabled = !ok;
    btn.style.opacity = ok ? "1" : ".5";
  }
}
function wizSet(key,val){ wizState[key]=val; wizSave(); route(); }
function wizSetCategory(id){
  if(wizState.category!==id){ wizState.category = id; wizState.subBrand = ""; wizState.specValues = {}; }
  wizSave(); route();
}
function wizSetType(t){
  if(wizState.listingType!==t){ wizState.listingType = t; wizState.specValues = {}; }
  wizSave(); route();
}
function wizGo(step){ const keys = wizSteps(); if(!wizCanProceed(keys[step-2])) return; wizSave(); location.hash="/postavi-oglas/"+step; }
function wizCanProceed(key){
  const t = wizState.listingType;
  if(key==="kategorija") return !!wizState.category;
  if(key==="tip") return LISTING_TYPE_IDS.includes(t);
  if(key==="brend") return !!wizState.subBrand;
  if(key==="detalji") return !!wizState.title && (t!=="offer_sale" || !!wizState.condition);
  if(key==="specifikacije") return !specMissing(wizSpecDefs, wizState.specValues) && !specBadNumber(wizSpecDefs, wizState.specValues);
  if(key==="cena") return t!=="offer_sale" ? (wizState.price==="" || Number(wizState.price)>=0) : (!!wizState.price && Number(wizState.price)>0);
  if(key==="lokacija") return !!wizState.city;
  if(key==="dostava") return !!wizState.delivery;
  if(key==="zamena") return !!wizState.exchange;
  if(key==="opis") return wizState.desc.length>9;
  if(key==="fotografije") return t!=="offer_sale" || wizState.photos.length>0;
  return true;
}
async function handleFiles(fileList){
  const room = 10 - wizState.photos.length;
  if(room<=0){ toast("Dostigao si maksimalan broj fotografija (10)"); return; }
  const files = Array.from(fileList).slice(0, room);
  wizState.uploading = true; route();
  for(const f of files){
    if(!/^image\/(jpeg|png|webp)$/.test(f.type)){ toast("Podržani formati: JPG, PNG, WEBP"); continue; }
    if(f.size > 20*1024*1024){ toast("Fotografija je prevelika (maks 20MB)"); continue; }
    try{ wizState.photos.push(await uploadListingPhoto(f)); }
    catch(e){ console.error(e); toast("Greška pri otpremanju fotografije"); }
  }
  wizState.uploading = false;
  wizSave(); route();
}
function handleDrop(ev){ ev.preventDefault(); if(ev.dataTransfer && ev.dataTransfer.files) handleFiles(ev.dataTransfer.files); }
function setCoverPhoto(i){ wizState.coverIndex=i; wizSave(); route(); }
function movePhoto(i,dir){
  const j=i+dir; if(j<0||j>=wizState.photos.length) return;
  [wizState.photos[i],wizState.photos[j]] = [wizState.photos[j],wizState.photos[i]];
  if(wizState.coverIndex===i) wizState.coverIndex=j; else if(wizState.coverIndex===j) wizState.coverIndex=i;
  wizSave(); route();
}
async function removePhoto(i){
  const p = wizState.photos[i];
  wizState.photos.splice(i,1);
  if(wizState.coverIndex>=wizState.photos.length) wizState.coverIndex=0;
  wizSave(); route();
  if(p && p.path){ try{ await sb.storage.from("listing-images").remove([p.path]); }catch(e){} }
}
const wizPublish = guarded("publish", async ()=>{
  if(!ME.id){ requireAuthRedirect(); return; }
  // re-validate every step (type/category may have changed after earlier steps)
  const steps = wizSteps();
  const bad = steps.findIndex(k=>!wizCanProceed(k));
  if(bad>=0){ toast("Popuni obavezna polja: korak „"+WIZ_LABELS[steps[bad]]+"“"); location.hash = "/postavi-oglas/"+(bad+1); return; }
  const btn = document.getElementById("wizPublishBtn");
  if(btn){ btn.disabled = true; btn.textContent = "Objavljivanje..."; }
  const t = wizState.listingType;
  const sale = t==="offer_sale";
  const payload = {
    id: wizState.draftId,
    seller_id: ME.id,
    category: wizState.category,
    listing_type: t,
    brand: sale ? (wizState.subBrand||"") : "",
    title: wizState.title,
    price: parseInt(wizState.price)||0,
    currency: wizState.currency==="EUR" ? "EUR" : "RSD",
    condition: sale ? wizState.condition : null,
    city: wizState.city,
    delivery: sale ? wizState.delivery : null,
    exchange: sale ? wizState.exchange==="Moguća" : false,
    description: wizState.desc,
    images: wizState.photos.map(p=>p.url),
    cover_index: wizState.coverIndex||0,
    status: "active",
  };
  let created = false;
  try{
    let { data, error } = await sb.from("listings").insert(payload).select("id").single();
    if(error && isMissingListingTypeColumn(error)){
      if(t!=="offer_sale") throw new Error("Baza još nije ažurirana za ovaj tip oglasa (potrebna je migracija 20261009).");
      const legacy = Object.assign({}, payload); delete legacy.listing_type;   // pre-migration database: plain sale as before
      ({ data, error } = await sb.from("listings").insert(legacy).select("id").single());
    }
    if(error) throw error;
    created = true;
    const newId = data.id;
    if(wizSpecDefs.length) await saveListingSpecs(newId, wizSpecDefs, wizState.specValues);
    wizState = freshWizState(); wizSave();
    toast("Oglas je objavljen!");
    location.hash = "/oglas/"+newId;
  }catch(e){
    console.error(e);
    // specs rejected -> don't leave a half-published listing behind (same id can be re-posted)
    if(created){ try{ await sb.from("listings").delete().eq("id", wizState.draftId); }catch(_){} }
    toast("Greška pri objavljivanju: " + (e.message||"pokušaj ponovo"));
    if(btn){ btn.disabled=false; btn.textContent="Objavi oglas"; }
  }
});
function wizardSuccess(){
  return `<div class="wrap section"><div class="empty" style="max-width:440px;margin:0 auto;">
    <div class="glyph">🎉</div><h3>Oglas je objavljen!</h3>
    <p>Tvoj oglas je odmah vidljiv svim korisnicima PazariMe.</p>
    <div style="display:flex; gap:10px; justify-content:center; margin-top:18px;"><a href="#/moj-pazarime/oglasi" class="btn btn-primary">Moji oglasi</a><a href="#/" class="btn btn-outline">Početna</a></div>
  </div></div>`;
}

/* ---------------- EDIT LISTING ---------------- */
let editSpec = null;   // {id, defs, values}
async function viewEditListing(id){
  const l = await fetchListing(id);
  if(!l) return `<div class="wrap section">${emptyState("🔎","Oglas nije pronađen","")}</div>`;
  if(l.seller_id!==ME.id && !isAdmin()) return `<div class="wrap section">${emptyState("🔒","Nemate dozvolu za ovu radnju","Samo vlasnik oglasa može da ga uredi.")}</div>`;
  const editImages = (l.images||[]).filter(Boolean);
  pform = { id:l.id, draftId:l.id, photos: editImages.map(u=>({url:u, path:null})), cover: Math.min(l.cover_index||0, Math.max(0,editImages.length-1)), uploading:false, storeId:null, originalUrls: editImages.slice() };
  const t = listingTypeOf(l);
  const defs = await fetchCategorySpecs(l.category, t);
  let rows = [];
  try{ const r = await sb.from("listing_specification_values").select("*").eq("listing_id", l.id); rows = r.data||[]; }catch(e){}
  editSpec = { id:l.id, defs, values: specValuesFromRows(defs, rows), orig:{category:l.category, listing_type:t, brand:l.brand||""}, busy:false };
  const catOpts = activeCategories().slice();
  if(!catOpts.find(c=>c.id===l.category) && CATBYID[l.category]) catOpts.push(CATBYID[l.category]);
  return `<div class="wrap section">
    <div class="wizard-card" style="max-width:560px;">
      <h2>Uredi oglas</h2>
      ${pformPhotosBlockHtml()}
      <div class="form-group"><label>Naziv</label><input type="text" id="editTitle" value="${esc(l.title)}"></div>
      <div class="form-row">
        <div class="form-group"><label>Kategorija</label><select id="editCategory" onchange="editRefreshSpecs()">${catOpts.map(c=>`<option value="${c.id}" ${l.category===c.id?"selected":""}>${c.emoji} ${esc(c.name)}</option>`).join("")}</select></div>
        <div class="form-group"><label>Tip oglasa</label><select id="editType" onchange="editRefreshSpecs()">${LISTING_TYPES.map(x=>`<option value="${x.id}" ${t===x.id?"selected":""}>${x.label}</option>`).join("")}</select></div>
      </div>
      <div id="editSpecs">${specFieldsHtml("edit", defs, editSpec.values)}</div>
      <div class="form-row">
        <div class="form-group"><label id="editPriceLabel">${priceLabelFor(t, l.currency)}</label><div style="display:flex; gap:8px; align-items:stretch;"><input type="number" inputmode="numeric" id="editPrice" style="flex:1 1 120px; min-width:0;" value="${l.price}">${currencySelectHtml("editCurrency", l.currency, "editCurrencyChanged()")}</div></div>
        <div class="form-group" id="editConditionGroup" style="${t==="offer_sale"?"":"display:none;"}"><label>Stanje</label><select id="editCondition"><option value="">Izaberi</option>${CONDITIONS.map(c=>`<option ${l.condition===c?"selected":""}>${c}</option>`).join("")}</select></div>
      </div>
      <div class="form-group"><label>Opis</label><textarea id="editDesc">${esc(l.description||"")}</textarea></div>
      <div class="form-group"><label>Status</label><select id="editStatus">${["active","paused","sold"].map(s=>`<option value="${s}" ${l.status===s?"selected":""}>${statusLabel(s)}</option>`).join("")}</select></div>
      <div class="wizard-actions">
        <a href="#/moj-pazarime/oglasi" class="btn btn-outline">Otkaži</a>
        <button id="saveEditBtn" class="btn btn-primary" onclick="saveEdit('${id}')">Sačuvaj izmene</button>
      </div>
    </div>
  </div>`;
}
// Category or type changed in the edit form: reload the applicable specs, keep values
// for specs that still apply, drop the rest (the server also clears stale values on save).
function editCurrencyChanged(){ const pl = document.getElementById("editPriceLabel"); if(pl) pl.textContent = priceLabelFor((document.getElementById("editType")||{}).value, (document.getElementById("editCurrency")||{}).value); }
async function editRefreshSpecs(){
  if(!editSpec) return;
  const cat = document.getElementById("editCategory").value;
  const t = document.getElementById("editType").value;
  const btn = document.getElementById("saveEditBtn"); if(btn) btn.disabled = true;
  editSpec.busy = true;
  const defs = await fetchCategorySpecs(cat, t);
  const kept = {};
  defs.forEach(s=>{ if(editSpec.values[s.id]!==undefined) kept[s.id] = editSpec.values[s.id]; });
  editSpec.defs = defs; editSpec.values = kept;
  const box = document.getElementById("editSpecs"); if(box) box.innerHTML = specFieldsHtml("edit", defs, kept);
  const pl = document.getElementById("editPriceLabel"); if(pl) pl.textContent = priceLabelFor(t, (document.getElementById("editCurrency")||{}).value);
  const cg = document.getElementById("editConditionGroup"); if(cg) cg.style.display = t==="offer_sale" ? "" : "none";
  editSpec.busy = false;
  if(btn) btn.disabled = false;
}
async function saveEdit(id){
  if(editSpec && editSpec.busy) return;
  const withPhotos = !!(pform && pform.id===id);
  const t = document.getElementById("editType").value;
  const cat = document.getElementById("editCategory").value;
  const sale = t==="offer_sale";
  if(withPhotos && sale && !pform.photos.length){ toast("Oglas mora imati bar jednu fotografiju"); return; }
  const title = document.getElementById("editTitle").value.trim();
  if(!title){ toast("Unesi naziv oglasa"); return; }
  const condition = document.getElementById("editCondition").value;
  if(sale && !condition){ toast("Izaberi stanje"); return; }
  const defs = (editSpec && editSpec.id===id) ? editSpec.defs : [];
  const vals = (editSpec && editSpec.id===id) ? editSpec.values : {};
  const miss = specMissing(defs, vals);
  if(miss){ toast("Obavezno polje: "+miss.label); return; }
  const badNum = specBadNumber(defs, vals);
  if(badNum){ toast("Neispravna vrednost u polju: "+badNum.label); return; }
  const btn = document.getElementById("saveEditBtn"); if(btn){ btn.disabled=true; btn.textContent="Čuvanje..."; }
  const orig = editSpec && editSpec.orig;
  let listingUpdated = false;
  try{
    const catChanged = !!orig && cat!==orig.category;
    const keepBrand = !catChanged && sale;
    const payload = {
      title,
      price: parseInt(document.getElementById("editPrice").value)||0,
      ...(document.getElementById("editCurrency") ? { currency: document.getElementById("editCurrency").value==="EUR" ? "EUR" : "RSD" } : {}),
      condition: sale ? condition : null,
      description: document.getElementById("editDesc").value,
      status: document.getElementById("editStatus").value,
      category: cat,
      listing_type: t,
    };
    if(orig && (catChanged || !sale)) payload.brand = keepBrand ? orig.brand : "";
    if(withPhotos){ payload.images = pform.photos.map(p=>p.url); payload.cover_index = Math.min(pform.cover||0, Math.max(0,pform.photos.length-1)); }
    let { error } = await sb.from("listings").update(payload).eq("id", id);
    if(error && isMissingListingTypeColumn(error)){
      if(!sale) throw new Error("Baza još nije ažurirana za ovaj tip oglasa (potrebna je migracija 20261009).");
      const legacy = Object.assign({}, payload); delete legacy.listing_type;
      ({ error } = await sb.from("listings").update(legacy).eq("id", id));
    }
    if(error) throw error;
    listingUpdated = true;
    if(defs.length || (orig && (catChanged || t!==orig.listing_type))) await saveListingSpecs(id, defs, vals);
    if(withPhotos){   // delete files of removed photos only after the DB no longer references them
      const keep = new Set(payload.images);
      await removeOwnedListingImages((pform.originalUrls||[]).filter(u=>!keep.has(u)), id);
      pform = null;
    }
    editSpec = null;
    toast("Oglas je ažuriran");
    location.hash = "/moj-pazarime/oglasi";
  }catch(e){
    console.error(e);
    // specs rejected: put category/type/brand back so the listing never mismatches its stored specs
    if(listingUpdated && orig){ try{ await sb.from("listings").update({category:orig.category, listing_type:orig.listing_type, brand:orig.brand}).eq("id", id); }catch(_){} }
    toast("Greška pri čuvanju izmena" + (e && e.message ? ": "+e.message : ""));
    if(btn){ btn.disabled=false; btn.textContent="Sačuvaj izmene"; }
  }
}
async function markSold(id){
  try{ const { error } = await sb.from("listings").update({status:"sold"}).eq("id", id); if(error) throw error; toast("Oglas obeležen kao prodat"); route(); }
  catch(e){ toast("Greška"); }
}
async function togglePause(id, current){
  const next = current==="paused" ? "active" : "paused";
  try{ const { error } = await sb.from("listings").update({status:next}).eq("id", id); if(error) throw error; toast(next==="paused"?"Oglas pauziran":"Oglas ponovo aktivan"); route(); }
  catch(e){ toast("Greška"); }
}
async function deleteListing(id){
  if(!confirm("Obrisati oglas? Ova radnja se ne može poništiti.")) return;
  try{ const { error } = await sb.from("listings").delete().eq("id", id); if(error) throw error; toast("Oglas je obrisan"); route(); }
  catch(e){ toast("Greška pri brisanju"); }
}

/* ---------------- DASHBOARD ---------------- */
async function viewDashboard(tab){
  if(!ME.id){
    Store.set("postLoginRedirect", "#/moj-pazarime/"+tab);
    return `<div class="wrap"><div class="auth-card"><h2>Prijava potrebna</h2><p class="sub">Prijavi se da bi pristupio svom profilu.</p><a href="#/prijava" class="btn btn-primary btn-block">Prijavi se</a></div></div>`;
  }
  const nav = [["pregled","Pregled","📊"],["oglasi","Moji oglasi","🏷️"],["promocije","Moje uplate","⭐"],["omiljeni","Omiljeni","♡"],["podesavanja","Podešavanja","⚙️"]];
  let body = "";
  const mine = await fetchMyListings();

  if(tab==="pregled"){
    const totalViews = mine.reduce((s,l)=>s+(l.views_count||0),0);
    const totalFavs = mine.reduce((s,l)=>s+(l.favorites_count||0),0);
    const convs = await fetchMyConversationsList();
    const subBanner = await storeSubBannerHtml();
    body = `${subBanner}<h2 style="font-size:20px;margin-bottom:18px;">Zdravo, ${esc((ME.name||"").split(" ")[0]||"tamo")} 👋</h2>
      <div class="stat-grid">
        <div class="stat-card"><div class="n">${mine.length}</div><div class="l">Ukupno oglasa</div></div>
        <div class="stat-card"><div class="n">${totalViews}</div><div class="l">Ukupno pregleda</div></div>
        <div class="stat-card"><div class="n">${totalFavs}</div><div class="l">Puta sačuvano</div></div>
        <div class="stat-card"><div class="n">${convs.length}</div><div class="l">Konverzacije</div></div>
      </div>
      ${mine.length?`<h3 style="font-size:15px; margin-bottom:10px;">Poslednji oglasi</h3>${dashListingRows(mine.slice(0,4))}`:emptyState("🏷️","Još nemaš objavljene oglase.","Postavi svoj prvi oglas i počni da prodaješ.", `<a href="#/postavi-oglas" class="btn btn-primary" style="margin-top:14px;">+ Postavi oglas</a>`)}`;
  } else if(tab==="oglasi"){
    body = `<h2 style="font-size:20px;margin-bottom:16px;">Moji oglasi</h2>
      ${mine.length ? dashListingRows(mine) : emptyState("🏷️","Još nemaš objavljene oglase.","Postavi svoj prvi oglas i počni da prodaješ.", `<a href="#/postavi-oglas" class="btn btn-primary" style="margin-top:14px;">+ Postavi oglas</a>`)}`;
  } else if(tab==="promocije"){
    body = await renderMyPromoOrders();
  } else if(tab==="omiljeni"){
    location.hash = "/omiljeni"; return "";
  } else if(tab==="podesavanja"){
    const mySt = await fetchMySellerStatus();
    body = `<h2 style="font-size:20px;margin-bottom:16px;">Podešavanja</h2>
      <div style="display:flex; align-items:center; gap:12px; background:var(--surface); border:1px solid var(--border); border-radius:var(--radius-m); padding:16px; margin-bottom:16px;">
        <img src="${ME.avatarUrl}" class="avatar" style="object-fit:cover;">
        <div><div style="font-weight:600;">${esc(ME.name||"Bez imena")}</div><div style="font-size:12.5px; color:var(--ink-faint);">${esc(ME.email)}</div></div>
      </div>
      ${mySellerStatusCardHtml(mySt)}
      ${isAdmin()?`<div style="background:var(--blue-dim); border-radius:var(--radius-m); padding:16px; margin-bottom:16px;"><a href="#/admin" style="font-size:13.5px; font-weight:600; color:var(--blue);">🛠️ Otvori admin panel →</a></div>`:""}
      <button class="btn btn-outline" onclick="doLogout()">Odjavi se</button>`;
  }
  return `<div class="wrap section"><div class="dash-layout">
    <nav class="dash-nav">${nav.map(([id,label,icon])=>`<a href="#/moj-pazarime/${id}" class="${tab===id?'active':''}">${icon} ${label}</a>`).join("")}<a href="#/moja-prodavnica">🏪 Moja prodavnica</a><a href="#/moje-porudzbine">🧾 Moje porudžbine</a></nav>
    <div>${body}</div>
  </div></div>`;
}
function dashListingRows(list){
  return list.map(l=>`<div class="list-row">
    <div class="thumb-sm">${l.images&&l.images.length?`<img src="${l.images[0]}" style="width:100%;height:100%;object-fit:cover;border-radius:9px;">`:(CATBYID[l.category]?CATBYID[l.category].emoji:"📦")}</div>
    <div class="info">
      <div class="t">${esc(l.title)}</div>
      <div class="stats"><span>${listingPriceText(l)}</span>${isServiceType(listingTypeOf(l))?`<span>${listingTypeBadgeHtml(listingTypeOf(l))}</span>`:""}<span>👁 ${l.views_count||0}</span><span>♡ ${l.favorites_count||0}</span><span class="status-pill ${statusClass(l.status)}">${statusLabel(l.status)}</span></div>
    </div>
    <div style="display:flex; gap:6px; flex-wrap:wrap; justify-content:flex-end;">
      <a href="${l.store_id?`#/moja-prodavnica/proizvod/${l.id}`:`#/uredi-oglas/${l.id}`}" class="btn btn-outline btn-sm">Uredi</a>
      ${l.status==="active"?`<a href="#/promocija/${l.id}" class="btn btn-outline btn-sm">⭐ Promoviši</a>`:""}
      ${l.status!=="sold"?`<button class="btn btn-ghost btn-sm" onclick="markSold('${l.id}')">Prodato</button>`:""}
      ${l.status==="active"||l.status==="paused"?`<button class="btn btn-ghost btn-sm" onclick="togglePause('${l.id}','${l.status}')">${l.status==="paused"?"Aktiviraj":"Pauziraj"}</button>`:""}
      <button class="btn btn-danger btn-sm" onclick="deleteListing('${l.id}')">Obriši</button>
    </div>
  </div>`).join("");
}

/* ---------------- MESSAGES ---------------- */
async function fetchMyConversationsList(){
  if(!ME.id) return [];
  try{
    const { data, error } = await sb.from("conversations").select("*").or(`buyer_id.eq.${ME.id},seller_id.eq.${ME.id}`).order("updated_at",{ascending:false});
    if(error) throw error;
    const convs = data||[];
    await Promise.all(convs.map(async c=>{
      const { data: msgs } = await sb.from("messages").select("*").eq("conversation_id", c.id).order("created_at",{ascending:false}).limit(1);
      c.lastMessage = (msgs && msgs[0]) || null;
    }));
    return convs;
  }catch(e){ return []; }
}
async function fetchConversationMessages(convId){
  try{
    const { data, error } = await sb.from("messages").select("*").eq("conversation_id", convId).order("created_at",{ascending:true});
    if(error) throw error;
    return data||[];
  }catch(e){ return []; }
}
function bubbleHtml(msg, opts={}){
  const mine = msg.sender_id===ME.id;
  let status = "";
  if(opts.pending) status = `<div class="seen">Šalje se...</div>`;
  else if(opts.failed) status = `<div class="seen" style="color:var(--danger);">Nije poslato · <a href="#" onclick="event.preventDefault();retrySend('${msg.id}','${msg.conversation_id}')">Pokušaj ponovo</a></div>`;
  else if(mine && opts.isLastMine && msg.read_at) status = `<div class="seen">Viđeno</div>`;
  return `<div class="bubble ${mine?'me':'them'}" data-msg-id="${msg.id}">${esc(msg.body)}${status}</div>`;
}
function appendMessageBubble(msg, opts={}){
  const body = document.getElementById("chatBody");
  if(!body) return;
  renderedMsgIds.add(msg.id);
  const empty = body.querySelector(".chat-empty-hint");
  if(empty) empty.remove();
  if(msg.sender_id===ME.id){
    // Only the truly latest message of mine should show "Viđeno" — clear it off older ones.
    body.querySelectorAll(".bubble.me .seen").forEach(s=>{ if(s.textContent==="Viđeno") s.remove(); });
  }
  const wrap = document.createElement("div");
  wrap.innerHTML = bubbleHtml(msg, opts);
  body.appendChild(wrap.firstElementChild);
  body.scrollTop = body.scrollHeight;
}
function finalizeBubble(tempId, realId){
  const el = document.querySelector(`[data-msg-id="${tempId}"]`);
  if(el){ el.setAttribute("data-msg-id", realId); const seen=el.querySelector(".seen"); if(seen) seen.remove(); }
}
function markBubbleFailed(tempId, text, convId){
  const el = document.querySelector(`[data-msg-id="${tempId}"]`);
  if(!el) return;
  el.dataset.failedText = text;
  let seen = el.querySelector(".seen");
  if(!seen){ seen = document.createElement("div"); seen.className="seen"; el.appendChild(seen); }
  seen.style.color = "var(--danger)";
  seen.innerHTML = `Nije poslato · <a href="#" onclick="event.preventDefault();retrySend('${tempId}','${convId}')">Pokušaj ponovo</a>`;
}
async function retrySend(tempId, convId){
  const el = document.querySelector(`[data-msg-id="${tempId}"]`);
  const text = el ? el.dataset.failedText : null;
  if(!text) return;
  const seen = el.querySelector(".seen");
  if(seen){ seen.style.color=""; seen.textContent = "Šalje se..."; }
  try{
    const { data, error } = await sb.from("messages").insert({ conversation_id: convId, sender_id: ME.id, body: text }).select().single();
    if(error) throw error;
    renderedMsgIds.add(data.id);
    finalizeBubble(tempId, data.id);
  }catch(e){ markBubbleFailed(tempId, text, convId); }
}
function updateSeenIndicator(convId){
  if(currentOpenConvId !== convId) return;
  const body = document.getElementById("chatBody");
  if(!body) return;
  const mine = [...body.querySelectorAll(".bubble.me")];
  if(!mine.length) return;
  mine.forEach(b=>{ const s=b.querySelector(".seen"); if(s && s.textContent==="Viđeno") s.remove(); });
  const last = mine[mine.length-1];
  if(last.querySelector(".seen")) return; // pending/failed status takes priority, don't overwrite
  const div = document.createElement("div"); div.className="seen"; div.textContent="Viđeno";
  last.appendChild(div);
}
async function refreshConversationListPreview(){
  const listEl = document.querySelector(".conv-list");
  if(!listEl) return;
  const convs = await fetchMyConversationsList();
  const otherIds = convs.map(c=> c.buyer_id===ME.id ? c.seller_id : c.buyer_id);
  const profiles = await resolveProfiles(otherIds);
  const unreadByConv = {};
  unreadMessages.forEach(m=>{ unreadByConv[m.conversation_id] = (unreadByConv[m.conversation_id]||0)+1; });
  listEl.innerHTML = convs.map(c=>{
    const otherId = c.buyer_id===ME.id ? c.seller_id : c.buyer_id;
    const other = profiles[otherId]||{name:"Korisnik",avatarUrl:genericAvatar(otherId),lastSeen:null};
    const unread = unreadByConv[c.id]||0;
    return `<a href="#/poruke?c=${c.id}" class="conv-item ${c.id===currentOpenConvId?'active':''}">
      <div class="avatar-wrap"><img src="${other.avatarUrl}" class="avatar" style="object-fit:cover;">${presenceDotHtml(other.lastSeen)}</div>
      <div style="flex:1; min-width:0;">
        <div class="t">${esc(other.name)} ${unread?`<span class="chip" style="background:var(--danger);color:#fff;border:none;">${unread}</span>`:''}</div>
        <div class="p">${c.lastMessage?esc(c.lastMessage.body):"Nema poruka još"}</div>
      </div>
    </a>`;
  }).join("");
}
async function viewMessages(activeId){
  if(!ME.id){
    Store.set("postLoginRedirect", "#/poruke");
    currentOpenConvId = null;
    return `<div class="wrap"><div class="auth-card"><h2>Prijava potrebna</h2><p class="sub">Prijavi se da bi video svoje poruke.</p><a href="#/prijava" class="btn btn-primary btn-block">Prijavi se</a></div></div>`;
  }
  const convs = await fetchMyConversationsList();
  if(!convs.length){
    currentOpenConvId = null;
    return `<div class="wrap section">${emptyState("💬","Nema poruka.","Kad kontaktiraš prodavca ili neko tebe kontaktira, razgovori će se pojaviti ovde.")}</div>`;
  }
  const active = convs.find(c=>c.id===activeId) || convs[0];
  // phones show either the conversation list or one chat: no explicit ?c= => list only
  const listOnly = window.innerWidth <= 680 && !activeId;
  currentOpenConvId = listOnly ? null : active.id;
  renderedMsgIds = new Set();
  const activeMessages = await fetchConversationMessages(active.id);
  activeMessages.forEach(m=>renderedMsgIds.add(m.id));
  const otherIds = convs.map(c=> c.buyer_id===ME.id ? c.seller_id : c.buyer_id);
  const profiles = await resolveProfiles(otherIds);
  const unreadByConv = {};
  unreadMessages.forEach(m=>{ unreadByConv[m.conversation_id] = (unreadByConv[m.conversation_id]||0)+1; });
  const activeOtherId = active.buyer_id===ME.id ? active.seller_id : active.buyer_id;
  const activeOther = profiles[activeOtherId] || {name:"Korisnik", avatarUrl:genericAvatar(activeOtherId), lastSeen:null};

  if(!listOnly) markConversationRead(active.id); // fire-and-forget; also refreshes the badge

  let lastMineMsg = null;
  for(let i=activeMessages.length-1; i>=0; i--){ if(activeMessages[i].sender_id===ME.id){ lastMineMsg = activeMessages[i]; break; } }

  return `<div class="wrap section">
    <h2 class="msg-title" style="font-size:20px;margin-bottom:16px;">Poruke</h2>
    <div class="msg-layout" data-view="${listOnly?"list":"chat"}">
      <div class="conv-list">
        ${convs.map(c=>{
          const otherId = c.buyer_id===ME.id ? c.seller_id : c.buyer_id;
          const other = profiles[otherId]||{name:"Korisnik",avatarUrl:genericAvatar(otherId),lastSeen:null};
          const unread = unreadByConv[c.id]||0;
          return `<a href="#/poruke?c=${c.id}" class="conv-item ${c.id===active.id&&!listOnly?'active':''}">
            <div class="avatar-wrap"><img src="${other.avatarUrl}" class="avatar" style="object-fit:cover;">${presenceDotHtml(other.lastSeen)}</div>
            <div style="flex:1; min-width:0;">
              <div class="t">${esc(other.name)} ${unread?`<span class="chip" style="background:var(--danger);color:#fff;border:none;">${unread}</span>`:''}</div>
              <div class="p">${c.lastMessage?esc(c.lastMessage.body):"Nema poruka još"}</div>
            </div>
          </a>`;
        }).join("")}
      </div>
      <div class="chat-pane">
        <div class="chat-head">
          <a href="#/poruke" class="chat-back" aria-label="Nazad na razgovore">←</a>
          <div class="avatar-wrap"><img src="${activeOther.avatarUrl}" class="avatar" style="object-fit:cover;">${presenceDotHtml(activeOther.lastSeen)}</div>
          <div style="min-width:0;">
            <div style="font-weight:600; font-size:13.5px;">${esc(activeOther.name)}</div>
            <div style="font-size:11px; color:var(--ink-faint);">${formatPresence(activeOther.lastSeen).label}</div>
            ${active.listing_id?`<a href="#/oglas/${active.listing_id}" style="font-size:12px; color:var(--blue);">Pogledaj oglas</a>`:""}
          </div>
        </div>
        <div class="chat-body" id="chatBody">
          ${activeMessages.length ? activeMessages.map(m=>bubbleHtml(m, {isLastMine: !!(lastMineMsg && m.id===lastMineMsg.id)})).join("") : `<div class="chat-empty-hint" style="color:var(--ink-faint); font-size:13px; text-align:center; margin:auto;">Pošalji prvu poruku</div>`}
        </div>
        <div class="chat-input">
          <input id="chatInput" enterkeyhint="send" autocomplete="off" placeholder="Napiši poruku..." onkeydown="if(event.key==='Enter')sendMessage('${active.id}')">
          <button class="btn btn-primary btn-sm" onclick="sendMessage('${active.id}')">Pošalji</button>
        </div>
      </div>
    </div>
  </div>`;
}
const sendMessage = guarded("send", async (convId)=>{
  const input = document.getElementById("chatInput");
  if(!input) return;
  const text = input.value.trim();
  if(!text) return;
  input.value = "";
  const tempId = "tmp-"+Date.now()+"-"+Math.random().toString(36).slice(2);
  appendMessageBubble({ id:tempId, conversation_id:convId, sender_id:ME.id, body:text, created_at:new Date().toISOString(), read_at:null }, { pending:true });
  try{
    const { data, error } = await sb.from("messages").insert({ conversation_id: convId, sender_id: ME.id, body: text }).select().single();
    if(error) throw error;
    renderedMsgIds.add(data.id);
    finalizeBubble(tempId, data.id);
  }catch(e){
    markBubbleFailed(tempId, text, convId);
  }
});

/* ---------------- FAVORITES ---------------- */
async function viewFavorites(){
  if(!ME.id){
    Store.set("postLoginRedirect", "#/omiljeni");
    return `<div class="wrap"><div class="auth-card"><h2>Prijava potrebna</h2><p class="sub">Prijavi se da bi video svoje omiljene oglase.</p><a href="#/prijava" class="btn btn-primary btn-block">Prijavi se</a></div></div>`;
  }
  await loadFavoriteIds();
  const ids = [...favoriteIds];
  let favs = [];
  if(ids.length){
    try{ const { data, error } = await sb.from("listings").select("*").in("id", ids); if(error) throw error; favs = data||[]; await cacheStoresFor(favs); }catch(e){ favs=[]; }
  }
  return `<div class="wrap section">
    <h2 style="font-size:20px;margin-bottom:16px;">Omiljeni oglasi</h2>
    ${favs.length ? listingGrid(favs) : emptyState("♡","Još nemaš omiljene oglase.","Klikni na srce na bilo kom oglasu da ga sačuvaš ovde.", `<a href="#/oglasi" class="btn btn-primary" style="margin-top:14px;">Pregledaj oglase</a>`)}
  </div>`;
}

/* ---------------- AUTH (real Supabase email/password) ---------------- */

// Central place that turns raw Supabase/network errors into friendly,
// Serbian, non-technical messages. Nothing from `error.message` is ever
// shown to the user verbatim — the raw error still goes to console.error
// for debugging, but the UI only ever sees one of these mapped strings.
function mapAuthError(error, context){
  const code = (error && (error.code || error.error_code)) || "";
  const status = error && error.status;
  const msg = String((error && error.message) || "").toLowerCase();
  console.error("[auth]", context, error);

  if(error && (error.name === "TypeError" || msg.includes("failed to fetch") || msg.includes("networkerror"))){
    return "Greška mreže. Proveri internet konekciju i pokušaj ponovo.";
  }
  if(code === "over_email_send_rate_limit" || status === 429 || msg.includes("rate limit")){
    return "Previše zahteva za verifikacioni email. Sačekaj nekoliko minuta i pokušaj ponovo.";
  }
  if(code === "email_not_confirmed" || msg.includes("email not confirmed")){
    return "Nalog nije potvrđen. Proveri svoj email i klikni na link za potvrdu pre prijave.";
  }
  if(code === "user_already_exists" || msg.includes("already registered") || msg.includes("already exists") || msg.includes("user already")){
    return "Nalog sa ovim emailom već postoji. Pokušaj da se prijaviš.";
  }
  if(code === "invalid_credentials" || msg.includes("invalid login credentials")){
    return "Pogrešan email ili lozinka.";
  }
  if(code === "validation_failed" || msg.includes("unable to validate email") || msg.includes("invalid email")){
    return "Email adresa nije ispravna.";
  }
  if(code === "weak_password" || msg.includes("password") && (msg.includes("weak") || msg.includes("should be at least") || msg.includes("characters"))){
    return "Lozinka je preslaba. Koristi bar 6 karaktera.";
  }
  if(code === "unexpected_failure"){
    // GoTrue redacts the real cause from the response body (by design), so
    // the client only ever sees a bare 500 here even when the underlying
    // issue — as it was for us — is the email provider rejecting the send.
    // The real cause is only visible server-side via Supabase's auth logs.
    return "Trenutno ne možemo da pošaljemo email za potvrdu. Probaj ponovo za par minuta — ako se ponavlja, kontaktiraj podršku na podrska.pazarime@gmail.com.";
  }
  if(status && status >= 500){
    return "Greška na serveru. Pokušaj ponovo za par trenutaka.";
  }
  return "Došlo je do greške. Pokušaj ponovo.";
}
function isValidEmail(email){
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function viewAuth(mode){
  if(ME.id){
    return `<div class="wrap"><div class="auth-card"><h2>Već si prijavljen</h2><p class="sub">Prijavljen si kao ${esc(ME.email)}.</p><a href="#/moj-pazarime" class="btn btn-primary btn-block">Moj PazariMe</a></div></div>`;
  }
  if(mode==="login"){
    return `<div class="wrap"><div class="auth-card">
      <h2>Prijava</h2><p class="sub">Dobrodošao nazad na PazariMe</p>
      <div id="authError" style="display:none; background:var(--danger-bg); color:var(--danger); font-size:13px; padding:10px 12px; border-radius:8px; margin-bottom:14px;"></div>
      <div id="resendInline" style="display:none; margin-bottom:14px;"></div>
      <div class="form-group"><label>Email</label><input type="email" id="loginEmail" placeholder="ime@email.com"></div>
      <div class="form-group"><label>Lozinka</label><input type="password" id="loginPass" placeholder="••••••••"></div>
      <button id="loginBtn" class="btn btn-primary btn-block" onclick="doLogin()">Prijavi se</button>
      <div style="text-align:center; margin-top:10px; font-size:13px; color:var(--ink-dim);">Nemaš nalog? <a href="#/registracija" style="color:var(--blue); font-weight:600;">Registruj se</a></div>
    </div></div>`;
  }
  return `<div class="wrap"><div class="auth-card">
    <h2>Registracija</h2><p class="sub">Napravi nalog za par sekundi</p>
    <div id="authError" style="display:none; background:var(--danger-bg); color:var(--danger); font-size:13px; padding:10px 12px; border-radius:8px; margin-bottom:14px;"></div>
    <div class="form-group"><label>Ime i prezime</label><input type="text" id="regName" placeholder="Marko Marković"></div>
    <div class="form-group"><label>Email</label><input type="email" id="regEmail" placeholder="ime@email.com"></div>
    <div class="form-group"><label>Lozinka</label><input type="password" id="regPass" placeholder="min. 6 karaktera"></div>
    <button id="regBtn" class="btn btn-primary btn-block" onclick="if(this.disabled)return; doRegister()">Registruj se</button>
    <div style="text-align:center; margin-top:10px; font-size:13px; color:var(--ink-dim);">Već imaš nalog? <a href="#/prijava" style="color:var(--blue); font-weight:600;">Prijavi se</a></div>
  </div></div>`;
}

// Shown right after signup instead of an immediate redirect, whenever
// Supabase requires email confirmation (i.e. signUp() returned no session).
// Also reachable any time from "Nisi dobio email?" so a user can request a
// resend without re-registering (which would just error as "already exists").
function viewVerificationPending(email){
  return `<div class="wrap"><div class="auth-card">
    <h2>Proveri svoj email</h2>
    <p class="sub">Poslali smo link za potvrdu naloga na<br><strong>${esc(email)}</strong></p>
    <p style="font-size:13px; color:var(--ink-dim); text-align:center; margin-bottom:18px;">Klikni na link u emailu, pa se <a href="#/prijava" style="color:var(--blue); font-weight:600;">prijavi</a>. Ne vidiš email? Proveri i spam folder.</p>
    <div id="authError" style="display:none; background:var(--danger-bg); color:var(--danger); font-size:13px; padding:10px 12px; border-radius:8px; margin-bottom:14px;"></div>
    <button id="resendBtn" class="btn btn-outline btn-block" onclick="resendVerificationEmail('${esc(email)}')">Pošalji ponovo</button>
    <a href="#/prijava" class="btn btn-ghost btn-block" style="margin-top:8px;">Nazad na prijavu</a>
  </div></div>`;
}
function showAuthError(msg){ const el=document.getElementById("authError"); if(el){ el.textContent=msg; el.style.display="block"; } }
function hideAuthError(){ const el=document.getElementById("authError"); if(el) el.style.display="none"; }
function afterAuthRedirect(){
  const dest = Store.get("postLoginRedirect", null);
  Store.del("postLoginRedirect");
  location.hash = dest || "/moj-pazarime";
}

// --- Resend cooldown: purely a client-side UX guard so a user can't spam
// the button. It does NOT and CANNOT bypass Supabase's own server-side
// rate limit — that's enforced on their end regardless of this timer.
const RESEND_COOLDOWN_SECONDS = 60;
let resendCountdownTimer = null;
function clearResendCountdown(){ if(resendCountdownTimer){ clearInterval(resendCountdownTimer); resendCountdownTimer=null; } }
function resendCooldownRemaining(email){
  const until = Store.get("resendCooldownUntil_"+email, 0);
  return Math.max(0, Math.ceil((until - Date.now())/1000));
}
function startResendCountdown(email){
  clearResendCountdown();
  const tick = ()=>{
    const btn = document.getElementById("resendBtn");
    if(!btn) { clearResendCountdown(); return; }
    const remaining = resendCooldownRemaining(email);
    if(remaining > 0){
      btn.disabled = true;
      btn.textContent = `Pošalji ponovo (${remaining}s)`;
    } else {
      btn.disabled = false;
      btn.textContent = "Pošalji ponovo";
      clearResendCountdown();
    }
  };
  tick();
  resendCountdownTimer = setInterval(tick, 1000);
}
const resendVerificationEmail = guarded("resend", async (email)=>{
  hideAuthError();
  if(resendCooldownRemaining(email) > 0) return; // extra guard; button is already disabled
  const btn = document.getElementById("resendBtn");
  if(btn){ btn.disabled = true; btn.textContent = "Slanje..."; }
  const { error } = await sb.auth.resend({ type: "signup", email });
  if(error){
    showAuthError(mapAuthError(error, "resend"));
    // Even on failure, start the cooldown — a 429 means the provider is
    // already rate-limited, so hammering it again won't help.
  }else{
    toast("Verifikacioni email je ponovo poslat.");
  }
  Store.set("resendCooldownUntil_"+email, Date.now() + RESEND_COOLDOWN_SECONDS*1000);
  startResendCountdown(email);
});

const doLogin = guarded("login", async ()=>{
  const btn = document.getElementById("loginBtn");
  btn.disabled = true; // disable immediately, before any validation, to kill double-clicks at the source
  const email = document.getElementById("loginEmail").value.trim();
  const pass = document.getElementById("loginPass").value;
  hideAuthError();
  const inlineResend = document.getElementById("resendInline");
  if(inlineResend) inlineResend.style.display = "none";

  if(!email || !pass){ showAuthError("Unesi email i lozinku"); btn.disabled=false; return; }
  if(!isValidEmail(email)){ showAuthError("Email adresa nije ispravna."); btn.disabled=false; return; }

  btn.textContent = "Prijavljivanje...";
  const { error } = await sb.auth.signInWithPassword({ email, password: pass });
  if(error){
    showAuthError(mapAuthError(error, "login"));
    if((error.code||"")==="email_not_confirmed" && inlineResend){
      inlineResend.style.display = "block";
      inlineResend.innerHTML = `<button id="resendBtn" class="btn btn-outline btn-block btn-sm" onclick="resendVerificationEmail('${esc(email)}')">Pošalji verifikacioni email ponovo</button>`;
      startResendCountdown(email);
    }
    btn.disabled = false; btn.textContent = "Prijavi se";
    return;
  }
  await loadFavoriteIds();
  toast("Uspešno si prijavljen");
  afterAuthRedirect();
});

const doRegister = guarded("register", async ()=>{
  const btn = document.getElementById("regBtn");
  btn.disabled = true; // disable immediately — this is the actual double-click guard
  const name = document.getElementById("regName").value.trim();
  const email = document.getElementById("regEmail").value.trim();
  const pass = document.getElementById("regPass").value;
  hideAuthError();

  if(!name){ showAuthError("Unesi ime i prezime"); btn.disabled=false; return; }
  if(!email || !isValidEmail(email)){ showAuthError("Email adresa nije ispravna."); btn.disabled=false; return; }
  if(!pass || pass.length<6){ showAuthError("Lozinka mora imati bar 6 karaktera."); btn.disabled=false; return; }

  btn.textContent = "Kreiranje naloga...";
  // Exactly one signUp() call per click, guaranteed by `guarded()` adding
  // "register" to busyKeys synchronously before this ever awaits — a second
  // click while this is in flight is a no-op, not a second request.
  const { data, error } = await sb.auth.signUp({ email, password: pass, options:{ data:{ full_name: name } } });
  if(error){
    showAuthError(mapAuthError(error, "register"));
    btn.disabled = false; btn.textContent = "Registruj se";
    return;
  }
  // With "Confirm email" disabled server-side, signUp() returns a session
  // directly and we log the user in immediately — no email step at all.
  if(data.session){
    await loadFavoriteIds();
    toast("Nalog je kreiran!");
    afterAuthRedirect();
    return;
  }
  // Safety net: if no session came back (e.g. a transient case), try
  // signing in immediately with the same credentials rather than assuming
  // email verification is required.
  const { error: signInErr } = await sb.auth.signInWithPassword({ email, password: pass });
  if(!signInErr){
    await loadFavoriteIds();
    toast("Nalog je kreiran!");
    afterAuthRedirect();
    return;
  }
  if((signInErr.code||"") === "email_not_confirmed"){
    // Honest, specific message: the account was created, but Supabase's
    // own "Confirm email" setting is still ON for this project — that's a
    // dashboard setting, not something this code can bypass or fake.
    showAuthError("Nalog je kreiran, ali server i dalje zahteva potvrdu emaila (podešavanje \"Confirm email\" u Supabase dashboard-u nije isključeno).");
  }else{
    showAuthError(mapAuthError(signInErr, "register-autologin"));
  }
  btn.disabled = false; btn.textContent = "Registruj se";
});
async function doLogout(){
  await sb.auth.signOut();
  favoriteIds = new Set();
  teardownMessagingRealtime();
  stopHeartbeat();
  unreadMessages = []; renderUnreadBadge();
  toast("Odjavljen si");
  location.hash = "/";
}

/* ---------------- SAFETY / STATIC PAGES ---------------- */
function viewSafety(){
  const tips = ["Ne šaljite novac unapred nepoznatim prodavcima.","Proverite proizvod pre kupovine, po mogućnosti uživo.","Budite oprezni sa neuobičajeno niskim cenama.","Ne šaljite lozinke, kodove ili druge osetljive podatke.","Dogovarajte se za sastanak na javnom, bezbednom mestu.","Prijavite svaki sumnjiv oglas ili poruku administraciji."];
  return `<div class="wrap section" style="max-width:720px;"><h1 style="font-size:26px;">Bezbednost na PazariMe</h1>
    <p style="color:var(--ink-dim); margin-top:8px; margin-bottom:26px;">Tvoja bezbednost nam je prioritet.</p>
    ${tips.map((t,i)=>`<div class="safety-tip"><div class="n">${i+1}</div><div style="padding-top:4px; font-size:14px;">${t}</div></div>`).join("")}
    <div style="margin-top:20px;"><a href="#/oglasi" class="btn btn-primary">Pregledaj oglase</a></div>
  </div>`;
}
function viewHowItWorks(){
  return `<div class="wrap section" style="max-width:720px;"><h1 style="font-size:26px;">Kako PazariMe radi?</h1>
    <div style="margin-top:20px; display:flex; flex-direction:column; gap:14px;">
      <div class="safety-tip"><div class="n">1</div><div style="padding-top:4px;"><strong>Postavi oglas</strong> — dodaj prave fotografije, opis i cenu.</div></div>
      <div class="safety-tip"><div class="n">2</div><div style="padding-top:4px;"><strong>Poveži se sa kupcima</strong> — odgovaraj na poruke direktno kroz platformu.</div></div>
      <div class="safety-tip"><div class="n">3</div><div style="padding-top:4px;"><strong>Dogovori prodaju</strong> — izaberi preuzimanje ili dostavu koja vam oboma odgovara.</div></div>
      <div class="safety-tip"><div class="n">4</div><div style="padding-top:4px;"><strong>Oceni prodavca</strong> — 👍/👎 pomaže zajednici da gradi poverenje.</div></div>
    </div>
    <a href="#/postavi-oglas" class="btn btn-primary" style="margin-top:20px;">Postavi svoj prvi oglas</a>
  </div>`;
}
function viewContact(){
  return `<div class="wrap section" style="max-width:560px;"><h1 style="font-size:24px;">Kontakt</h1>
    <p style="color:var(--ink-dim); margin:8px 0 20px;">Podrška: <strong><a href="mailto:podrska.pazarime@gmail.com" style="color:var(--blue);">podrska.pazarime@gmail.com</a></strong></p>
    <div class="form-group"><label>Poruka</label><textarea></textarea></div>
    <button class="btn btn-primary" onclick="toast('Poruka je poslata! Odgovorićemo uskoro.')">Pošalji poruku</button>
  </div>`;
}
function viewFaq(){
  const faqs = [["Kako da postavim oglas?","Klikni na „Postavi oglas“, izaberi kategoriju i prati korake do objave."],["Kako da izmenim oglas?","Idi na „Moji oglasi“ u tvom profilu i klikni „Uredi“."],["Kako da kontaktiram prodavca?","Na stranici oglasa klikni „Kontaktiraj prodavca“."],["Ko vidi moje poruke?","Samo ti i sagovornik — poruke su vidljive isključivo učesnicima razgovora."],["Kako funkcionišu ocene prodavaca?","Svaki prijavljeni korisnik može oceniti drugog prodavca sa 👍 ili 👎, jednom po prodavcu; ocenu kasnije možeš promeniti."]];
  return `<div class="wrap section" style="max-width:680px;"><h1 style="font-size:24px; margin-bottom:20px;">Najčešća pitanja</h1>
    ${faqs.map(([q,a])=>`<div style="border-bottom:1px solid var(--border); padding:16px 0;"><div style="font-weight:600; font-size:14.5px;">${q}</div><div style="color:var(--ink-dim); font-size:13.5px; margin-top:6px;">${a}</div></div>`).join("")}
  </div>`;
}
/* ---------------- PROMOCIJA OGLASA UPLATOM NA RAČUN ----------------
   Podaci žive u promo_packages / promo_orders / promo_payment_settings / promo_payment_events.
   Korisnici samo ČITAJU svoje porudžbine (RLS); sve upise rade RPC funkcije u bazi koje samostalno
   čitaju cenu i trajanje iz baze. Promociju aktivira ISKLJUČIVO admin_confirm_promo_payment. */
const PROMO_SUPPORT_EMAIL = "podrska.pazarime@gmail.com";
const PROMO_STATUS = {
  awaiting_payment:  {label:"Čeka uplatu",                      cls:"status-pending", text:"Porudžbina je kreirana. Uplati tačan iznos na račun ispod i obavezno upiši referencu porudžbine. Promocija se NE aktivira dok administrator ne proveri da je uplata stigla."},
  payment_submitted: {label:"Uplata prijavljena — čeka proveru", cls:"status-pending", text:"Javio/la si da si izvršio/la uplatu. Administrator proverava da li je novac stigao na račun. Promocija će biti aktivirana tek nakon što uplata bude potvrđena."},
  paid:              {label:"Plaćeno — promocija aktivirana",   cls:"status-active",  text:"Uplata je potvrđena i promocija je aktivirana."},
  rejected:          {label:"Odbijeno",                         cls:"status-cancel",  text:"Uplata nije prihvaćena. Promocija nije aktivirana."},
  cancelled:         {label:"Otkazano",                         cls:"status-cancel",  text:"Porudžbina je otkazana. Možeš da napraviš novu porudžbinu."},
  expired:           {label:"Isteklo",                          cls:"status-sold",    text:"Porudžbina je istekla jer uplata nije stigla na vreme. Ako si ipak izvršio/la uplatu, pošalji potvrdu o uplati i referencu na "+PROMO_SUPPORT_EMAIL+"."},
};
function fmtRsd(n){ const v = Number(n)||0; return v.toLocaleString("sr-RS",{minimumFractionDigits: Number.isInteger(v)?0:2, maximumFractionDigits:2}) + " RSD"; }
// "Izdvojeno" važi samo dok featured_until nije prošao (ne oslanjamo se na cron)
// PREMIUM važi samo dok premium_until nije prošao. Vrednost postavlja ISKLJUČIVO baza (admin_confirm_promo_payment) - ovo je samo prikaz.
function isPremiumNow(l){ return !!(l && l.premium_until && new Date(l.premium_until).getTime() > Date.now()); }
function isFeaturedNow(l){ return !!(l && l.is_featured && (!l.featured_until || new Date(l.featured_until).getTime() > Date.now())); }
function expirePromotionsOnce(){
  try{
    const last = Number(sessionStorage.getItem("pzmExpireAt")||0);
    if(Date.now()-last < 10*60*1000) return;
    sessionStorage.setItem("pzmExpireAt", String(Date.now()));
    Promise.resolve(sb.rpc("expire_promotions")).catch(()=>{});
  }catch(e){}
}

/* --- upiti --- */
async function fetchPromoPackages(kind){
  const { data, error } = await sb.from("promo_packages").select("*").eq("is_active", true).eq("kind", kind||"listing_promo").order("sort_order").order("created_at");
  if(error) throw error; return data||[];
}
async function promoCheckoutAvailable(){
  try{ const { data, error } = await sb.rpc("promo_checkout_available"); if(error) throw error; return data===true; }catch(e){ return false; }
}
async function fetchPromoOrders(f){
  let q = sb.from("promo_orders").select("*").order("created_at",{ascending:false}).limit(f&&f.limit||300);
  if(f&&f.listing) q = q.eq("listing_id", f.listing);
  if(f&&f.id) q = q.eq("id", f.id);
  if(f&&f.kind) q = q.eq("kind", f.kind);
  if(f&&f.storeId) q = q.eq("store_id", f.storeId);
  const { data, error } = await q; if(error) throw error; return data||[];
}
function copyText(txt){
  const done = ()=>toast("Kopirano");
  try{
    if(navigator.clipboard && window.isSecureContext !== false){ navigator.clipboard.writeText(txt).then(done, ()=>copyTextFallback(txt)); return; }
  }catch(e){}
  copyTextFallback(txt);
}
function copyTextFallback(txt){
  const ta = document.createElement("textarea"); ta.value = txt; ta.style.position="fixed"; ta.style.opacity="0"; document.body.appendChild(ta); ta.select();
  try{ document.execCommand("copy"); toast("Kopirano"); }catch(e){ toast("Kopiranje nije uspelo — označi tekst ručno"); }
  document.body.removeChild(ta);
}
function promoLoginPrompt(hash){
  Store.set("postLoginRedirect", hash);
  return `<div class="wrap"><div class="auth-card"><h2>Prijava potrebna</h2><p class="sub">Prijavi se da bi promovisao oglas.</p><a href="#/prijava" class="btn btn-primary btn-block">Prijavi se</a></div></div>`;
}

/* --- korisnik: stranica "Promoviši oglas" --- */
let promoSel = null;
async function viewPromote(listingId){
  if(!ME.id) return promoLoginPrompt("#/promocija/"+listingId);
  const l = await fetchListing(listingId);
  if(!l || l.seller_id!==ME.id) return `<div class="wrap section">${emptyState("🔎","Oglas nije pronađen","Možeš da promovišeš samo svoje oglase.", `<a href="#/moj-pazarime/oglasi" class="btn btn-primary" style="margin-top:14px;">Moji oglasi</a>`)}</div>`;
  let packages = [], avail = false, orders = [];
  try{ [packages, avail, orders] = await Promise.all([fetchPromoPackages("listing_promo"), promoCheckoutAvailable(), fetchPromoOrders({listing:l.id})]); }catch(e){ console.error(e); }
  const open = orders.find(o=>o.status==="awaiting_payment"||o.status==="payment_submitted");
  const active = l.status==="active";
  promoSel = {listingId:l.id, packageId:null};
  let action = "";
  if(open){
    const m = PROMO_STATUS[open.status];
    action = `<div class="notice">${promoStatusPill(open.status, open.kind)}<p style="margin:8px 0 12px;">${esc(m.text)}</p><a class="btn btn-primary" href="#/promocija/porudzbina/${open.id}">${open.status==="awaiting_payment"?"Prikaži uputstvo za uplatu":"Pogledaj porudžbinu"}</a></div>`;
  } else if(!active){
    action = `<div class="notice warn">Samo aktivan oglas može da se promoviše.</div>`;
  } else if(!avail){
    action = `<div class="notice warn"><b>Plaćanje promocije je trenutno nedostupno.</b><br>Uplata na račun još nije omogućena. Pokušaj ponovo kasnije.</div>`;
  } else if(!packages.length){
    action = `<div class="notice warn">Trenutno nema dostupnih paketa promocije.</div>`;
  } else {
    action = `<h3 style="font-size:15px; margin:18px 0 10px;">Izaberi paket</h3>
      <div class="promo-grid">${packages.map(p=>`<button type="button" class="promo-pkg" id="pkg_${p.id}" onclick="promoSelect('${p.id}')" aria-pressed="false">
        <div class="promo-pkg-name">${esc(p.name)}${p.is_premium?' <span class="chip chip-premium">PREMIUM</span>':""}</div>
        ${p.description?`<div class="promo-pkg-desc">${esc(p.description)}</div>`:""}
        <div class="promo-pkg-meta"><span>${p.duration_days} ${p.duration_days===1?"dan":"dana"}</span><b>${fmtRsd(p.price_rsd)}</b></div></button>`).join("")}</div>
      <div id="promoSummary" class="promo-summary" style="display:none;"></div>`;
    window.__promoPackages = packages;
  }
  const hist = orders.filter(o=>!open || o.id!==open.id).slice(0,5);
  return `<div class="wrap section"><div style="max-width:720px; margin:0 auto;">
    <a href="#/moj-pazarime/oglasi" style="font-size:12.5px; color:var(--ink-faint);">← Moji oglasi</a>
    <h2 style="font-size:22px; margin:10px 0 14px;">Promoviši oglas</h2>
    <div class="list-row" style="margin-bottom:12px;"><div class="thumb-sm">${l.images&&l.images.length?`<img src="${esc(l.images[0])}" style="width:100%;height:100%;object-fit:cover;border-radius:9px;">`:(CATBYID[l.category]?CATBYID[l.category].emoji:"📦")}</div>
      <div class="info"><div class="t">${esc(l.title)}</div><div class="stats"><span>${listingPriceText(l)}</span></div></div></div>
    ${isPremiumNow(l)?`<div class="notice" style="margin-bottom:12px;">🔥 Oglas je trenutno PREMIUM do <b>${fmtDateTime(l.premium_until)}</b>. Nova Premium promocija počinje kada postojeća istekne.</div>`:""}
    ${isFeaturedNow(l)?`<div class="notice" style="margin-bottom:12px;">⭐ Oglas je trenutno izdvojen${l.featured_until?` do <b>${fmtDateTime(l.featured_until)}</b>`:""}. Nova plaćena promocija počinje kada postojeća istekne.</div>`:""}
    <p style="font-size:13.5px; color:var(--ink-dim); line-height:1.6; margin-bottom:6px;">Izdvojeni oglasi se ističu oznakom „Izdvojeno“. Plaćanje se vrši uplatom na račun. <b>Promocija se aktivira tek kada administrator proveri da je uplata stigla.</b></p>
    ${action}
    ${hist.length?`<h3 style="font-size:15px; margin:26px 0 10px;">Prethodne porudžbine za ovaj oglas</h3>${hist.map(promoOrderRowHtml).join("")}`:""}
  </div></div>`;
}
function promoSelect(id){
  const p = (window.__promoPackages||[]).find(x=>x.id===id); if(!p || !promoSel) return;
  promoSel.packageId = id;
  document.querySelectorAll(".promo-pkg").forEach(b=>{ const on = b.id==="pkg_"+id; b.classList.toggle("selected", on); b.setAttribute("aria-pressed", on?"true":"false"); });
  const box = document.getElementById("promoSummary"); if(!box) return;
  box.style.display = "";
  box.innerHTML = `<div class="order-label">Pregled porudžbine</div>
    <div class="order-line"><span>Oglas</span><span style="text-align:right; max-width:65%;">${esc(document.querySelector(".list-row .t").textContent)}</span></div>
    <div class="order-line"><span>Paket</span><span>${esc(p.name)}</span></div>
    <div class="order-line"><span>Trajanje</span><span>${p.duration_days} ${p.duration_days===1?"dan":"dana"}</span></div>
    <div class="order-total" style="font-size:16px;"><span>Za uplatu</span><span>${fmtRsd(p.price_rsd)}</span></div>
    <button id="promoBtn" class="btn btn-primary btn-block" style="margin-top:14px;" onclick="promoCreateOrder()">Potvrdi porudžbinu i prikaži uputstvo za uplatu</button>
    <p style="font-size:12px; color:var(--ink-faint); margin-top:10px; line-height:1.5;">Potvrdom se kreira porudžbina sa jedinstvenom referencom. Promocija se ne aktivira dok uplata ne bude proverena.</p>`;
}
const promoCreateOrder = guarded("promoCreate", async ()=>{
  if(!promoSel || !promoSel.packageId) return;
  const p = (window.__promoPackages||[]).find(x=>x.id===promoSel.packageId);
  const btn = document.getElementById("promoBtn"); if(btn){ btn.disabled = true; btn.textContent = "Kreiranje porudžbine..."; }
  try{
    const { data, error } = await sb.rpc("create_promo_order", { p_listing_id: promoSel.listingId, p_package_id: promoSel.packageId, p_expected_price: p?p.price_rsd:null });
    if(error) throw error;
    location.hash = "/promocija/porudzbina/" + data.id;
  }catch(e){
    toast("Greška: " + ((e&&e.message)||"pokušaj ponovo"));
    if(btn){ btn.disabled = false; btn.textContent = "Potvrdi porudžbinu i prikaži uputstvo za uplatu"; }
  }
});
function promoOrderRowHtml(o){
  const title = o.kind==="listing_promo" || !o.kind ? `${esc(o.package_name)} — ${fmtRsd(o.price_rsd)}` : `${esc(PROMO_KIND[o.kind])}: ${esc(o.store_name||"")} — ${fmtRsd(o.price_rsd)}`;
  return `<a class="list-row" href="#/promocija/porudzbina/${o.id}" style="text-decoration:none; color:inherit;">
    <div class="info"><div class="t">${title}</div>
    <div class="stats"><span>${esc(o.reference)}</span><span>${fmtDateTime(o.created_at)}</span></div></div>
    <div>${promoStatusPill(o.status, o.kind)}</div></a>`;
}

/* --- korisnik: porudžbina + uputstvo za uplatu --- */
function promoPayText(o){
  const s = o.payment_snapshot||{};
  return [`Primalac: ${s.recipient_name||""}`, `Broj računa: ${s.account_number||""}`, s.bank_name?`Banka: ${s.bank_name}`:null,
          `Iznos: ${fmtRsd(o.price_rsd)}`, `Svrha uplate: ${s.purpose||""}`, `Referenca: ${o.reference}`].filter(Boolean).join("\n");
}
function copyPromoDetails(){ if(window.__promoOrder) copyText(promoPayText(window.__promoOrder)); }
function copyPromoRef(){ if(window.__promoOrder) copyText(window.__promoOrder.reference); }
async function viewPromoOrder(id){
  if(!ME.id) return promoLoginPrompt("#/promocija/porudzbina/"+id);
  let o = null;
  try{ [o] = await fetchPromoOrders({id}); }catch(e){ console.error(e); }
  if(!o || o.user_id!==ME.id) return `<div class="wrap section">${emptyState("🧾","Porudžbina nije pronađena","", `<a href="#/moj-pazarime/promocije" class="btn btn-primary" style="margin-top:14px;">Moje uplate</a>`)}</div>`;
  window.__promoOrder = o;
  const isListing = !o.kind || o.kind==="listing_promo";
  const m = promoStatusInfo(o);
  const s = o.payment_snapshot||{};
  const showPay = o.status==="awaiting_payment" || o.status==="payment_submitted";
  const what = isListing ? "Promocija se aktivira" : (o.kind==="store_open" ? "Prodavnica se otvara" : "Pretplata se produžava");
  let extra = "";
  if(o.status==="paid"){
    if(isListing) extra = `<div class="notice" style="margin-top:12px;">Promocija je aktivna od <b>${fmtDateTime(o.promo_starts_at)}</b> do <b>${fmtDateTime(o.promo_ends_at)}</b>.</div>`;
    else if(o.kind==="store_open") extra = `<div class="notice" style="margin-top:12px;">Prodavnica je otvorena. Pretplata je aktivna od <b>${fmtDateTime(o.promo_starts_at)}</b> do <b>${fmtDateTime(o.promo_ends_at)}</b>.<div style="margin-top:10px;"><a class="btn btn-primary btn-sm" href="#/moja-prodavnica/podesavanja">Dopuni podatke prodavnice</a> <a class="btn btn-outline btn-sm" href="#/moja-prodavnica">Otvori moju prodavnicu</a></div></div>`;
    else extra = `<div class="notice" style="margin-top:12px;">Pretplata je produžena do <b>${fmtDateTime(o.promo_ends_at)}</b>.<div style="margin-top:10px;"><a class="btn btn-outline btn-sm" href="#/moja-prodavnica/pretplata">Pogledaj pretplatu</a></div></div>`;
  }
  if(o.status==="rejected") extra = `<div class="notice warn" style="margin-top:12px;"><b>Razlog odbijanja:</b> ${esc(o.reject_reason||"")}<br><span style="font-size:12.5px;">Ako smatraš da je došlo do greške, pošalji potvrdu o uplati i referencu na <a href="mailto:${PROMO_SUPPORT_EMAIL}" style="color:var(--blue);">${PROMO_SUPPORT_EMAIL}</a>.</span></div>`;
  const subject = isListing
    ? `<div class="pay-row" style="margin-top:12px;"><span>Oglas</span>${o.listing_id?`<a href="#/oglas/${o.listing_id}" style="font-weight:600;">${esc(o.listing_title)}</a>`:`<b>${esc(o.listing_title)}</b>`}</div>`
    : `<div class="pay-row" style="margin-top:12px;"><span>Prodavnica</span><b>${esc(o.store_name||"")}</b></div>
       <div class="pay-row"><span>Adresa</span><b>pazarime.rs/prodavnica/${esc(o.store_slug||"")}</b></div>
       <div class="pay-row"><span>Vrsta</span><b>${esc(PROMO_KIND[o.kind]||"")}</b></div>`;
  const payBox = !showPay ? "" : `<div class="pay-box">
      <h3 style="font-size:15px; margin-bottom:10px;">Podaci za uplatu</h3>
      <div class="pay-row"><span>Primalac</span><b>${esc(s.recipient_name||"")}</b></div>
      <div class="pay-row"><span>Broj računa</span><b>${esc(s.account_number||"")}</b></div>
      ${s.bank_name?`<div class="pay-row"><span>Banka</span><b>${esc(s.bank_name)}</b></div>`:""}
      <div class="pay-row"><span>Iznos</span><b>${fmtRsd(o.price_rsd)}</b></div>
      <div class="pay-row"><span>Svrha uplate</span><b>${esc(s.purpose||"")}</b></div>
      <div class="pay-row pay-ref"><span>Referenca</span><b id="promoRef">${esc(o.reference)}</b></div>
      <div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:12px;">
        <button class="btn btn-primary btn-sm" onclick="copyPromoDetails()">📋 Kopiraj podatke za uplatu</button>
        <button class="btn btn-outline btn-sm" onclick="copyPromoRef()">Kopiraj referencu</button>
      </div>
      <div class="notice warn" style="margin-top:14px;"><b>Važno:</b> u svrhu uplate obavezno upiši tačnu referencu <b>${esc(o.reference)}</b>. Bez nje uplatu ne možemo da povežemo sa tvojom porudžbinom.</div>
      ${s.instructions?`<div style="margin-top:12px; font-size:13.5px; line-height:1.6; white-space:pre-wrap;">${esc(s.instructions)}</div>`:""}
      <h4 style="font-size:13.5px; margin:16px 0 6px;">Kako da uplatiš</h4>
      <ol style="font-size:13.5px; line-height:1.7; padding-left:20px; margin:0;">
        <li>U e-bankingu ili u banci napravi uplatu na račun primaoca iz gornjih podataka.</li>
        <li>Uplati tačan iznos: <b>${fmtRsd(o.price_rsd)}</b>.</li>
        <li>U svrhu uplate upiši referencu <b>${esc(o.reference)}</b>.</li>
        <li>Kada uplatiš, klikni „Uplatio/la sam“ ispod. ${what} tek nakon što administrator proveri uplatu.</li>
      </ol>
      <h4 style="font-size:13.5px; margin:16px 0 6px;">Pogrešna referenca ili uplata nije potvrđena?</h4>
      <p style="font-size:13.5px; line-height:1.6; margin:0;">Ako si pogrešno upisao/la referencu ili uplata još nije potvrđena, pošalji potvrdu o uplati i referencu <b>${esc(o.reference)}</b> na <a href="mailto:${PROMO_SUPPORT_EMAIL}" style="color:var(--blue);">${PROMO_SUPPORT_EMAIL}</a>.</p>
    </div>`;
  const actions = o.status==="awaiting_payment" ? `<div class="pay-box" style="margin-top:14px;">
      <h4 style="font-size:13.5px; margin-bottom:8px;">Uplatio/la si?</h4>
      <textarea id="promoNote" maxlength="300" placeholder="Napomena (opciono), npr. ime uplatioca ili datum uplate" style="width:100%; min-height:64px;"></textarea>
      <div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:10px;">
        <button class="btn btn-primary" onclick="promoSubmitPayment('${o.id}')">Uplatio/la sam</button>
        <button class="btn btn-ghost" onclick="promoCancelOrder('${o.id}')">Otkaži porudžbinu</button>
      </div>
      <p style="font-size:12px; color:var(--ink-faint); margin-top:8px;">Klik na „Uplatio/la sam“ samo javlja administratoru da proveri uplatu — ništa se ne aktivira automatski.</p></div>` : "";
  return `<div class="wrap section"><div style="max-width:720px; margin:0 auto;">
    <a href="#/moj-pazarime/promocije" style="font-size:12.5px; color:var(--ink-faint);">← Moje uplate</a>
    <h2 style="font-size:22px; margin:10px 0 12px;">${isListing?"Porudžbina promocije":(o.kind==="store_open"?"Otvaranje prodavnice":"Obnova pretplate")}</h2>
    <div class="pay-box">
      <div style="display:flex; justify-content:space-between; gap:10px; flex-wrap:wrap; align-items:center;"><b style="font-size:15px; overflow-wrap:anywhere;">${esc(o.reference)}</b>${promoStatusPill(o.status, o.kind)}</div>
      <p style="font-size:13.5px; line-height:1.6; margin:10px 0 0;">${esc(m.text)}</p>${extra}
      ${subject}
      <div class="pay-row"><span>Paket</span><b>${esc(o.package_name)} (${o.duration_days} ${o.duration_days===1?"dan":"dana"})</b></div>
      <div class="pay-row"><span>Iznos</span><b>${fmtRsd(o.price_rsd)}</b></div>
      <div class="pay-row"><span>Kreirano</span><b>${fmtDateTime(o.created_at)}</b></div>
      ${o.user_note&&showPay?`<div class="pay-row"><span>Tvoja napomena</span><b>${esc(o.user_note)}</b></div>`:""}
    </div>
    ${payBox ? `<div style="margin-top:14px;">${payBox}</div>` : ""}
    ${actions}
  </div></div>`;
}
const promoSubmitPayment = guarded("promoSubmit", async (id)=>{
  const note = (document.getElementById("promoNote")||{}).value || "";
  try{ const { error } = await sb.rpc("submit_promo_payment", { p_order_id:id, p_note:note }); if(error) throw error; toast("Hvala! Administrator će proveriti uplatu."); route(); }
  catch(e){ toast("Greška: "+((e&&e.message)||"pokušaj ponovo")); }
});
const promoCancelOrder = guarded("promoCancel", async (id)=>{
  if(!confirm("Otkazati porudžbinu? Ako si već uplatio/la, nemoj da otkazuješ — klikni „Uplatio/la sam“.")) return;
  try{ const { error } = await sb.rpc("cancel_promo_order", { p_order_id:id }); if(error) throw error; toast("Porudžbina je otkazana"); route(); }
  catch(e){ toast("Greška: "+((e&&e.message)||"pokušaj ponovo")); }
});
/* --- korisnik: Moj PazariMe → Promocije --- */
async function renderMyPromoOrders(){
  let orders = []; try{ orders = await fetchPromoOrders({}); }catch(e){ console.error(e); }
  return `<h2 style="font-size:20px;margin-bottom:6px;">Moje uplate</h2>
    <p style="font-size:13px; color:var(--ink-dim); margin-bottom:14px; line-height:1.5;">Promocija oglasa, otvaranje prodavnice i obnova pretplate aktiviraju se tek nakon što administrator potvrdi uplatu. Status svake porudžbine vidiš ovde.</p>
    ${orders.length ? orders.map(promoOrderRowHtml).join("") : emptyState("⭐","Još nemaš uplata.","Promoviši oglas ili otvori prodavnicu.", `<a href="#/moj-pazarime/oglasi" class="btn btn-primary" style="margin-top:14px;">Moji oglasi</a>`)}`;
}

/* ---------------- ADMIN: Uplate ---------------- */
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function adminPayTabs(cur){
  const t = [["", "Porudžbine"],["packages","Paketi promocije"],["store-packages","Paketi prodavnice"],["settings","Podešavanja računa"]];
  return `<div class="type-tabs" style="margin-bottom:16px;">${t.map(([k,l])=>`<a class="type-tab${cur===k?" active":""}" href="#/admin/payments${k?"/"+k:""}">${l}</a>`).join("")}</div>`;
}
async function renderAdminPayments(subId, params){
  if(subId==="packages") return adminPayTabs("packages") + await renderAdminPromoPackages("listing_promo");
  if(subId==="store-packages") return adminPayTabs("store-packages") + await renderAdminPromoPackages("store_subscription");
  if(subId==="settings") return adminPayTabs("settings") + await renderAdminPaymentSettings();
  if(subId && UUID_RE.test(subId)) return await renderAdminPromoOrder(subId);
  return adminPayTabs("") + await renderAdminPromoOrders(params||new URLSearchParams());
}
function promoSubjectHtml(o){
  if(!o.kind || o.kind==="listing_promo") return o.listing_id?`<a href="#/oglas/${o.listing_id}">${esc(o.listing_title||"")}</a>`:esc(o.listing_title||"—");
  const nm = o.store_id ? `<a href="#/admin/stores/${o.store_id}">${esc(o.store_name||"")}</a>` : esc(o.store_name||"");
  return `${nm}<div style="font-size:11.5px;color:var(--ink-faint);">/${esc(o.store_slug||"")}</div>`;
}
async function renderAdminPromoOrders(params){
  const status = params.get("status")||"", kind = params.get("kind")||"", q = (params.get("q")||"").trim().toLowerCase(), from = params.get("from")||"", to = params.get("to")||"";
  let query = sb.from("promo_orders").select("*").order("created_at",{ascending:false}).limit(500);
  if(status) query = query.eq("status", status);
  if(kind) query = query.eq("kind", kind);
  if(from) query = query.gte("created_at", from+"T00:00:00");
  if(to) query = query.lte("created_at", to+"T23:59:59");
  const { data, error } = await query; if(error) throw error;
  let rows = data||[];
  if(q) rows = rows.filter(o=>[o.reference,o.user_email,o.user_name,o.listing_title,o.package_name,o.store_name,o.store_slug].some(x=>String(x||"").toLowerCase().includes(q)));
  const pending = (data||[]).filter(o=>o.status==="payment_submitted").length;
  const stOpts = Object.entries(PROMO_STATUS).map(([k,v])=>`<option value="${k}" ${status===k?"selected":""}>${esc((STORE_ORDER_STATUS[k]||v).label)} / ${esc(v.label)}</option>`).join("");
  const kOpts = Object.entries(PROMO_KIND).map(([k,v])=>`<option value="${k}" ${kind===k?"selected":""}>${esc(v)}</option>`).join("");
  return `<div style="display:flex; justify-content:space-between; align-items:center; gap:10px; flex-wrap:wrap; margin-bottom:12px;"><h2 style="font-size:20px;">Uplate (${rows.length})</h2>
      ${pending?`<span class="chip" style="background:var(--warn-bg,#fff4d6); color:var(--warn);">${pending} čeka proveru</span>`:""}</div>
    <form class="admin-filters" onsubmit="adminPayFilter(event)" style="display:flex; gap:8px; flex-wrap:wrap; margin-bottom:14px;">
      <input type="text" id="apQ" placeholder="Referenca, korisnik, oglas, prodavnica..." value="${esc(params.get("q")||"")}" style="padding:9px 14px;border-radius:8px;border:1px solid var(--border);min-width:200px;flex:1;">
      <select id="apKind"><option value="">Sve vrste</option>${kOpts}</select>
      <select id="apStatus"><option value="">Svi statusi</option>${stOpts}</select>
      <input type="date" id="apFrom" value="${esc(from)}" aria-label="Od datuma"><input type="date" id="apTo" value="${esc(to)}" aria-label="Do datuma">
      <button class="btn btn-primary btn-sm" type="submit">Filtriraj</button>
      ${(q||status||kind||from||to)?`<a class="btn btn-ghost btn-sm" href="#/admin/payments">Poništi</a>`:""}
    </form>
    ${rows.length ? `<div class="overflow-x"><table class="admin-table"><thead><tr><th>Referenca</th><th>Vrsta</th><th>Korisnik</th><th>Oglas / prodavnica</th><th>Paket</th><th>Iznos</th><th>Kreirano</th><th>Status</th><th>Period</th><th></th></tr></thead><tbody>
      ${rows.map(o=>`<tr>
        <td><a href="#/admin/payments/${o.id}" style="font-weight:600;">${esc(o.reference)}</a></td>
        <td style="font-size:12.5px;">${esc(PROMO_KIND[o.kind||"listing_promo"]||"")}</td>
        <td>${esc(o.user_name||"—")}<div style="font-size:11.5px;color:var(--ink-faint);">${esc(o.user_email||"")}</div></td>
        <td>${promoSubjectHtml(o)}</td>
        <td>${esc(o.package_name)}<div style="font-size:11.5px;color:var(--ink-faint);">${o.duration_days} d</div></td>
        <td>${fmtRsd(o.price_rsd)}</td><td>${fmtDateTime(o.created_at)}</td><td>${promoStatusPill(o.status, o.kind)}</td>
        <td style="font-size:12px;">${o.promo_starts_at?`${fmtDateTime(o.promo_starts_at)}<br>→ ${fmtDateTime(o.promo_ends_at)}`:"—"}</td>
        <td><a class="btn btn-outline btn-sm" href="#/admin/payments/${o.id}">Detalji</a></td></tr>`).join("")}
      </tbody></table></div>` : emptyState("🧾","Nema porudžbina za prikaz.","")}`;
}
function adminPayFilter(ev){
  ev.preventDefault();
  const p = new URLSearchParams();
  [["q","apQ"],["kind","apKind"],["status","apStatus"],["from","apFrom"],["to","apTo"]].forEach(([k,id])=>{ const v = document.getElementById(id).value.trim(); if(v) p.set(k,v); });
  location.hash = "/admin/payments" + (p.toString()?"?"+p.toString():"");
}
async function renderAdminPromoOrder(id){
  const [o] = await fetchPromoOrders({id});
  if(!o) return emptyState("🧾","Porudžbina nije pronađena","");
  const { data: ev } = await sb.from("promo_payment_events").select("*").eq("order_id", id).order("created_at");
  window.__adminPromoOrder = o;
  const isListing = !o.kind || o.kind==="listing_promo";
  const open = ["awaiting_payment","payment_submitted","expired"].includes(o.status);
  const EV = {created:"Kreirana",submitted:"Korisnik javio uplatu",confirmed:"Uplata potvrđena",rejected:"Odbijena",cancelled:"Otkazana",expired:"Istekla"};
  const s = o.payment_snapshot||{};
  const effect = isListing ? "Promocija će odmah biti aktivirana" : (o.kind==="store_open" ? "Prodavnica će odmah biti otvorena i javno vidljiva" : "Pretplata prodavnice će odmah biti produžena");
  return `<a href="#/admin/payments" style="font-size:12.5px; color:var(--ink-faint);">← Nazad na uplate</a>
    <div class="pay-box" style="margin-top:12px;">
      <div style="display:flex; justify-content:space-between; gap:10px; flex-wrap:wrap; align-items:center;"><h2 style="font-size:18px; overflow-wrap:anywhere;">${esc(o.reference)}</h2>${promoStatusPill(o.status, o.kind)}</div>
      <div class="pay-row"><span>Vrsta</span><b>${esc(PROMO_KIND[o.kind||"listing_promo"]||"")}</b></div>
      <div class="pay-row"><span>Korisnik</span><b>${esc(o.user_name||"—")} <span style="font-weight:400;">${esc(o.user_email||"")}</span></b></div>
      ${isListing
        ? `<div class="pay-row"><span>Oglas</span>${o.listing_id?`<a href="#/oglas/${o.listing_id}" style="font-weight:600;">${esc(o.listing_title)}</a>`:`<b>${esc(o.listing_title)} (obrisan)</b>`}</div>`
        : `<div class="pay-row"><span>Prodavnica</span>${o.store_id?`<a href="#/admin/stores/${o.store_id}" style="font-weight:600;">${esc(o.store_name||"")}</a>`:`<b>${esc(o.store_name||"")}</b>`}</div>
           <div class="pay-row"><span>Adresa</span><b>/${esc(o.store_slug||"")}</b></div>
           ${o.kind==="store_open"?`<div class="pay-row"><span>Kategorija / grad</span><b>${esc((CATBYID[o.store_category]||{}).name||o.store_category||"—")} / ${esc(o.store_city||"—")}</b></div>`:""}`}
      <div class="pay-row"><span>Paket</span><b>${esc(o.package_name)} (${o.duration_days} d)</b></div>
      <div class="pay-row"><span>Iznos</span><b>${fmtRsd(o.price_rsd)}</b></div>
      <div class="pay-row"><span>Svrha uplate</span><b>${esc(s.purpose||"")}</b></div>
      <div class="pay-row"><span>Kreirano</span><b>${fmtDateTime(o.created_at)}</b></div>
      ${o.user_note?`<div class="pay-row"><span>Napomena korisnika</span><b>${esc(o.user_note)}</b></div>`:""}
      ${o.promo_starts_at?`<div class="pay-row"><span>${isListing?"Promocija":"Pretplata"}</span><b>${fmtDateTime(o.promo_starts_at)} → ${fmtDateTime(o.promo_ends_at)}</b></div>`:""}
      ${o.confirmed_at?`<div class="pay-row"><span>Potvrđeno</span><b>${fmtDateTime(o.confirmed_at)}</b></div>`:""}
      ${o.reject_reason?`<div class="pay-row"><span>Razlog odbijanja</span><b>${esc(o.reject_reason)}</b></div>`:""}
    </div>
    ${open?`<div class="pay-box" style="margin-top:14px;">
      <h3 style="font-size:15px; margin-bottom:8px;">Obrada uplate</h3>
      <p style="font-size:13px; color:var(--ink-dim); line-height:1.5; margin-bottom:10px;">Potvrdi samo ako je novac <b>stvarno stigao na račun</b> u iznosu ${fmtRsd(o.price_rsd)} sa referencom <b>${esc(o.reference)}</b>. Slika uplatnice nije dokaz. ${effect}.</p>
      <textarea id="apNote" maxlength="500" placeholder="Napomena / razlog odbijanja" style="width:100%; min-height:64px;"></textarea>
      <div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:10px;">
        <button class="btn btn-primary" onclick="adminConfirmPromo('${o.id}')">✔ Potvrdi uplatu</button>
        <button class="btn btn-danger" onclick="adminRejectPromo('${o.id}')">Odbij uplatu</button>
      </div></div>`:""}
    <h3 style="font-size:15px; margin:20px 0 8px;">Istorija</h3>
    ${(ev&&ev.length)?`<div class="overflow-x"><table class="admin-table"><thead><tr><th>Vreme</th><th>Događaj</th><th>Status</th><th>Napomena</th></tr></thead><tbody>${ev.map(e=>`<tr><td>${fmtDateTime(e.created_at)}</td><td>${esc(EV[e.event]||e.event)}</td><td>${esc((e.from_status||"—")+" → "+(e.to_status||"—"))}</td><td>${esc(e.note||"")}</td></tr>`).join("")}</tbody></table></div>`:emptyState("📜","Nema događaja","")}`;
}
const adminConfirmPromo = guarded("adminConfirmPromo", async (id)=>{
  const o = window.__adminPromoOrder; if(!o) return;
  const effect = (!o.kind||o.kind==="listing_promo") ? `${o.is_premium?"PREMIUM promocija":"Promocija"} će odmah biti aktivirana na ${o.duration_days} d.` : (o.kind==="store_open" ? `Prodavnica „${o.store_name}“ će odmah biti otvorena (pretplata ${o.duration_days} d).` : `Pretplata prodavnice će biti produžena za ${o.duration_days} d.`);
  if(!confirm(`Potvrđuješ da je uplata od ${fmtRsd(o.price_rsd)} sa referencom ${o.reference} STVARNO stigla na račun?\n${effect}`)) return;
  try{ const { error } = await sb.rpc("admin_confirm_promo_payment", { p_order_id:id, p_note:(document.getElementById("apNote")||{}).value||null }); if(error) throw error; toast("Uplata je potvrđena"); route(); }
  catch(e){ toast("Greška: "+((e&&e.message)||"pokušaj ponovo")); route(); }
});
const adminRejectPromo = guarded("adminRejectPromo", async (id)=>{
  const reason = ((document.getElementById("apNote")||{}).value||"").trim();
  if(reason.length<3){ toast("Unesi razlog odbijanja u polje za napomenu"); return; }
  if(!confirm("Odbiti uplatu? Korisnik će videti razlog, a ništa neće biti aktivirano.")) return;
  try{ const { error } = await sb.rpc("admin_reject_promo_payment", { p_order_id:id, p_reason:reason }); if(error) throw error; toast("Uplata je odbijena"); route(); }
  catch(e){ toast("Greška: "+((e&&e.message)||"pokušaj ponovo")); route(); }
});

/* --- admin: paketi (po vrsti) --- */
async function renderAdminPromoPackages(kind){
  const isStore = kind==="store_subscription";
  const { data, error } = await sb.from("promo_packages").select("*").eq("kind", kind).order("sort_order").order("created_at"); if(error) throw error;
  const pk = data||[]; window.__adminPromoPkgs = pk; window.__adminPkgKind = kind;
  return `<div style="display:flex; justify-content:space-between; align-items:center; gap:10px; flex-wrap:wrap; margin-bottom:12px;"><h2 style="font-size:20px;">${isStore?"Paketi prodavnice (pretplata)":"Paketi promocije oglasa"} (${pk.length})</h2>
      <button class="btn btn-primary btn-sm" onclick="adminPkgForm(null)">+ Novi paket</button></div>
    <div id="adminPkgForm"></div>
    ${pk.length?`<div class="overflow-x"><table class="admin-table"><thead><tr><th>Redosled</th><th>Naziv</th>${isStore?"":"<th>Vrsta</th>"}<th>Trajanje</th><th>Cena</th><th>Status</th><th>Akcije</th></tr></thead><tbody>
      ${pk.map((p,i)=>`<tr>
        <td style="white-space:nowrap;"><button class="btn btn-ghost btn-sm" ${i===0?"disabled":""} onclick="adminMovePkg('${p.id}',-1)" aria-label="Pomeri gore">▲</button><button class="btn btn-ghost btn-sm" ${i===pk.length-1?"disabled":""} onclick="adminMovePkg('${p.id}',1)" aria-label="Pomeri dole">▼</button></td>
        <td><b>${esc(p.name)}</b>${p.description?`<div style="font-size:11.5px;color:var(--ink-faint);">${esc(p.description)}</div>`:""}</td>
        ${isStore?"":`<td>${p.is_premium?'<span class="chip chip-premium">PREMIUM</span>':'<span class="chip">Standardna</span>'}</td>`}
        <td>${p.duration_days} d</td><td>${fmtRsd(p.price_rsd)}</td>
        <td><span class="status-pill ${p.is_active?"status-active":"status-sold"}">${p.is_active?"Aktivan":"Isključen"}</span></td>
        <td style="white-space:nowrap;"><button class="btn btn-outline btn-sm" onclick="adminPkgForm('${p.id}')">Uredi</button>
          <button class="btn btn-ghost btn-sm" onclick="adminTogglePkg('${p.id}',${!p.is_active})">${p.is_active?"Isključi":"Uključi"}</button></td></tr>`).join("")}
    </tbody></table></div>`:emptyState(isStore?"🏪":"📦","Još nema paketa.","Dodaj prvi paket.")}
    <p style="font-size:12px; color:var(--ink-faint); margin-top:12px; line-height:1.5;">Izmena cene ili trajanja ne menja već kreirane porudžbine (one čuvaju cenu i trajanje iz trenutka kreiranja).${isStore?" Trajanje pretplate je u danima (npr. 30, 90, 180 ili 365).":""} Isključen paket se ne prikazuje korisnicima.</p>`;
}
function adminPkgForm(id){
  const box = document.getElementById("adminPkgForm"); if(!box) return;
  const p = id ? (window.__adminPromoPkgs||[]).find(x=>x.id===id) : null;
  if(!p && box.dataset.open==="1"){ box.innerHTML=""; box.dataset.open="0"; return; }
  box.dataset.open = "1";
  box.innerHTML = `<div class="pay-box" style="margin-bottom:16px; max-width:520px;">
    <h4 style="font-size:13.5px; margin-bottom:10px;">${p?"Uredi paket":"Novi paket"}</h4>
    <input type="hidden" id="pkId" value="${p?p.id:""}">
    <div class="form-group"><label>Naziv</label><input type="text" id="pkName" maxlength="80" value="${p?esc(p.name):""}"></div>
    ${window.__adminPkgKind!=="store_subscription"?`<div class="form-group"><label>Vrsta promocije</label><select id="pkType">
      <option value="standard" ${!p||!p.is_premium?"selected":""}>Standardna promocija</option>
      <option value="premium" ${p&&p.is_premium?"selected":""}>Premium promocija</option></select>
      <div style="font-size:11.5px;color:var(--ink-faint);margin-top:4px;line-height:1.45;">Premium oglas ima narandžasti okvir i oznaku „PREMIUM OGLAS“ i uvek se prikazuje pre standardno promovisanih oglasa.</div></div>`:""}
    <div class="form-group"><label>Opis (opciono)</label><textarea id="pkDesc" maxlength="500" style="min-height:64px;">${p&&p.description?esc(p.description):""}</textarea></div>
    <div class="form-row"><div class="form-group"><label>Cena (RSD)</label><input type="number" id="pkPrice" min="1" step="0.01" value="${p?esc(p.price_rsd):""}"></div>
      <div class="form-group"><label>Trajanje (dana)</label><input type="number" id="pkDays" min="1" max="365" step="1" value="${p?esc(p.duration_days):""}"></div></div>
    <label class="f-check"><input type="checkbox" id="pkActive" ${!p||p.is_active?"checked":""}> Aktivan (prikazuje se korisnicima)</label>
    <div style="display:flex; gap:8px; margin-top:12px;"><button class="btn btn-primary btn-sm" onclick="adminSavePkg()">Sačuvaj</button><button class="btn btn-ghost btn-sm" onclick="adminPkgForm(null)">Otkaži</button></div></div>`;
}
async function adminSavePkg(){
  const id = document.getElementById("pkId").value;
  const data = { name:document.getElementById("pkName").value.trim(), description:document.getElementById("pkDesc").value.trim(),
    price_rsd:document.getElementById("pkPrice").value, duration_days:document.getElementById("pkDays").value, is_active:document.getElementById("pkActive").checked,
    kind: window.__adminPkgKind || "listing_promo" };
  if(data.kind==="listing_promo"){ const t = document.getElementById("pkType"); if(t) data.is_premium = t.value==="premium"; }
  if(!data.name){ toast("Unesi naziv paketa"); return; }
  try{
    const { data:savedId, error } = await sb.rpc("admin_upsert_promo_package", { p_id:id||null, p_data:data }); if(error) throw error;
    if(typeof data.is_premium==="boolean"){   // read the row back: if the stored type differs from what was chosen, say so instead of pretending it worked
      const { data:chk, error:e2 } = await sb.from("promo_packages").select("is_premium").eq("id", savedId||id).maybeSingle();
      if(e2) throw e2;
      if(!chk || chk.is_premium!==data.is_premium){ toast("Greška: vrsta paketa nije sačuvana u bazi. Osveži stranicu i proveri paket."); route(); return; }
    }
    toast("Paket je sačuvan"); route(); }
  catch(e){ toast("Greška: "+((e&&e.message)||"pokušaj ponovo")); }
}
async function adminTogglePkg(id, active){
  try{ const { error } = await sb.rpc("admin_set_promo_package_active", { p_id:id, p_active:active }); if(error) throw error; toast(active?"Paket je uključen":"Paket je isključen"); route(); }
  catch(e){ toast("Greška: "+((e&&e.message)||"pokušaj ponovo")); }
}
async function adminMovePkg(id, dir){
  const ids = (window.__adminPromoPkgs||[]).map(p=>p.id), i = ids.indexOf(id), j = i+dir;
  if(i<0||j<0||j>=ids.length) return; [ids[i],ids[j]] = [ids[j],ids[i]];
  try{ const { error } = await sb.rpc("admin_reorder_promo_packages", { p_ids:ids }); if(error) throw error; route(); }
  catch(e){ toast("Greška: "+((e&&e.message)||"pokušaj ponovo")); }
}

/* --- admin: podešavanja računa --- */
async function renderAdminPaymentSettings(){
  const { data, error } = await sb.rpc("admin_get_payment_settings"); if(error) throw error;
  const s = data||{};
  return `<h2 style="font-size:20px; margin-bottom:6px;">Podešavanja uplate na račun</h2>
    <div class="notice ${s.configured&&s.enabled?"":"warn"}" style="margin-bottom:14px; max-width:620px;">${s.configured&&s.enabled
      ? "Uplate su <b>uključene</b>. Korisnici mogu da naprave porudžbinu promocije."
      : s.configured ? "Podaci su uneti, ali su uplate <b>isključene</b>. Korisnici ne mogu da naprave porudžbinu."
      : "Podaci o računu <b>nisu uneti</b>. Dok ne uneseš primaoca, broj računa i svrhu uplate, korisnici ne mogu da naprave porudžbinu i vide da je plaćanje nedostupno."}</div>
    <div class="pay-box" style="max-width:620px;">
      <label class="f-check"><input type="checkbox" id="psEnabled" ${s.enabled?"checked":""}> Uplate na račun su uključene</label>
      <div class="form-group" style="margin-top:12px;"><label>Primalac (naziv)</label><input type="text" id="psRecipient" maxlength="120" value="${esc(s.recipient_name||"")}"></div>
      <div class="form-group"><label>Broj računa</label><input type="text" id="psAccount" maxlength="40" value="${esc(s.account_number||"")}"></div>
      <div class="form-group"><label>Naziv banke (opciono)</label><input type="text" id="psBank" maxlength="120" value="${esc(s.bank_name||"")}"></div>
      <div class="form-group"><label>Svrha uplate (šablon)</label><input type="text" id="psPurpose" maxlength="140" value="${esc(s.purpose_template||"")}">
        <div style="font-size:11.5px; color:var(--ink-faint); margin-top:4px;">Možeš da koristiš <code>{referenca}</code> i <code>{paket}</code>. Referenca se uvek dodaje u svrhu uplate.</div></div>
      <div class="form-group"><label>Uputstvo za uplatu (opciono)</label><textarea id="psInstr" maxlength="1000" style="min-height:90px;">${esc(s.instructions||"")}</textarea></div>
      <div class="form-group"><label>Rok za uplatu (dana)</label><input type="number" id="psDays" min="1" max="60" step="1" value="${esc(s.pending_expiry_days||7)}">
        <div style="font-size:11.5px; color:var(--ink-faint); margin-top:4px;">Neplaćene porudžbine posle ovog roka dobijaju status „Isteklo“.</div></div>
      <button class="btn btn-primary" onclick="adminSavePaySettings()">Sačuvaj podešavanja</button>
    </div>
    <p style="font-size:12px; color:var(--ink-faint); margin-top:12px; max-width:620px; line-height:1.5;">Podatke o računu vide samo administratori i korisnik koji je kreirao porudžbinu (na stranici te porudžbine).</p>`;
}
async function adminSavePaySettings(){
  const v = id => document.getElementById(id).value;
  const data = { enabled:document.getElementById("psEnabled").checked, recipient_name:v("psRecipient"), account_number:v("psAccount"), bank_name:v("psBank"),
                 purpose_template:v("psPurpose"), instructions:v("psInstr"), pending_expiry_days:v("psDays") };
  try{ const { error } = await sb.rpc("admin_save_payment_settings", { p_data:data }); if(error) throw error; toast("Podešavanja su sačuvana"); route(); }
  catch(e){ toast("Greška: "+((e&&e.message)||"pokušaj ponovo")); }
}


/* ---------------- PLAĆENE PRODAVNICE: otvaranje i obnova pretplate ----------------
   Prodavnica se kreira ISKLJUČIVO u bazi, u admin_confirm_promo_payment, nakon što admin potvrdi uplatu.
   Klijent samo kreira porudžbinu (create_store_order / create_store_renewal_order) i prikazuje status. */
const PROMO_KIND = {listing_promo:"Promocija oglasa", store_open:"Otvaranje prodavnice", store_renew:"Obnova pretplate"};
const STORE_ORDER_STATUS = {
  awaiting_payment:  {label:"Čeka se uplata",  cls:"status-pending"},
  payment_submitted: {label:"Uplata na proveri", cls:"status-pending"},
  paid:              {label:"Uplata potvrđena", cls:"status-active"},
  rejected:          {label:"Uplata odbijena", cls:"status-cancel"},
  cancelled:         {label:"Otkazano", cls:"status-cancel"},
  expired:           {label:"Isteklo", cls:"status-sold"},
};
function promoStatusInfo(o){
  if(o.kind==="listing_promo" || !o.kind) return PROMO_STATUS[o.status] || {label:o.status, cls:"status-pending", text:""};
  const base = STORE_ORDER_STATUS[o.status] || {label:o.status, cls:"status-pending"};
  const open = o.kind==="store_open";
  const what = open ? "Prodavnica se NE otvara" : "Pretplata se NE produžava";
  const text = {
    awaiting_payment: `Porudžbina je kreirana. Uplati tačan iznos na račun ispod i obavezno upiši referencu porudžbine. ${what} dok administrator ne proveri da je uplata stigla.`,
    payment_submitted: `Javio/la si da si izvršio/la uplatu. Administrator proverava da li je novac stigao na račun. ${open?"Prodavnica će biti otvorena":"Pretplata će biti produžena"} tek nakon što uplata bude potvrđena.`,
    paid: open ? "Uplata je potvrđena, prodavnica je otvorena i pretplata je aktivna." : "Uplata je potvrđena i pretplata je produžena.",
    rejected: open ? "Uplata nije prihvaćena. Prodavnica nije otvorena." : "Uplata nije prihvaćena. Pretplata nije produžena.",
    cancelled: "Porudžbina je otkazana. Možeš da napraviš novu porudžbinu.",
    expired: "Porudžbina je istekla jer uplata nije stigla na vreme. Ako si ipak izvršio/la uplatu, pošalji potvrdu o uplati i referencu na "+PROMO_SUPPORT_EMAIL+".",
  }[o.status] || "";
  return Object.assign({}, base, {text});
}
function promoStatusPill(s, kind){
  const m = (kind && kind!=="listing_promo") ? (STORE_ORDER_STATUS[s] || {label:s, cls:"status-pending"}) : (PROMO_STATUS[s] || {label:s, cls:"status-pending"});
  return `<span class="status-pill ${m.cls}">${esc(m.label)}</span>`;
}

/* --- stanje pretplate prodavnice (za prikaz; istinu čuva baza) --- */
function storeSubInfo(s){
  if(!s) return null;
  if(s.grandfathered) return {state:"free", label:"Besplatna pretplata", cls:"status-active", until:null, daysLeft:null};
  const t = s.paid_until ? new Date(s.paid_until).getTime() : 0, now = Date.now();
  if(!t || t<=now) return {state:"expired", label:"Pretplata istekla", cls:"status-cancel", until:s.paid_until||null, daysLeft:0};
  const days = Math.ceil((t-now)/86400000);
  return days<=7
    ? {state:"expiring", label:`Pretplata ističe za ${days} ${days===1?"dan":"dana"}`, cls:"status-pending", until:s.paid_until, daysLeft:days}
    : {state:"active", label:"Pretplata aktivna", cls:"status-active", until:s.paid_until, daysLeft:days};
}
function storeSubPill(s){ const i = storeSubInfo(s); return i ? `<span class="status-pill ${i.cls}">${esc(i.label)}</span>` : "—"; }
function storeSubNoticeHtml(store){
  const i = storeSubInfo(store); if(!i) return "";
  if(i.state==="expired") return `<div class="notice warn" style="display:flex; justify-content:space-between; gap:12px; flex-wrap:wrap; align-items:center;"><span>⚠️ <b>Pretplata tvoje prodavnice je istekla</b> — prodavnica i njeni proizvodi nisu javno vidljivi dok ne obnoviš pretplatu.</span><a class="btn btn-primary btn-sm" href="#/moja-prodavnica/pretplata">Obnovi prodavnicu</a></div>`;
  if(i.state==="expiring") return `<div class="notice warn" style="display:flex; justify-content:space-between; gap:12px; flex-wrap:wrap; align-items:center;"><span>⏳ Pretplata tvoje prodavnice <b>ističe ${i.daysLeft===1?"za 1 dan":`za ${i.daysLeft} dana`}</b> (${fmtDateTime(i.until)}). Obnovi je na vreme da prodavnica ostane javno vidljiva.</span><a class="btn btn-primary btn-sm" href="#/moja-prodavnica/pretplata">Produži pretplatu</a></div>`;
  return "";
}
async function storeSubBannerHtml(){
  const s = await fetchMyStore(); return s ? storeSubNoticeHtml(s) : "";
}

/* --- korisnik bez prodavnice: izbor paketa + podaci prodavnice + porudžbina --- */
let soSel = null;
function storeOpenAutoSlug(){
  const slugEl = document.getElementById("soSlug");
  if(slugEl && !slugEl.dataset.touched) slugEl.value = slugify(document.getElementById("soName").value);
}
async function viewStoreOpen(){
  let packages = [], avail = false, orders = [];
  try{ [packages, avail, orders] = await Promise.all([fetchPromoPackages("store_subscription"), promoCheckoutAvailable(), fetchPromoOrders({kind:"store_open"})]); }catch(e){ console.error(e); }
  window.__storePackages = packages; soSel = null;
  const open = orders.find(o=>o.status==="awaiting_payment"||o.status==="payment_submitted");
  const last = orders[0];
  let body = "";
  if(open){
    const m = promoStatusInfo(open);
    body = `<div class="notice"><div style="display:flex; justify-content:space-between; gap:10px; flex-wrap:wrap; align-items:center;"><b>${esc(open.store_name)}</b>${promoStatusPill(open.status, open.kind)}</div>
      <p style="margin:8px 0 12px; line-height:1.55;">${esc(m.text)}</p>
      <div style="font-size:13px; margin-bottom:12px;">Referenca: <b>${esc(open.reference)}</b> · Iznos: <b>${fmtRsd(open.price_rsd)}</b></div>
      <a class="btn btn-primary" href="#/promocija/porudzbina/${open.id}">${open.status==="awaiting_payment"?"Prikaži uputstvo za uplatu":"Pogledaj porudžbinu"}</a></div>`;
  } else if(!avail || !packages.length){
    const adm = isAdmin();
    body = `<div class="notice warn"><b>Otvaranje prodavnice trenutno nije dostupno.</b><br>Pokušaj ponovo kasnije.</div>
      ${adm?`<div class="notice" style="margin-top:12px;"><b>Za administratora:</b> potrebna je konfiguracija pre nego što korisnici mogu da otvore prodavnicu.<ul style="margin:6px 0 0 18px; line-height:1.7;">
        ${!avail?`<li>Podaci o računu i uključene uplate: <a href="#/admin/payments/settings" style="color:var(--blue);">Admin → Uplate → Podešavanja računa</a></li>`:""}
        ${!packages.length?`<li>Bar jedan aktivan paket prodavnice: <a href="#/admin/payments/store-packages" style="color:var(--blue);">Admin → Uplate → Paketi prodavnice</a></li>`:""}</ul></div>`:""}`;
  } else {
    body = `${last && last.status==="rejected"?`<div class="notice warn" style="margin-bottom:14px;"><b>Prethodna uplata je odbijena.</b> Razlog: ${esc(last.reject_reason||"")}. Možeš da napraviš novu porudžbinu.</div>`:""}
      ${last && last.status==="expired"?`<div class="notice" style="margin-bottom:14px;">Prethodna porudžbina je istekla bez uplate. Možeš da napraviš novu.</div>`:""}
      <div id="soError" class="notice err" style="display:none;"></div>
      <h3 style="font-size:15px; margin-bottom:10px;">1. Izaberi paket</h3>
      <div class="promo-grid">${packages.map(p=>`<button type="button" class="promo-pkg" id="pkg_${p.id}" onclick="storeOpenSelect('${p.id}')" aria-pressed="false">
        <div class="promo-pkg-name">${esc(p.name)}</div>${p.description?`<div class="promo-pkg-desc">${esc(p.description)}</div>`:""}
        <div class="promo-pkg-meta"><span>${p.duration_days} ${p.duration_days===1?"dan":"dana"}</span><b>${fmtRsd(p.price_rsd)}</b></div></button>`).join("")}</div>
      <h3 style="font-size:15px; margin:20px 0 10px;">2. Podaci prodavnice</h3>
      <div class="form-group"><label>Naziv prodavnice *</label><input type="text" id="soName" maxlength="60" placeholder="npr. Urban Store" oninput="storeOpenAutoSlug()"></div>
      <div class="form-group"><label>Adresa prodavnice *</label>
        <div style="display:flex; align-items:center; gap:6px;"><span style="font-size:13px; color:var(--ink-faint); white-space:nowrap;">pazarime.rs/prodavnica/</span>
        <input type="text" id="soSlug" maxlength="40" placeholder="urban-store" oninput="this.dataset.touched='1'"></div>
        <div style="font-size:11.5px; color:var(--ink-faint); margin-top:4px;">Samo mala slova, brojevi i crtice (3–40 karaktera). Ne može se kasnije menjati.</div></div>
      <div class="form-row">
        <div class="form-group"><label>Glavna kategorija *</label><select id="soCat"><option value="">Izaberi</option>${activeCategories().map(c=>`<option value="${c.id}">${c.emoji} ${esc(c.name)}</option>`).join("")}</select></div>
        <div class="form-group"><label>Grad *</label><select id="soCity"><option value="">Izaberi</option>${CITIES.map(c=>`<option>${esc(c)}</option>`).join("")}</select></div>
      </div>
      <div id="soSummary" class="promo-summary" style="display:none;"></div>
      <button id="soBtn" class="btn btn-primary btn-block" style="margin-top:14px;" disabled onclick="storeOpenCreate()">Potvrdi i prikaži uputstvo za uplatu</button>
      <p style="font-size:12px; color:var(--ink-faint); margin-top:10px; line-height:1.5;">Naziv i adresa se čuvaju uz porudžbinu i koriste se tek nakon što administrator potvrdi uplatu. Logo, opis i ostale podatke dopunjuješ kada se prodavnica otvori.</p>`;
  }
  return `<div class="wrap section"><div class="wizard-card" style="max-width:680px;">
    <h2>🏪 Otvori prodavnicu</h2>
    <p class="sub" style="text-align:left; margin-bottom:16px;">Napravi svoju prodavnicu na PazariMe — svi tvoji proizvodi na jednom mestu, sa sopstvenom adresom. Prodavnica se otvara uz plaćenu pretplatu.</p>
    <div class="notice" style="margin-bottom:16px;">Plaćanje se vrši uplatom na račun. <b>Prodavnica postaje aktivna i javno vidljiva tek nakon što administrator proveri da je uplata stigla.</b> Do tada možeš da pratiš status porudžbine u svom nalogu.</div>
    ${body}
    <div style="margin-top:16px;"><a href="#/moj-pazarime" class="btn btn-ghost btn-sm">← Nazad</a></div>
  </div></div>`;
}
function storeOpenSelect(id){
  const p = (window.__storePackages||[]).find(x=>x.id===id); if(!p) return;
  soSel = id;
  document.querySelectorAll(".promo-pkg").forEach(b=>{ const on = b.id==="pkg_"+id; b.classList.toggle("selected", on); b.setAttribute("aria-pressed", on?"true":"false"); });
  const box = document.getElementById("soSummary");
  if(box){ box.style.display = ""; box.innerHTML = `<div class="order-label">Pregled porudžbine</div>
    <div class="order-line"><span>Paket</span><span>${esc(p.name)}</span></div>
    <div class="order-line"><span>Trajanje pretplate</span><span>${p.duration_days} ${p.duration_days===1?"dan":"dana"}</span></div>
    <div class="order-total" style="font-size:16px;"><span>Za uplatu</span><span>${fmtRsd(p.price_rsd)}</span></div>`; }
  const btn = document.getElementById("soBtn"); if(btn) btn.disabled = false;
}
function soShowError(msg){ const el = document.getElementById("soError"); if(el){ el.textContent = msg; el.style.display = "block"; el.scrollIntoView({block:"center"}); } else toast(msg); }
const storeOpenCreate = guarded("storeOpenCreate", async ()=>{
  const v = id => (document.getElementById(id)||{value:""}).value.trim();
  const p = (window.__storePackages||[]).find(x=>x.id===soSel);
  const name = v("soName"), slug = v("soSlug").toLowerCase(), cat = v("soCat"), city = v("soCity");
  if(!p) return soShowError("Izaberi paket.");
  if(name.length<2) return soShowError("Unesi naziv prodavnice (bar 2 karaktera).");
  if(!/^[a-z0-9]+(-[a-z0-9]+)*$/.test(slug)) return soShowError("Adresa može sadržati samo mala slova, brojeve i crtice (npr. urban-store).");
  if(slug.length<3||slug.length>40) return soShowError("Adresa mora imati 3–40 karaktera.");
  if(!cat) return soShowError("Izaberi glavnu kategoriju.");
  if(!city) return soShowError("Izaberi grad.");
  const btn = document.getElementById("soBtn"); if(btn){ btn.disabled = true; btn.textContent = "Kreiranje porudžbine..."; }
  try{
    const { data, error } = await sb.rpc("create_store_order", { p_package_id:p.id, p_name:name, p_slug:slug, p_category:cat, p_city:city, p_expected_price:p.price_rsd });
    if(error) throw error;
    location.hash = "/promocija/porudzbina/" + data.id;
  }catch(e){
    soShowError((e&&e.message)||"Greška. Pokušaj ponovo.");
    if(btn){ btn.disabled = false; btn.textContent = "Potvrdi i prikaži uputstvo za uplatu"; }
  }
});

/* --- vlasnik prodavnice: Pretplata (status, obnova, istorija) --- */
let srSel = null;
async function renderStoreSubscription(store){
  const i = storeSubInfo(store);
  let packages = [], avail = false, orders = [];
  try{ [packages, avail, orders] = await Promise.all([fetchPromoPackages("store_subscription"), promoCheckoutAvailable(), fetchPromoOrders({storeId:store.id})]); }catch(e){ console.error(e); }
  window.__storePackages = packages; srSel = null;
  const open = orders.find(o=>o.kind==="store_renew" && (o.status==="awaiting_payment"||o.status==="payment_submitted"));
  const paid = orders.find(o=>o.status==="paid");
  let renew = "";
  if(i.state==="free"){
    renew = `<div class="notice">Ova prodavnica ima <b>besplatnu pretplatu</b> (otvorena je pre uvođenja pretplate), pa obnova nije potrebna.</div>`;
  } else if(store.status==="suspended"){
    renew = `<div class="notice warn">Prodavnica je suspendovana od strane administracije — obnova nije moguća. Kontaktiraj podršku na ${PROMO_SUPPORT_EMAIL}.</div>`;
  } else if(open){
    renew = `<div class="notice"><div style="display:flex; justify-content:space-between; gap:10px; flex-wrap:wrap; align-items:center;"><b>Obnova pretplate</b>${promoStatusPill(open.status, open.kind)}</div>
      <p style="margin:8px 0 12px; line-height:1.55;">${esc(promoStatusInfo(open).text)}</p>
      <div style="font-size:13px; margin-bottom:12px;">Referenca: <b>${esc(open.reference)}</b> · Iznos: <b>${fmtRsd(open.price_rsd)}</b></div>
      <a class="btn btn-primary" href="#/promocija/porudzbina/${open.id}">${open.status==="awaiting_payment"?"Prikaži uputstvo za uplatu":"Pogledaj porudžbinu"}</a></div>`;
  } else if(!avail || !packages.length){
    renew = `<div class="notice warn"><b>Obnova pretplate trenutno nije dostupna.</b><br>Pokušaj ponovo kasnije.</div>
      ${isAdmin()?`<div class="notice" style="margin-top:12px;"><b>Za administratora:</b> potrebni su podaci o računu (<a href="#/admin/payments/settings" style="color:var(--blue);">Podešavanja računa</a>) i bar jedan aktivan <a href="#/admin/payments/store-packages" style="color:var(--blue);">paket prodavnice</a>.</div>`:""}`;
  } else {
    renew = `<h3 style="font-size:15px; margin-bottom:10px;">Produži pretplatu</h3>
      <p style="font-size:13px; color:var(--ink-dim); line-height:1.55; margin-bottom:12px;">${i.state==="expired"
        ? "Pretplata je istekla. Kada administrator potvrdi uplatu, prodavnica ponovo postaje javno vidljiva, a nova pretplata počinje od potvrde."
        : `Ako obnoviš pre isteka, nova pretplata se nadovezuje na postojeću (počinje <b>${fmtDateTime(i.until)}</b>). Pretplata se produžava tek nakon što administrator potvrdi uplatu.`}</p>
      <div id="srError" class="notice err" style="display:none;"></div>
      <div class="promo-grid">${packages.map(p=>`<button type="button" class="promo-pkg" id="pkg_${p.id}" onclick="storeRenewSelect('${p.id}')" aria-pressed="false">
        <div class="promo-pkg-name">${esc(p.name)}</div>${p.description?`<div class="promo-pkg-desc">${esc(p.description)}</div>`:""}
        <div class="promo-pkg-meta"><span>${p.duration_days} ${p.duration_days===1?"dan":"dana"}</span><b>${fmtRsd(p.price_rsd)}</b></div></button>`).join("")}</div>
      <div id="srSummary" class="promo-summary" style="display:none;"></div>
      <button id="srBtn" class="btn btn-primary" style="margin-top:14px;" disabled onclick="storeRenewCreate()">Potvrdi i prikaži uputstvo za uplatu</button>`;
  }
  return `<h2 style="font-size:20px; margin-bottom:14px;">Pretplata prodavnice</h2>
    <div class="pay-box" style="margin-bottom:16px;">
      <div style="display:flex; justify-content:space-between; gap:10px; flex-wrap:wrap; align-items:center;"><b style="font-size:15px;">${esc(store.name)}</b><span class="status-pill ${i.cls}">${esc(i.label)}</span></div>
      ${i.state==="free"?`<div class="pay-row"><span>Važi do</span><b>bez isteka</b></div>`:`<div class="pay-row"><span>Važi do</span><b>${i.until?fmtDateTime(i.until):"—"}</b></div>`}
      ${paid?`<div class="pay-row"><span>Poslednja uplata</span><b>${esc(paid.package_name)} · ${fmtRsd(paid.price_rsd)} · ${esc(paid.reference)}</b></div>`:""}
      <div class="pay-row"><span>Javna vidljivost</span><b>${store.status==="active" && i.state!=="expired" ? "Prodavnica je javno vidljiva" : "Prodavnica nije javno vidljiva"}</b></div>
    </div>
    ${renew}
    ${orders.length?`<h3 style="font-size:15px; margin:24px 0 10px;">Istorija uplata</h3>${orders.map(promoOrderRowHtml).join("")}`:""}`;
}
function storeRenewSelect(id){
  const p = (window.__storePackages||[]).find(x=>x.id===id); if(!p) return;
  srSel = id;
  document.querySelectorAll(".promo-pkg").forEach(b=>{ const on = b.id==="pkg_"+id; b.classList.toggle("selected", on); b.setAttribute("aria-pressed", on?"true":"false"); });
  const box = document.getElementById("srSummary");
  if(box){ box.style.display = ""; box.innerHTML = `<div class="order-label">Pregled porudžbine</div>
    <div class="order-line"><span>Paket</span><span>${esc(p.name)}</span></div>
    <div class="order-line"><span>Trajanje</span><span>${p.duration_days} ${p.duration_days===1?"dan":"dana"}</span></div>
    <div class="order-total" style="font-size:16px;"><span>Za uplatu</span><span>${fmtRsd(p.price_rsd)}</span></div>
    <p style="font-size:12px; color:var(--ink-faint); margin-top:8px; line-height:1.5;">Pretplata se ne produžava dok uplata ne bude potvrđena.</p>`; }
  const btn = document.getElementById("srBtn"); if(btn) btn.disabled = false;
}
const storeRenewCreate = guarded("storeRenewCreate", async ()=>{
  const p = (window.__storePackages||[]).find(x=>x.id===srSel); if(!p) return;
  const btn = document.getElementById("srBtn"); if(btn){ btn.disabled = true; btn.textContent = "Kreiranje porudžbine..."; }
  try{
    const { data, error } = await sb.rpc("create_store_renewal_order", { p_package_id:p.id, p_expected_price:p.price_rsd });
    if(error) throw error;
    location.hash = "/promocija/porudzbina/" + data.id;
  }catch(e){
    const el = document.getElementById("srError"); if(el){ el.textContent = (e&&e.message)||"Greška. Pokušaj ponovo."; el.style.display = "block"; } else toast("Greška: "+((e&&e.message)||""));
    if(btn){ btn.disabled = false; btn.textContent = "Potvrdi i prikaži uputstvo za uplatu"; }
  }
});

/* --- admin: pretplata prodavnice (besplatna / plaćena) --- */
async function adminStoreGrandfather(id, free){
  try{
    let paidUntil = null;
    if(!free){
      const d = prompt("Na koliko dana prelazi na plaćenu pretplatu? (npr. 30)", "30"); if(d===null) return;
      const n = parseInt(d, 10); if(!(n>0 && n<=3650)){ toast("Unesi broj dana (1–3650)"); return; }
      paidUntil = new Date(Date.now()+n*86400000).toISOString();
    } else if(!confirm("Označiti prodavnicu kao besplatnu (pretplata bez isteka)?")) return;
    const { error } = await sb.rpc("admin_set_store_grandfathered", { p_store_id:id, p_value:free, p_paid_until:paidUntil });
    if(error) throw error;
    toast("Sačuvano"); route();
  }catch(e){ toast("Greška: "+((e&&e.message)||"pokušaj ponovo")); }
}


/* ---------------- LEGAL PAGES ----------------
   LEGAL_DOCS holds the text of the public legal pages (Uslovi korišćenja, Politika privatnosti, Pravila oglašavanja).
   The pages are public (no login). The only support address used on the site is podrska.pazarime@gmail.com. */
const LEGAL_DOCS = {
 "zastita-kupaca": {
 "brand": "PAZARIME",
 "title": "Zaštita kupaca i status prodavaca",
 "subtitle": "Ko prodaje na PazariMe, koja pravila važe i kome da se obratiš ako nešto pođe po zlu",
 "blocks": [
  {
   "lines": [
    [
     {
      "t": "Ova stranica je informativna i objašnjava kako PazariMe prikazuje status prodavca. Ne predstavlja pravni savet. Za konkretan slučaj obrati se stručnom licu ili nadležnom organu."
     }
    ]
   ],
   "note": true
  },
  {
   "h": "1. Zašto postoji ova stranica",
   "id": "uvod"
  },
  {
   "lines": [
    [
     {
      "t": "PazariMe je onlajn tržište: na njemu oglase i prodavnice objavljuju različiti prodavci, a kupci sa njima samostalno dogovaraju kupovinu. Prava koja kupac ima zavise od toga da li prodavac nastupa kao trgovac ili kao fizičko lice koje ne nastupa kao trgovac. Zato na svakom oglasu, uz podatke o prodavcu, prikazujemo status koji je prodavac sam izjavio."
     }
    ]
   ]
  },
  {
   "lines": [
    [
     {
      "t": "To obaveštenje je istaknuto na samom oglasu i na stranici porudžbine, a ne samo u Uslovima korišćenja. Stranica je pripremljena imajući u vidu član 28 Zakona o zaštiti potrošača („Službeni glasnik RS“, br. 35/2026)."
     }
    ]
   ]
  },
  {
   "h": "2. Privatni prodavac i trgovac",
   "id": "status"
  },
  {
   "lines": [
    [
     {
      "t": "Pre prvog objavljivanja oglasa ili otvaranja prodavnice, svaki prodavac izjavljuje jedan od dva statusa:"
     }
    ]
   ]
  },
  {
   "lines": [
    [
     {
      "t": "• "
     },
     {
      "t": "Fizičko lice – privatni prodavac: ",
      "b": true
     },
     {
      "t": "fizičko lice koje se izjasnilo da ne nastupa kao trgovac, na primer kada prodaje sopstvene stvari van svoje poslovne ili druge komercijalne delatnosti. Od privatnog prodavca ne tražimo podatke o delatnosti."
     }
    ],
    [
     {
      "t": "• "
     },
     {
      "t": "Trgovac: ",
      "b": true
     },
     {
      "t": "prodavac koji nastupa u okviru svoje poslovne delatnosti ili u druge komercijalne svrhe (pravno lice, preduzetnik ili fizičko lice, uključujući lice koje postupa u ime ili za račun trgovca). Trgovac navodi poslovno ime, pravnu formu, adresu sedišta, matični broj, PIB, e-adresu i telefon, a ti podaci se prikazuju kupcima."
     }
    ]
   ]
  },
  {
   "lines": [
    [
     {
      "t": "Status se navodi na osnovu izjave prodavca, a podaci o trgovcu prikazuju se onako kako ih je prodavac naveo. PazariMe ne proverava automatski tačnost izjava niti podataka u registrima. Ko prodaje u okviru svoje delatnosti treba da izabere status „Trgovac“; trgovac ne sme da se lažno predstavlja kao fizičko lice. Stariji oglasi prodavaca koji se još nisu izjasnili imaju oznaku „Status nije izjavljen“."
     }
    ]
   ]
  },
  {
   "h": "3. Kako se razlikuju prava kupca",
   "id": "prava"
  },
  {
   "lines": [
    [
     {
      "t": "Zakon o zaštiti potrošača štiti potrošače u odnosu na trgovce. Zato je važno ko je prodavac:"
     }
    ]
   ]
  },
  {
   "lines": [
    [
     {
      "t": "• "
     },
     {
      "t": "Kupovina od trgovca: ",
      "b": true
     },
     {
      "t": "primenjuju se propisi o zaštiti potrošača, između ostalog pravila o informisanju pre zaključenja ugovora, pravu na odustanak od ugovora zaključenog na daljinu (uz zakonske izuzetke), saobraznosti robe i reklamacijama."
     }
    ],
    [
     {
      "t": "• "
     },
     {
      "t": "Kupovina od fizičkog lica koje nije trgovac: ",
      "b": true
     },
     {
      "t": "odredbe Zakona o zaštiti potrošača se ne primenjuju na tu kupoprodaju. Primenjuju se opšta pravila obligacionog prava, a kupac i prodavac se dogovaraju o uslovima. Zato pre kupovine pažljivo proveri oglas i predmet."
     }
    ]
   ]
  },
  {
   "lines": [
    [
     {
      "t": "Ovo je opšte objašnjenje. Tačan obim prava zavisi od okolnosti slučaja i važećih propisa."
     }
    ]
   ]
  },
  {
   "h": "4. Uloga PazariMe-a",
   "id": "uloga"
  },
  {
   "lines": [
    [
     {
      "t": "PazariMe je onlajn tržište koje povezuje kupce i prodavce: omogućava objavljivanje oglasa i prodavnica, pretragu, razmenu poruka i, za proizvode u prodavnicama, slanje porudžbine prodavcu. Pored toga, PazariMe ima neposredan odnos sa korisnicima kada pruža sopstvene usluge, na primer promociju oglasa i prodavnice."
     }
    ]
   ]
  },
  {
   "lines": [
    [
     {
      "t": "Kupoprodaju po pravilu zaključuju kupac i prodavac. Da li je i u kojoj meri PazariMe u konkretnom slučaju ugovorna strana ili odgovara kupcu, zavisi od važećih propisa i stvarne uloge PazariMe-a u toj transakciji. Podela odgovornosti iz ove stranice ne utiče na odgovornost koju, prema zakonu, PazariMe ili prodavac imaju prema kupcu u vezi sa ugovorom."
     }
    ]
   ]
  },
  {
   "h": "5. Podela odgovornosti",
   "id": "podela"
  },
  {
   "lines": [
    [
     {
      "t": "Prema načinu na koji PazariMe danas funkcioniše:"
     }
    ]
   ]
  },
  {
   "lines": [
    [
     {
      "t": "• "
     },
     {
      "t": "Oglasi i roba: ",
      "b": true
     },
     {
      "t": "prodavac je odgovoran za sadržaj oglasa, tačnost opisa, fotografija i cene, kao i za stanje, poreklo i zakonitost robe ili usluge koju nudi."
     }
    ],
    [
     {
      "t": "• "
     },
     {
      "t": "Plaćanje: ",
      "b": true
     },
     {
      "t": "PazariMe ne naplaćuje cenu robe i usluga iz oglasa i ne prima uplate kupaca; način plaćanja dogovaraju kupac i prodavac. Online plaćanje robe trenutno nije dostupno. Uplate PazariMe-u odnose se samo na njegove sopstvene usluge (promocija oglasa, prodavnice)."
     }
    ],
    [
     {
      "t": "• "
     },
     {
      "t": "Isporuka: ",
      "b": true
     },
     {
      "t": "način i rok isporuke dogovaraju kupac i prodavac; PazariMe ne isporučuje robu."
     }
    ],
    [
     {
      "t": "• "
     },
     {
      "t": "Reklamacije i zahtevi zbog robe: ",
      "b": true
     },
     {
      "t": "upućuju se prodavcu. Ako je prodavac trgovac, on postupa po propisima o zaštiti potrošača; ako je fizičko lice koje nije trgovac, primenjuju se opšta pravila iz tačke 3."
     }
    ],
    [
     {
      "t": "• "
     },
     {
      "t": "Sporovi: ",
      "b": true
     },
     {
      "t": "kupac i prodavac prvo pokušavaju da spor reše direktno. Kada je prodavac trgovac, potrošač može da koristi i zakonske mehanizme, uključujući vansudsko rešavanje potrošačkih sporova i obraćanje nadležnim organima. Problem u vezi sa sadržajem ili ponašanjem na PazariMe-u možeš da prijaviš (tačka 7), a PazariMe može da proveri prijavu i preduzme mere predviđene Uslovima korišćenja."
     }
    ],
    [
     {
      "t": "• "
     },
     {
      "t": "Platforma: ",
      "b": true
     },
     {
      "t": "PazariMe odgovara za rad platforme i za sopstvene usluge, u meri u kojoj to propisuje zakon."
     }
    ]
   ]
  },
  {
   "lines": [
    [
     {
      "t": "Ova podela ne utiče na odgovornost koju, prema zakonu, PazariMe ili prodavac imaju prema kupcu u vezi sa ugovorom."
     }
    ]
   ]
  },
  {
   "h": "6. Kako se rangiraju oglasi",
   "id": "rangiranje"
  },
  {
   "lines": [
    [
     {
      "t": "Kada pretražuješ ili pregledaš oglase, redosled određuju sledeći parametri, ovim redom:"
     }
    ]
   ]
  },
  {
   "lines": [
    [
     {
      "t": "• "
     },
     {
      "t": "Plaćena promocija: ",
      "b": true
     },
     {
      "t": "prvo se prikazuju oglasi sa aktivnom PREMIUM promocijom, zatim oglasi sa aktivnom standardnom promocijom (oznaka „Izdvojeno“), pa ostali oglasi. Promociju plaća prodavac, a aktivira se tek kada administrator potvrdi uplatu. Promovisani oglasi su označeni na samom oglasu, a po isteku roka promocije oglas gubi prednost."
     }
    ],
    [
     {
      "t": "• "
     },
     {
      "t": "Izabrano sortiranje: ",
      "b": true
     },
     {
      "t": "unutar svake od te tri grupe oglasi se redaju po tvom izboru: najnoviji (podrazumevano), najjeftiniji, najskuplji ili najgledaniji."
     }
    ],
    [
     {
      "t": "• "
     },
     {
      "t": "Pretraga i filteri: ",
      "b": true
     },
     {
      "t": "rezultati obuhvataju oglase koji odgovaraju unetom pojmu (naslov, opis, brend, naziv prodavnice) i izabranim filterima. Prikazuje se najviše 200 rezultata."
     }
    ]
   ]
  },
  {
   "lines": [
    [
     {
      "t": "Status prodavca (fizičko lice ili trgovac) ne utiče na redosled oglasa."
     }
    ]
   ]
  },
  {
   "h": "7. Prijava problema i kontakt",
   "id": "prijava"
  },
  {
   "lines": [
    [
     {
      "t": "• Na stranici oglasa klikni „Prijavi“ i izaberi razlog, na primer „Prevara“, „Lažan proizvod“ ili „Netačan status prodavca“ (kada sumnjaš da se prodavac koji nastupa kao trgovac predstavlja kao fizičko lice)."
     }
    ],
    [
     {
      "t": "• Piši nam na podrska.pazarime@gmail.com. Navedi link oglasa, opis problema i, ako ih imaš, dokaze (poruke, potvrde o uplati, fotografije)."
     }
    ],
    [
     {
      "t": "• Za probleme sa robom prvo kontaktiraj prodavca porukom na PazariMe-u i sačuvaj prepisku."
     }
    ],
    [
     {
      "t": "• Nikome ne šalji lozinke, jednokratne kodove ni podatke platnih kartica."
     }
    ]
   ]
  },
  {
   "h": "8. Povezana dokumenta",
   "id": "dokumenta"
  },
  {
   "lines": [
    [
     {
      "t": "Pročitaj i Uslove korišćenja, Politiku privatnosti i Pravila oglašavanja. Ova stranica se može menjati; važi verzija objavljena na sajtu."
     }
    ]
   ]
  }
 ]
},
 "uslovi": {
  "brand": "PAZARIME",
  "title": "USLOVI KORIŠĆENJA",
  "subtitle": "Pazarime – internet platforma za objavljivanje i pregled oglasa",
  "blocks": [
   {
    "h": "1. Opšte odredbe"
   },
   {
    "lines": [
     [
      {
       "t": "Ovi Uslovi korišćenja uređuju pristup i korišćenje internet platforme Pazarime (u daljem tekstu: „Platforma“), uključujući pregledanje, postavljanje i upravljanje oglasima, korisničke naloge, komunikaciju među korisnicima i prijavljivanje sadržaja."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Operater Platforme: PazariMe"
      }
     ],
     [
      {
       "t": "Kontakt e-pošta: podrska.pazarime@gmail.com"
      }
     ],
     [
      {
       "t": "Internet adresa: pazarime.netlify.app"
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Korišćenjem Platforme korisnik potvrđuje da je pročitao ove Uslove. Ako se ne slaže sa njima, ne treba da koristi Platformu. Ovi Uslovi ne isključuju prava koja korisniku pripadaju po prinudnim propisima Republike Srbije."
      }
     ]
    ]
   },
   {
    "h": "2. Uloga Pazarime-a"
   },
   {
    "lines": [
     [
      {
       "t": "Pazarime omogućava korisnicima da objavljuju oglase, pretražuju ponude i međusobno komuniciraju. Osim ako je izričito navedeno drugačije, Pazarime nije prodavac, kupac, zastupnik niti ugovorna strana u kupoprodaji između korisnika."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Korisnici samostalno dogovaraju cenu, plaćanje, isporuku, pregled robe i druge uslove transakcije. Pazarime ne garantuje da će oglas dovesti do prodaje, da je korisnik solventan, niti da su tvrdnje u oglasu tačne. Platforma može sprovoditi moderaciju, ali pregled oglasa ne predstavlja potvrdu njihove istinitosti, zakonitosti ili kvaliteta."
      }
     ]
    ]
   },
   {
    "h": "3. Korisnički nalog"
   },
   {
    "lines": [
     [
      {
       "t": "Za pojedine funkcije, kao što su objavljivanje oglasa, slanje poruka ili prijavljivanje sadržaja, potrebno je kreirati nalog. Korisnik je dužan da pruži tačne podatke, čuva poverljivost svojih pristupnih podataka i bez odlaganja obavesti Platformu o sumnji na neovlašćen pristup."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Korisnik je odgovoran za aktivnosti izvršene preko njegovog naloga, osim u meri u kojoj važeći propisi određuju drugačije. Nalog se ne sme prodavati, ustupati ili koristiti za obmanjivanje drugih korisnika. Korisnik mora imati zakonsku sposobnost da koristi Platformu i, ako je maloletan, može je koristiti samo u skladu sa važećim propisima i uz odgovarajuću saglasnost roditelja ili staratelja kada je potrebna."
      }
     ]
    ]
   },
   {
    "h": "4. Oglasi i odgovornost korisnika"
   },
   {
    "lines": [
     [
      {
       "t": "Korisnik koji objavi oglas odgovoran je za njegov sadržaj, fotografije, cenu, opis, stanje predmeta, poreklo i pravo da predmet ponudi. Oglas mora biti istinit, jasan, ažuran i usklađen sa Pravilima oglašavanja i važećim propisima."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Korisnik ne sme objavljivati tuđe lične podatke, fotografije ili drugi sadržaj bez odgovarajućeg pravnog osnova. Zabranjeno je lažno predstavljanje, obmanjujuće opisivanje predmeta, objavljivanje dupliranih ili spam oglasa i korišćenje Platforme za prevare ili druge protivpravne aktivnosti."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Korisnik je dužan da ukloni ili ažurira oglas kada predmet više nije dostupan ili kada se bitno promene navedeni podaci."
      }
     ]
    ]
   },
   {
    "h": "5. Komunikacija i transakcije"
   },
   {
    "lines": [
     [
      {
       "t": "Poruke i dogovori između korisnika služe za komunikaciju u vezi sa oglasima. Korisnici treba da budu oprezni sa zahtevima za uplatu unapred, linkovima za navodnu dostavu ili plaćanje, zahtevima za lozinke, jednokratne kodove ili podatke platnih kartica."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Pazarime ne traži od korisnika da drugom korisniku otkrije lozinku ili sigurnosni kod. Korisnici sami proveravaju identitet sagovornika, predmet, cenu, način plaćanja i isporuke. Platforma ne garantuje izvršenje dogovora između korisnika, osim ako za konkretnu uslugu nije izričito navedeno drugačije."
      }
     ]
    ]
   },
   {
    "h": "6. Prijave, moderacija i mere"
   },
   {
    "lines": [
     [
      {
       "t": "Korisnici mogu prijaviti oglas ili nalog za koji smatraju da krši ove Uslove, Pravila oglašavanja ili propise. Prijava treba da sadrži tačne informacije i, kada je moguće, objašnjenje razloga."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Pazarime može pregledati prijave i, u skladu sa okolnostima i važećim propisima, zatražiti dodatne informacije, privremeno sakriti oglas, ukloniti sadržaj, ograničiti funkcije naloga, suspendovati ili ukinuti nalog, odnosno prijaviti nadležnim organima sadržaj za koji postoji odgovarajući osnov. Mere treba da budu primerene okolnostima. Korisnik može kontaktirati operatera radi preispitivanja mere na adresu e-pošte podrska.pazarime@gmail.com."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Pazarime ne garantuje prethodnu proveru svakog oglasa i ne odriče se obaveza koje mu nameću važeći propisi."
      }
     ]
    ]
   },
   {
    "h": "7. Intelektualna svojina i sadržaj korisnika"
   },
   {
    "lines": [
     [
      {
       "t": "Korisnik zadržava prava na sadržaju koji zakonito postavi. Objavljivanjem sadržaja korisnik daje Pazarime-u neisključivu, besplatnu, teritorijalno neograničenu licencu, u trajanju potrebnom za pružanje i promociju usluga Platforme, da sadržaj hostuje, prikazuje, formatira, tehnički prilagođava i učini dostupnim kroz funkcije Platforme."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Korisnik potvrđuje da ima potrebna prava i ovlašćenja za objavljivanje sadržaja. Ova licenca prestaje u meri u kojoj sadržaj bude uklonjen, osim kada je njegovo zadržavanje potrebno zbog zakonskih obaveza, rešavanja sporova, bezbednosti ili zaštite pravnih zahteva."
      }
     ]
    ]
   },
   {
    "h": "8. Dostupnost i izmene Platforme"
   },
   {
    "lines": [
     [
      {
       "t": "Pazarime nastoji da Platforma bude dostupna i bezbedna, ali ne garantuje neprekidan rad, odsustvo grešaka ili kompatibilnost sa svakim uređajem. Platforma može privremeno biti nedostupna zbog održavanja, bezbednosnih razloga ili okolnosti van razumne kontrole operatera."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Operater može unapređivati ili menjati funkcije Platforme. Bitne izmene ovih Uslova biće objavljene na Platformi, uz navođenje datuma stupanja na snagu. Nastavak korišćenja nakon stupanja izmena na snagu znači korišćenje pod izmenjenim Uslovima, u meri dozvoljenoj propisima."
      }
     ]
    ]
   },
   {
    "h": "9. Ograničenje odgovornosti"
   },
   {
    "lines": [
     [
      {
       "t": "Ništa u ovim Uslovima ne isključuje niti ograničava odgovornost koja se po prinudnim propisima ne može isključiti ili ograničiti. U meri dozvoljenoj zakonom, Pazarime ne odgovara za postupke korisnika, kvalitet ili zakonitost predmeta iz oglasa, tačnost korisničkih navoda, niti za sporove iz transakcija između korisnika."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Korisnici treba da čuvaju dokaze o dogovorima i plaćanjima i da sporove pokušaju da reše neposredno, uz korišćenje dostupnih zakonskih mehanizama."
      }
     ]
    ]
   },
   {
    "h": "10. Zaštita podataka"
   },
   {
    "lines": [
     [
      {
       "t": "Obrada ličnih podataka uređena je posebnom Politikom privatnosti koja čini prateći dokument Platforme. Korišćenjem Platforme korisnik treba da se upozna sa tom Politikom. Ovi Uslovi ne zamenjuju obaveštenja i saglasnosti koje su, prema propisima, potrebne za pojedine obrade."
      }
     ]
    ]
   },
   {
    "h": "11. Merodavno pravo i rešavanje sporova"
   },
   {
    "lines": [
     [
      {
       "t": "Na ove Uslove primenjuju se propisi Republike Srbije, uz poštovanje obaveznih prava potrošača i drugih prava koja se ne mogu ugovorom isključiti. Sporovi će se pokušati rešiti mirnim putem; ako to nije moguće, rešavaće ih nadležni organi Republike Srbije u skladu sa pravilima o nadležnosti."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Ništa u ovoj odredbi ne ograničava pravo korisnika da se obrati nadležnom organu ili da koristi zakonska prava na prigovor, reklamaciju ili sudsku zaštitu kada su primenljiva."
      }
     ]
    ]
   },
   {
    "h": "12. Kontakt i završne odredbe"
   },
   {
    "lines": [
     [
      {
       "t": "Za pitanja u vezi sa Uslovima, prijave ili prigovore kontaktirajte:"
      }
     ],
     [
      {
       "t": "Operater: Pazarime"
      }
     ],
     [
      {
       "t": "E-pošta: podrska.pazarime@gmail.com"
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Datum stupanja na snagu: 11.10.2026."
      }
     ],
     [
      {
       "t": "Verzija: 1.0"
      }
     ]
    ]
   }
  ]
 },
 "privatnost": {
  "brand": "PAZARIME",
  "title": "POLITIKA PRIVATNOSTI",
  "subtitle": "Obaveštenje o obradi i zaštiti ličnih podataka na Pazarime platformi",
  "blocks": [
   {
    "h": "1. Rukovalac podataka i kontakt"
   },
   {
    "lines": [
     [
      {
       "t": "Rukovalac podataka je: Pazarime"
      }
     ],
     [
      {
       "t": "Kontakt za privatnost i zahteve lica: "
      },
      {
       "t": "podrska.pazarime@gmail.com",
       "href": "mailto:podrska.pazarime@gmail.com"
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Ova Politika objašnjava koje podatke Pazarime obrađuje, u koje svrhe, po kom pravnom osnovu, kome ih otkriva, koliko ih čuva i kako korisnici mogu ostvariti svoja prava."
      }
     ]
    ]
   },
   {
    "h": "2. Koje podatke možemo obrađivati"
   },
   {
    "lines": [
     [
      {
       "t": "U zavisnosti od načina korišćenja Platforme, možemo obrađivati:"
      }
     ],
     [
      {
       "t": "• Podatke naloga: ime ili prikazano ime, e-mail adresu, identifikator korisničkog naloga i podatke profila."
      }
     ],
     [
      {
       "t": "• Oglase: naslov, opis, cenu, kategoriju, lokaciju koju korisnik navede, fotografije i druge podatke koje korisnik objavi."
      }
     ],
     [
      {
       "t": "• Komunikaciju: poruke, podatke o razgovorima, vreme slanja i status pročitanosti, u meri u kojoj su ove funkcije uključene."
      }
     ],
     [
      {
       "t": "• Bezbednosne i tehničke podatke: IP adresu, identifikatore sesije, zapise o pristupu, uređaju/pregledaču i događaje potrebne za zaštitu, sprečavanje zloupotreba i otklanjanje grešaka."
      }
     ],
     [
      {
       "t": "• Podatke o aktivnostima na Platformi: pretrage, preglede oglasa, favorite, ocene, prijave i interakcije, u obimu koji je potreban za funkcije i bezbednost."
      }
     ],
     [
      {
       "t": "• Podatke iz komunikacije sa podrškom i prigovora."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Ne tražite se niti treba slati posebne kategorije ličnih podataka, podatke platnih kartica, lozinke ili jednokratne sigurnosne kodove kroz oglase ili poruke."
      }
     ]
    ]
   },
   {
    "h": "3. Svrhe i pravni osnovi obrade"
   },
   {
    "lines": [
     [
      {
       "t": "Podatke obrađujemo u sledeće svrhe i na odgovarajućim pravnim osnovima, u zavisnosti od konkretne obrade:"
      }
     ],
     [
      {
       "t": "• Kreiranje i održavanje naloga, objavljivanje oglasa, poruke i druge tražene funkcije — izvršenje ugovora ili preduzimanje radnji na zahtev lica pre zaključenja ugovora."
      }
     ],
     [
      {
       "t": "• Bezbednost, sprečavanje prevara, otkrivanje zloupotreba, moderacija prijava i zaštita naloga — legitimni interes, uz procenu prava i interesa korisnika, ili zakonska obaveza kada je primenljiva."
      }
     ],
     [
      {
       "t": "• Odgovaranje na upite i rešavanje sporova — izvršenje ugovora, legitimni interes ili zakonska obaveza, zavisno od slučaja."
      }
     ],
     [
      {
       "t": "• Ispunjavanje računovodstvenih, poreskih ili drugih zakonskih obaveza — zakonska obaveza."
      }
     ],
     [
      {
       "t": "• Analitika, oglašavanje ili neobavezni kolačići koji zahtevaju saglasnost — saglasnost korisnika, kada je propisana."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Kada se obrada zasniva na saglasnosti, korisnik je može povući u bilo kom trenutku, bez uticaja na zakonitost obrade pre povlačenja."
      }
     ]
    ]
   },
   {
    "h": "4. Javno dostupni podaci"
   },
   {
    "lines": [
     [
      {
       "t": "Podaci koje korisnik namerno unese u javni oglas ili javni profil, kao što su prikazano ime, opis, fotografije i navedena lokacija, mogu biti vidljivi drugim posetiocima Platforme i mogu biti kopirani ili indeksirani od strane trećih lica. Korisnik treba da objavljuje samo podatke koje želi da učini javnim i da iz fotografija ukloni nepotrebne lične podatke ili metapodatke."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Privatne poruke nisu javni oglasi. Pristup porukama ograničen je na učesnike razgovora i ovlašćene sisteme/lica kada je to neophodno za rad, bezbednost, prijavu zloupotrebe ili ispunjenje zakonske obaveze, uz primenu odgovarajućih mera zaštite."
      }
     ]
    ]
   },
   {
    "h": "5. Primaoci i obrađivači"
   },
   {
    "lines": [
     [
      {
       "t": "Podaci mogu biti dostupni pružaocima usluga koji podržavaju rad Platforme, kao što su hosting, baza podataka, autentifikacija, skladištenje fotografija, dostava e-pošte, bezbednost i tehnička podrška."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Podaci se mogu otkriti nadležnim organima kada postoji zakonska obaveza ili valjan pravni osnov, kao i u meri neophodnoj za uspostavljanje, ostvarivanje ili odbranu pravnih zahteva. Pazarime ne prodaje lične podatke korisnika."
      }
     ]
    ]
   },
   {
    "h": "6. Prenos podataka u druge države"
   },
   {
    "lines": [
     [
      {
       "t": "Pojedini pružaoci usluga mogu obrađivati podatke izvan Republike Srbije."
      }
     ]
    ]
   },
   {
    "h": "7. Rokovi čuvanja"
   },
   {
    "lines": [
     [
      {
       "t": "Podatke čuvamo samo onoliko dugo koliko je potrebno za svrhe zbog kojih su prikupljeni, osim kada duži rok nalažu propisi ili je potreban radi rešavanja sporova i zaštite pravnih zahteva."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Podaci naloga i oglasa čuvaju se dok je nalog aktivan ili dok su potrebni za pružanje usluge. Prijave, evidencije bezbednosti i administrativne radnje mogu se čuvati tokom perioda potrebnog za moderaciju, sprečavanje ponovljenih zloupotreba i dokazivanje postupanja. Rezervne kopije, evidencije i zakonski obavezni podaci mogu ostati u sistemima tokom tehnički i pravno opravdanog perioda, nakon čega se brišu ili anonimizuju."
      }
     ]
    ]
   },
   {
    "h": "8. Kolačići i slične tehnologije"
   },
   {
    "lines": [
     [
      {
       "t": "Platforma može koristiti neophodne kolačiće ili lokalno skladište za prijavu, bezbednost, pamćenje podešavanja i osnovni rad funkcija. Neobavezni analitički ili marketinški alati smeju se koristiti samo uz odgovarajuće obaveštenje i saglasnost kada je ona propisana."
      }
     ]
    ]
   },
   {
    "h": "9. Bezbednost podataka"
   },
   {
    "lines": [
     [
      {
       "t": "Pazarime primenjuje odgovarajuće tehničke i organizacione mere, srazmerne riziku, kao što su kontrola pristupa, pravila ovlašćenja, zaštita pristupnih podataka, ograničavanje pristupa podacima i praćenje bezbednosnih događaja. Nijedan sistem prenosa ili čuvanja podataka ne može se garantovati kao apsolutno bezbedan."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Korisnik je dužan da čuva svoju lozinku, koristi bezbedan uređaj i prijavi sumnju na kompromitovanje naloga na podrska.pazarime@gmail.com"
      }
     ]
    ]
   },
   {
    "h": "10. Prava lica na koja se podaci odnose"
   },
   {
    "lines": [
     [
      {
       "t": "U skladu sa važećim propisima, korisnik može imati pravo da zatraži pristup svojim podacima, ispravku, brisanje, ograničenje obrade, prenosivost podataka, prigovor na obradu i povlačenje saglasnosti kada se obrada zasniva na saglasnosti. Prava zavise od pravnog osnova i mogu biti podložna zakonskim izuzecima."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Zahtev se podnosi na podrska.pazarime@gmail.com. Radi zaštite podataka, možemo zatražiti razumnu proveru identiteta. Odgovorićemo u rokovima propisanim zakonom. Lice takođe može podneti pritužbu Povereniku za informacije od javnog značaja i zaštitu podataka o ličnosti, u skladu sa važećim propisima."
      }
     ]
    ]
   },
   {
    "h": "11. Maloletnici"
   },
   {
    "lines": [
     [
      {
       "t": "Platforma nije namenjena prikupljanju podataka dece bez odgovarajućeg pravnog osnova i potrebne saglasnosti roditelja ili staratelja. Ako saznamo da su podaci deteta prikupljeni protivno propisima, preduzećemo odgovarajuće korake, uključujući ograničavanje ili brisanje podataka kada je to zakonski potrebno."
      }
     ]
    ]
   },
   {
    "h": "12. Izmene Politike i kontakt"
   },
   {
    "lines": [
     [
      {
       "t": "Politika može biti ažurirana zbog promena u funkcionalnostima, propisima ili načinu obrade. Na stranici će biti naveden datum poslednje izmene. Za bitne promene korisnici će biti obavešteni na primeren način kada je to potrebno."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Rukovalac: Pazarime"
      }
     ],
     [
      {
       "t": "E-pošta za privatnost: podrska.pazarime@gmail.com"
      }
     ],
     [
      {
       "t": "Datum stupanja na snagu: 11.10.2026."
      }
     ],
     [
      {
       "t": "Verzija: 1.0"
      }
     ]
    ]
   }
  ]
 },
 "pravila-oglasavanja": {
  "brand": "PAZARIME",
  "title": "PRAVILA OGLAŠAVANJA",
  "subtitle": "Pravila za postavljanje, sadržaj i moderaciju oglasa na Pazarime platformi",
  "blocks": [
   {
    "h": "1. Svrha i primena"
   },
   {
    "lines": [
     [
      {
       "t": "Ova Pravila uređuju koje oglase korisnici mogu da objavljuju na Pazarime platformi, kako oglasi treba da izgledaju i kada Pazarime može da zatraži izmenu, ograniči vidljivost ili ukloni oglas."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Pravila važe za sve korisnike koji objavljuju ili uređuju oglase. Ona dopunjuju Uslove korišćenja i ne zamenjuju obaveze koje proizlaze iz zakona Republike Srbije."
      }
     ]
    ]
   },
   {
    "h": "2. Osnovni uslovi za oglas"
   },
   {
    "lines": [
     [
      {
       "t": "Svaki oglas mora:"
      }
     ],
     [
      {
       "t": "• da se odnosi na konkretan predmet, robu ili uslugu koja se zakonito može oglašavati;"
      }
     ],
     [
      {
       "t": "• da sadrži tačan i razumljiv naslov i opis;"
      }
     ],
     [
      {
       "t": "• da navede realnu cenu ili jasno objasni osnov obračuna kada je cena promenljiva;"
      }
     ],
     [
      {
       "t": "• da bude objavljen u odgovarajućoj kategoriji;"
      }
     ],
     [
      {
       "t": "• da koristi fotografije koje prikazuju ponuđeni predmet ili uslugu i na koje oglašivač ima prava;"
      }
     ],
     [
      {
       "t": "• da sadrži tačne podatke o stanju, količini, lokaciji i bitnim nedostacima, kada su relevantni."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Oglas ne sme da obmanjuje, prikriva važne informacije, koristi tuđe fotografije bez ovlašćenja ili predstavlja kopiju drugog oglasa radi veštačkog povećanja vidljivosti."
      }
     ]
    ]
   },
   {
    "h": "3. Zabranjeni i ograničeni oglasi"
   },
   {
    "lines": [
     [
      {
       "t": "Zabranjeno je objavljivanje oglasa koji nude, promovišu ili olakšavaju protivpravnu aktivnost ili promet zabranjenih predmeta. To uključuje, između ostalog, ukradenu robu, falsifikate koji se predstavljaju kao originali, narkotike i druge nedozvoljene supstance, oružje i municiju bez zakonom potrebnih dozvola i u slučajevima u kojima je oglašavanje zabranjeno, eksplozivne i opasne materije, dokumenta ili identifikacione isprave, ljudske organe ili tkiva, kao i sadržaj koji podstiče nasilje, mržnju, eksploataciju ili seksualno zlostavljanje."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Zabranjeno je oglašavanje robe ili usluga čija je prodaja ili promocija ograničena propisima, osim ako je oglašavanje dozvoljeno i oglašivač ispunjava sve zakonske uslove. Posebno proveriti zakonska ograničenja za lekove, medicinska sredstva, duvan i nikotinske proizvode, alkohol, finansijske usluge, igre na sreću, životinje, zaštićene vrste i druge regulisane kategorije."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Ovaj spisak je opšti i nije iscrpan. Ako korisnik nije siguran da li je predmet dozvoljen, ne treba da ga objavi dok ne proveri važeće propise i pravila kategorije."
      }
     ]
    ]
   },
   {
    "h": "4. Prevare i obmanjujuće prakse"
   },
   {
    "lines": [
     [
      {
       "t": "Nije dozvoljeno:"
      }
     ],
     [
      {
       "t": "• lažno predstavljanje identiteta, vlasništva ili ovlašćenja za prodaju;"
      }
     ],
     [
      {
       "t": "• traženje avansne uplate uz lažne podatke ili nameru prevare;"
      }
     ],
     [
      {
       "t": "• objavljivanje nepostojećih predmeta ili cena koje služe samo za privlačenje korisnika;"
      }
     ],
     [
      {
       "t": "• korišćenje lažnih potvrda, recenzija, ocena ili reputacije;"
      }
     ],
     [
      {
       "t": "• preusmeravanje korisnika na lažne stranice za plaćanje, dostavu ili prijavu;"
      }
     ],
     [
      {
       "t": "• traženje lozinki, jednokratnih kodova ili nepotrebnih podataka platnih kartica;"
      }
     ],
     [
      {
       "t": "• spam, masovno ponavljanje istih oglasa ili zaobilaženje ograničenja Platforme."
      }
     ]
    ]
   },
   {
    "h": "5. Fotografije, tekst i prava trećih lica"
   },
   {
    "lines": [
     [
      {
       "t": "Oglašivač mora imati pravo da koristi fotografije, tekst, logotipe i druge materijale u oglasu. Fotografije treba da budu relevantne i da ne prikazuju nepovezane predmete, tuđe lične podatke ili sadržaj koji krši privatnost."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Nije dozvoljeno koristiti tuđe fotografije ili opise bez dozvole, uklanjati vodene žigove radi prikrivanja izvora, niti koristiti sadržaj koji krši autorska, žigovna ili druga prava. Pazarime može zatražiti dokaz o pravu korišćenja ili ukloniti sadržaj po prijavi ili kada postoji osnov za postupanje."
      }
     ]
    ]
   },
   {
    "h": "6. Duplikati, kategorije i vidljivost"
   },
   {
    "lines": [
     [
      {
       "t": "Jedan oglas treba da predstavlja jednu ponudu ili jasno definisan skup istovrsnih predmeta. Nije dozvoljeno objavljivati isti oglas više puta radi zauzimanja rezultata pretrage, stavljati oglas u nepovezane kategorije ili koristiti obmanjujuće ključne reči."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Plaćeno ili posebno istaknuto pozicioniranje, ako postoji, mora biti označeno na jasan način i ne sme da prikazuje lažne tvrdnje o kvalitetu ili pouzdanosti oglasa. Uslovi eventualnih promocija i naplate moraju biti posebno prikazani korisniku pre kupovine."
      }
     ]
    ]
   },
   {
    "h": "7. Prijavljivanje oglasa"
   },
   {
    "lines": [
     [
      {
       "t": "Korisnici mogu prijaviti oglas za koji smatraju da krši ova Pravila, Uslove korišćenja ili zakon. Prijava treba da identifikuje oglas i navede razlog, uz dodatne informacije ili dokaz kada je dostupan."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Prijave se pregledaju u skladu sa raspoloživim informacijama, ozbiljnošću navoda i primenljivim obavezama. Slanje prijave ne garantuje automatsko uklanjanje oglasa. Zloupotreba prijava, uključujući namerno lažne ili uznemiravajuće prijave, može dovesti do ograničenja naloga."
      }
     ]
    ]
   },
   {
    "h": "8. Moderacija i posledice kršenja"
   },
   {
    "lines": [
     [
      {
       "t": "Kada postoji osnov da oglas krši Pravila ili propise, Pazarime može zatražiti izmenu, privremeno ograničiti vidljivost, ukloniti oglas, ograničiti pojedine funkcije ili suspendovati/ukinuti nalog, u skladu sa Uslovima korišćenja i važećim propisima."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Pri odlučivanju se mogu uzeti u obzir priroda i težina povrede, ponavljanje, rizik za druge korisnike, dostavljeni dokazi i zakonske obaveze. Pazarime može sačuvati relevantne evidencije kada je to potrebno radi bezbednosti, sprečavanja zloupotreba ili postupanja po zakonskom zahtevu."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Korisnik može zatražiti preispitivanje odluke putem e-pošte podrska.pazarime@gmail.com, uz navođenje oglasa i razloga za prigovor."
      }
     ]
    ]
   },
   {
    "h": "9. Obaveze prodavaca i kupaca"
   },
   {
    "lines": [
     [
      {
       "t": "Prodavci su odgovorni za zakonitost ponude, tačnost opisa i ispunjavanje obaveza koje se na njih primenjuju, uključujući obaveze koje mogu važiti za trgovce prema potrošačima. Privatni prodavci i registrovani trgovci mogu imati različit pravni status i obaveze; korisnici ne smeju prikrivati svoj status kada je njegovo navođenje zakonski potrebno."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Kupci treba da provere oglas, identitet prodavca, stanje predmeta, cenu, način plaćanja i isporuke pre zaključenja dogovora. Pazarime nije automatski strana u transakciji između korisnika."
      }
     ]
    ]
   },
   {
    "h": "10. Izmene pravila i kontakt"
   },
   {
    "lines": [
     [
      {
       "t": "Pazarime može menjati ova Pravila radi usklađivanja sa propisima, promenama usluga ili uočenim oblicima zloupotrebe. Važeća verzija biće objavljena na Platformi uz datum poslednje izmene."
      }
     ]
    ]
   },
   {
    "lines": [
     [
      {
       "t": "Kontakt za pitanja, prijave i prigovore:"
      }
     ],
     [
      {
       "t": "Operater: Pazarime"
      }
     ],
     [
      {
       "t": "E-pošta: podrska.pazarime@gmail.com"
      }
     ],
     [
      {
       "t": "Datum stupanja na snagu: 11.10.2026."
      }
     ],
     [
      {
       "t": "Verzija: 1.0"
      }
     ]
    ]
   }
  ]
 }
};
function legalInline(segs){
  return segs.map(sg=>{
    let h = esc(sg.t).replace(/([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})/g, '<a href="mailto:$1">$1</a>');
    if(sg.href && /^(mailto:|https?:)/i.test(sg.href)) h = `<a href="${esc(sg.href)}">${esc(sg.t)}</a>`;
    if(sg.b) h = `<strong>${h}</strong>`;
    if(sg.i) h = `<em>${h}</em>`;
    return h;
  }).join("");
}
function legalBlockHtml(b){
  if(b.h) return `<h2${b.id?` id="zk-${esc(b.id)}"`:""}>${esc(b.h)}</h2>`;
  const txt = l => l.map(sg=>sg.t).join("");
  let out = "", para = [], items = [];
  const flushP = () => { if(para.length){ out += `<p${b.note?' class="legal-note"':''}>${para.join("<br>")}</p>`; para = []; } };
  const flushL = () => { if(items.length){ out += `<ul>${items.map(i=>`<li>${i}</li>`).join("")}</ul>`; items = []; } };
  b.lines.forEach(l=>{
    const t = txt(l);
    if(/^\s*•\s/.test(t)){
      flushP();
      const first = Object.assign({}, l[0], {t: l[0].t.replace(/^\s*•\s+/, "")});   // the visible bullet becomes a real list marker
      items.push(legalInline([first].concat(l.slice(1))));
    } else { flushL(); para.push(legalInline(l)); }
  });
  flushP(); flushL();
  return out;
}
function viewLegal(key){
  const d = LEGAL_DOCS[key];
  if(!d) return view404();
  return `<div class="wrap section"><article class="legal-doc">
    <header class="legal-head"><div class="legal-brand">${esc(d.brand)}</div><h1>${esc(d.title)}</h1><p class="legal-sub">${esc(d.subtitle)}</p></header>
    ${d.blocks.map(legalBlockHtml).join("")}
  </article></div>`;
}
function view404(){ return `<div class="wrap section">${emptyState("🧭","Stranica nije pronađena","Proveri link ili se vrati na početnu.", `<a href="#/" class="btn btn-primary" style="margin-top:14px;">Nazad na početnu</a>`)}</div>`; }

/* ---------------- ADMIN ---------------- */
function accountStatusLabel(s){ return {active:"Aktivan",suspended:"Suspendovan",banned:"Blokiran"}[s]||s; }
function statusLabelReport(s){ return {pending:"Na čekanju",reviewing:"U pregledu",resolved:"Rešeno",dismissed:"Odbačeno"}[s]||s; }

async function viewAdmin(tab, subId, params){
  if(!isAdmin()) return `<div class="wrap section">${emptyState("🔒","Nemate dozvolu za ovu radnju","Admin panel je dostupan samo administratorima.", `<a href="#/" class="btn btn-primary" style="margin-top:14px;">Nazad na početnu</a>`)}</div>`;
  const navItems = [
    ["dashboard","📊","Dashboard"], ["users","👥","Korisnici"], ["listings","🏷️","Oglasi"],
    ["stores","🏪","Prodavnice"], ["orders","🧾","Porudžbine"], ["reports","🚩","Prijave"], ["categories","🗂️","Kategorije"], ["specifications","🧩","Specifikacije"], ["promotions","★","Promocije"], ["payments","💳","Uplate"],
    ["activity","📜","Istorija akcija"], ["settings","⚙️","Podešavanja"],
  ];
  let body = "";
  try{
    if(tab==="dashboard") body = await renderAdminDashboard();
    else if(tab==="users") body = subId ? await renderAdminUserDetail(subId) : await renderAdminUsers(params||new URLSearchParams());
    else if(tab==="listings") body = await renderAdminListings(params||new URLSearchParams());
    else if(tab==="stores") body = await renderAdminStores(subId, params||new URLSearchParams());
    else if(tab==="orders") body = await renderAdminOrders(subId, params||new URLSearchParams());
    else if(tab==="reports") body = await renderAdminReports(params||new URLSearchParams());
    else if(tab==="categories") body = await renderAdminCategories();
    else if(tab==="specifications") body = await renderAdminSpecifications(params||new URLSearchParams());
    else if(tab==="promotions") body = await renderAdminPromotions();
    else if(tab==="payments") body = await renderAdminPayments(subId, params||new URLSearchParams());
    else if(tab==="activity") body = await renderAdminActivity();
    else if(tab==="settings") body = renderAdminSettings();
    else body = emptyState("🧭","Nepoznata admin stranica","");
  }catch(e){
    console.error("[admin]", e);
    body = emptyState("⚠️","Greška pri učitavanju admin podataka","Pokušaj ponovo ili osveži stranicu."+((e&&e.message)?`<br><code style="font-size:12px;">${esc(e.message)}</code>`:""));
  }
  return `<div class="wrap section"><div class="dash-layout">
    <nav class="dash-nav">
      ${navItems.map(([id,icon,label])=>`<a href="#/admin/${id}" class="${tab===id?'active':''}">${icon} ${label}</a>`).join("")}
      <a href="#/moj-pazarime" class="dash-nav-back">← Nazad na PazariMe</a>
    </nav>
    <div>${body}</div>
  </div></div>`;
}

/* ---- Dashboard ---- */
async function fetchDashboardStats(){
  const todayStart = new Date(); todayStart.setHours(0,0,0,0);
  const todayISO = todayStart.toISOString();
  const [usersTotal, usersToday, listingsTotal, listingsActive, listingsSold, listingsPaused, listingsRemoved, listingsToday, favoritesTotal, reportsTotal, viewsRows, storesTotal] = await Promise.all([
    sb.from("profiles").select("id",{count:"exact",head:true}),
    sb.from("profiles").select("id",{count:"exact",head:true}).gte("created_at", todayISO),
    sb.from("listings").select("*",{count:"exact",head:true}),
    sb.from("listings").select("*",{count:"exact",head:true}).eq("status","active"),
    sb.from("listings").select("*",{count:"exact",head:true}).eq("status","sold"),
    sb.from("listings").select("*",{count:"exact",head:true}).eq("status","paused"),
    sb.from("listings").select("*",{count:"exact",head:true}).eq("status","removed"),
    sb.from("listings").select("*",{count:"exact",head:true}).gte("created_at", todayISO),
    sb.from("favorites").select("*",{count:"exact",head:true}),
    sb.from("reports").select("*",{count:"exact",head:true}),
    sb.from("listings").select("views_count"),
    sb.from("stores").select("*",{count:"exact",head:true}),
  ]);
  return {
    usersTotal: usersTotal.count||0, usersToday: usersToday.count||0,
    listingsTotal: listingsTotal.count||0, listingsActive: listingsActive.count||0,
    listingsSold: listingsSold.count||0, listingsPaused: listingsPaused.count||0,
    listingsRemoved: listingsRemoved.count||0, listingsToday: listingsToday.count||0,
    favoritesTotal: favoritesTotal.count||0, reportsTotal: reportsTotal.count||0, storesTotal: storesTotal.count||0,
    totalViews: (viewsRows.data||[]).reduce((s,r)=>s+(r.views_count||0),0),
  };
}
async function renderAdminDashboard(){
  const stats = await fetchDashboardStats();
  const [recentUsers, recentListingsRes, recentReportsRes] = await Promise.all([
    fetchAdminUsers(null),
    sb.from("listings").select("*").order("created_at",{ascending:false}).limit(5),
    sb.from("reports").select("*").order("created_at",{ascending:false}).limit(5),
  ]);
  const cards = [
    ["Registrovani korisnici", stats.usersTotal], ["Novi danas (korisnici)", stats.usersToday],
    ["Ukupno oglasa", stats.listingsTotal], ["Aktivni oglasi", stats.listingsActive],
    ["Prodati oglasi", stats.listingsSold], ["Pauzirani oglasi", stats.listingsPaused],
    ["Uklonjeni oglasi", stats.listingsRemoved], ["Novi danas (oglasi)", stats.listingsToday],
    ["Ukupno pregleda", stats.totalViews], ["Ukupno omiljenih", stats.favoritesTotal],
    ["Ukupno prijava", stats.reportsTotal], ["Prodavnice", stats.storesTotal],
  ];
  const recentListings = recentListingsRes.data||[];
  const recentReports = recentReportsRes.data||[];
  return `
  <h2 style="font-size:20px; margin-bottom:16px;">Dashboard</h2>
  <div class="stat-grid">
    ${cards.map(([l,n])=>`<div class="stat-card"><div class="n">${n}</div><div class="l">${l}</div></div>`).join("")}
  </div>
  <div class="admin-trio">
    <div>
      <h3 style="font-size:14px; margin-bottom:10px;">Novoregistrovani korisnici</h3>
      ${recentUsers.slice(0,5).length ? recentUsers.slice(0,5).map(u=>`<a href="#/admin/users/${u.id}" class="list-row"><div class="info"><div class="t">${esc(u.display_name||u.email)}</div><div class="stats">${esc(u.email)} · ${fmtDate(u.created_at)}</div></div></a>`).join("") : emptyState("👤","Još nema korisnika.","")}
    </div>
    <div>
      <h3 style="font-size:14px; margin-bottom:10px;">Novi oglasi</h3>
      ${recentListings.length ? recentListings.map(l=>`<a href="#/oglas/${l.id}" class="list-row"><div class="info"><div class="t">${esc(l.title)}</div><div class="stats">${fmtPrice(l.price,l.currency)} · ${fmtDate(l.created_at)}</div></div></a>`).join("") : emptyState("🏷️","Još nema oglasa.","")}
    </div>
    <div>
      <h3 style="font-size:14px; margin-bottom:10px;">Nove prijave</h3>
      ${recentReports.length ? recentReports.map(r=>`<a href="#/admin/reports" class="list-row"><div class="info"><div class="t">${esc(r.reason)}</div><div class="stats">${statusLabelReport(r.status)} · ${fmtDate(r.created_at)}</div></div></a>`).join("") : emptyState("🚩","Nema prijava.","")}
    </div>
  </div>`;
}

/* ---- Users ---- */
async function fetchAdminUsers(search){
  try{
    const { data, error } = await sb.rpc("admin_list_users", { p_search: search || null });
    if(error) throw error;
    return data||[];
  }catch(e){ console.error(e); return []; }
}
async function renderAdminUsers(params){
  const q = params.get("q")||"";
  const users = await fetchAdminUsers(q);
  return `
  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:10px;">
    <h2 style="font-size:20px;">Korisnici (${users.length})</h2>
    <input type="text" placeholder="Pretraži po emailu, imenu ili ID..." value="${esc(q)}" style="padding:9px 14px;border-radius:8px;border:1px solid var(--border);min-width:260px;" onkeydown="if(event.key==='Enter')location.hash='/admin/users?q='+encodeURIComponent(this.value)">
  </div>
  ${users.length ? `<div class="overflow-x"><table class="admin-table"><thead><tr><th>Korisnik</th><th>Email</th><th>Registrovan</th><th>Oglasi</th><th>Omiljeni</th><th>Status</th><th>Status prodavca</th><th>Admin</th><th>Akcije</th></tr></thead><tbody>
    ${users.map(u=>`<tr>
      <td><a href="#/admin/users/${u.id}" style="font-weight:600;">${esc(u.display_name||"—")}</a></td>
      <td>${esc(u.email)}</td>
      <td>${fmtDate(u.created_at)}</td>
      <td>${u.listing_count}</td>
      <td>${u.favorite_count}</td>
      <td><span class="status-pill ${u.account_status==='active'?'status-active':u.account_status==='banned'?'status-sold':'status-pending'}">${accountStatusLabel(u.account_status)}</span></td>
      <td>${esc(sellerStatusLabel(u.trader_status))}</td>
      <td>${u.is_admin?'✓':''}</td>
      <td><a href="#/admin/users/${u.id}" class="btn btn-outline btn-sm">Detalji</a></td>
    </tr>`).join("")}
  </tbody></table></div>` : emptyState("👤","Nema korisnika za prikaz.","")}
  `;
}
async function renderAdminUserDetail(userId){
  const users = await fetchAdminUsers(userId);
  const u = users.find(x=>x.id===userId);
  if(!u) return emptyState("👤","Korisnik nije pronađen","");
  const { data: listingsData } = await sb.from("listings").select("*").eq("seller_id", userId).order("created_at",{ascending:false});
  const listings = listingsData||[];
  const sellerCard = await adminSellerStatusHtml(userId);
  return `
  <a href="#/admin/users" style="font-size:12.5px; color:var(--ink-faint);">← Nazad na korisnike</a>
  <div style="display:flex; gap:20px; align-items:center; margin:16px 0 24px; flex-wrap:wrap;">
    <img src="${u.avatar_url||genericAvatar(u.id)}" class="avatar lg" style="object-fit:cover;">
    <div>
      <h2 style="font-size:20px;">${esc(u.display_name||"—")}</h2>
      <div style="font-size:13px; color:var(--ink-faint); margin-top:4px;">${esc(u.email)} · registrovan ${fmtDate(u.created_at)}</div>
      <div style="display:flex; gap:8px; margin-top:8px;">
        <span class="status-pill ${u.account_status==='active'?'status-active':u.account_status==='banned'?'status-sold':'status-pending'}">${accountStatusLabel(u.account_status)}</span>
        ${u.is_admin?'<span class="chip">Administrator</span>':''}
      </div>
    </div>
  </div>
  <div class="stat-grid" style="grid-template-columns:repeat(2,1fr); max-width:400px; margin-bottom:24px;">
    <div class="stat-card"><div class="n">${u.listing_count}</div><div class="l">Oglasa</div></div>
    <div class="stat-card"><div class="n">${u.favorite_count}</div><div class="l">Omiljenih</div></div>
  </div>
  ${sellerCard}
  <div style="display:flex; gap:8px; flex-wrap:wrap; margin-bottom:28px;">
    ${u.account_status!=='suspended'?`<button class="btn btn-outline btn-sm" onclick="adminModerateUser('${u.id}','suspended','Suspendovati ovog korisnika?')">Suspenduj</button>`:`<button class="btn btn-outline btn-sm" onclick="adminModerateUser('${u.id}','active','Ukinuti suspenziju?')">Ukini suspenziju</button>`}
    ${u.account_status!=='banned'?`<button class="btn btn-danger btn-sm" onclick="adminModerateUser('${u.id}','banned','Blokirati ovog korisnika? Ova radnja je ozbiljna.')">Blokiraj</button>`:`<button class="btn btn-outline btn-sm" onclick="adminModerateUser('${u.id}','active','Ukinuti blokadu?')">Ukini blokadu</button>`}
  </div>
  <h3 style="font-size:15px; margin-bottom:12px;">Oglasi korisnika (${listings.length})</h3>
  ${listings.length ? listings.map(l=>`<div class="list-row"><div class="thumb-sm">${l.images&&l.images.length?`<img src="${l.images[0]}" style="width:100%;height:100%;object-fit:cover;border-radius:9px;">`:(CATBYID[l.category]?CATBYID[l.category].emoji:"📦")}</div><div class="info"><div class="t">${esc(l.title)}</div><div class="stats">${fmtPrice(l.price,l.currency)} · <span class="status-pill ${statusClass(l.status)}">${statusLabel(l.status)}</span></div></div><a href="#/oglas/${l.id}" class="btn btn-outline btn-sm">Pogledaj</a></div>`).join("") : emptyState("🏷️","Korisnik nema oglasa.","")}
  `;
}
async function adminModerateUser(userId, status, confirmMsg){
  if(!confirm(confirmMsg)) return;
  try{
    const { error } = await sb.rpc("admin_set_account_status", { p_user_id:userId, p_status:status });
    if(error) throw error;
    toast("Status korisnika je ažuriran");
    route();
  }catch(e){ toast("Greška: "+(e.message||"pokušaj ponovo")); }
}

/* ---- Listings ---- */
async function renderAdminListings(params){
  const q = params.get("q")||"";
  const status = params.get("status")||"";
  const cat = params.get("cat")||"";
  const sort = params.get("sort")||"newest";
  let query = sb.from("listings").select("*");
  if(status) query = query.eq("status", status);
  if(cat) query = query.eq("category", cat);
  let field="created_at", asc=false;
  if(sort==="oldest"){ field="created_at"; asc=true; }
  else if(sort==="views"){ field="views_count"; asc=false; }
  else if(sort==="favorites"){ field="favorites_count"; asc=false; }
  query = query.order(field,{ascending:asc}).limit(300);
  const { data } = await query;
  const all = data||[];
  const sellerIds = [...new Set(all.map(l=>l.seller_id))];
  const profiles = await resolveProfiles(sellerIds);
  let filtered = all;
  if(q){
    const qq = q.toLowerCase();
    filtered = all.filter(l => (l.title||"").toLowerCase().includes(qq) || ((profiles[l.seller_id]&&profiles[l.seller_id].name)||"").toLowerCase().includes(qq));
  }
  return `
  <h2 style="font-size:20px; margin-bottom:16px;">Oglasi (${filtered.length})</h2>
  <div style="display:flex; gap:8px; flex-wrap:wrap; margin-bottom:16px;">
    <input type="text" id="adminListingSearch" placeholder="Pretraži po nazivu ili prodavcu..." value="${esc(q)}" style="padding:9px 14px;border-radius:8px;border:1px solid var(--border);min-width:220px;flex:1;" onkeydown="if(event.key==='Enter')adminListingsFilter()">
    <select id="adminListingStatus" onchange="adminListingsFilter()">
      <option value="">Svi statusi</option>
      ${["draft","active","paused","sold","removed"].map(s=>`<option value="${s}" ${status===s?"selected":""}>${statusLabel(s)}</option>`).join("")}
    </select>
    <select id="adminListingCat" onchange="adminListingsFilter()">
      <option value="">Sve kategorije</option>
      ${CATEGORIES.map(c=>`<option value="${c.id}" ${cat===c.id?"selected":""}>${c.name}</option>`).join("")}
    </select>
    <select id="adminListingSort" onchange="adminListingsFilter()">
      <option value="newest" ${sort==="newest"?"selected":""}>Najnoviji</option>
      <option value="oldest" ${sort==="oldest"?"selected":""}>Najstariji</option>
      <option value="views" ${sort==="views"?"selected":""}>Najgledaniji</option>
      <option value="favorites" ${sort==="favorites"?"selected":""}>Najomiljeniji</option>
    </select>
  </div>
  ${filtered.length ? `<div class="overflow-x"><table class="admin-table"><thead><tr><th>Oglas</th><th>Tip</th><th>Prodavac</th><th>Cena</th><th>Kategorija</th><th>Status</th><th>👁</th><th>♡</th><th>Kreiran</th><th>Akcije</th></tr></thead><tbody>
    ${filtered.map(l=>`<tr>
      <td><a href="#/oglas/${l.id}" style="font-weight:600;">${esc(l.title)}</a>${isFeaturedNow(l)?' <span class="chip">★</span>':''}</td>
      <td>${listingTypeLabel(listingTypeOf(l))}</td>
      <td>${esc((profiles[l.seller_id]&&profiles[l.seller_id].name)||"—")}</td>
      <td>${fmtPrice(l.price,l.currency)}</td>
      <td>${CATBYID[l.category]?CATBYID[l.category].name:l.category}</td>
      <td><span class="status-pill ${statusClass(l.status)}">${statusLabel(l.status)}</span></td>
      <td>${l.views_count||0}</td>
      <td>${l.favorites_count||0}</td>
      <td>${fmtDate(l.created_at)}</td>
      <td style="white-space:nowrap;">
        <a href="#/oglas/${l.id}" class="btn btn-outline btn-sm">Pogledaj</a>
        ${l.status!=="active"?`<button class="btn btn-outline btn-sm" onclick="adminListingAction('${l.id}','active')">Aktiviraj</button>`:`<button class="btn btn-ghost btn-sm" onclick="adminListingAction('${l.id}','paused')">Pauziraj</button>`}
        ${l.status!=="removed"?`<button class="btn btn-danger btn-sm" onclick="adminListingAction('${l.id}','removed',true)">Ukloni</button>`:`<button class="btn btn-outline btn-sm" onclick="adminListingAction('${l.id}','active')">Vrati</button>`}
      </td>
    </tr>`).join("")}
  </tbody></table></div>` : emptyState("🏷️","Nema oglasa za izabrane filtere.","")}
  `;
}
function adminListingsFilter(){
  const q = document.getElementById("adminListingSearch").value;
  const status = document.getElementById("adminListingStatus").value;
  const cat = document.getElementById("adminListingCat").value;
  const sort = document.getElementById("adminListingSort").value;
  const p = new URLSearchParams();
  if(q) p.set("q",q); if(status) p.set("status",status); if(cat) p.set("cat",cat); if(sort!=="newest") p.set("sort",sort);
  location.hash = "/admin/listings"+(p.toString()?("?"+p.toString()):"");
}
async function adminListingAction(id, status, needsConfirm){
  if(needsConfirm && !confirm("Ukloniti ovaj oglas? Vlasnik će videti da je uklonjen.")) return;
  try{
    const { error } = await sb.rpc("admin_set_listing_status", { p_listing_id:id, p_status:status });
    if(error) throw error;
    toast("Status oglasa je ažuriran");
    route();
  }catch(e){ toast("Greška: "+(e.message||"pokušaj ponovo")); }
}

/* ---- Reports ---- */
async function renderAdminReports(params){
  const status = params.get("status")||"";
  let query = sb.from("reports").select("*").order("created_at",{ascending:false}).limit(200);
  if(status) query = query.eq("status", status);
  const { data } = await query;
  const reports = data||[];
  const listingIds = [...new Set(reports.map(r=>r.listing_id).filter(Boolean))];
  const userIds = [...new Set([...reports.map(r=>r.reporter_id), ...reports.map(r=>r.reported_user_id).filter(Boolean)])];
  const [listingResults, profiles] = await Promise.all([
    Promise.all(listingIds.map(id=>fetchListing(id))),
    resolveProfiles(userIds),
  ]);
  const listingsMap = Object.fromEntries(listingResults.filter(Boolean).map(l=>[l.id,l]));
  const statuses = ["pending","reviewing","resolved","dismissed"];
  return `
  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:10px;">
    <h2 style="font-size:20px;">Prijave (${reports.length})</h2>
    <select onchange="location.hash='/admin/reports'+(this.value?('?status='+this.value):'')">
      <option value="">Svi statusi</option>
      ${statuses.map(s=>`<option value="${s}" ${status===s?"selected":""}>${statusLabelReport(s)}</option>`).join("")}
    </select>
  </div>
  ${reports.length ? reports.map(r=>`
    <div style="background:var(--surface); border:1px solid var(--border); border-radius:var(--radius-m); padding:16px; margin-bottom:10px;">
      <div style="display:flex; justify-content:space-between; flex-wrap:wrap; gap:8px;">
        <div><strong style="font-size:13.5px;">${esc(r.reason)}</strong><span class="status-pill ${r.status==='resolved'?'status-active':r.status==='dismissed'?'status-sold':'status-pending'}" style="margin-left:8px;">${statusLabelReport(r.status)}</span></div>
        <span style="font-size:12px; color:var(--ink-faint);">${fmtDate(r.created_at)}</span>
      </div>
      ${r.description?`<p style="font-size:13px; color:var(--ink-dim); margin-top:8px;">${esc(r.description)}</p>`:""}
      <div style="font-size:12.5px; color:var(--ink-faint); margin-top:8px;">
        Prijavio: ${esc((profiles[r.reporter_id]&&profiles[r.reporter_id].name)||"—")}
        ${r.reported_user_id?` · Prodavac: ${esc((profiles[r.reported_user_id]&&profiles[r.reported_user_id].name)||"—")}`:""}
        ${r.listing_id?` · Oglas: ${listingsMap[r.listing_id]?`<a href="#/oglas/${r.listing_id}">${esc(listingsMap[r.listing_id].title)}</a>`:"(obrisan)"}`:""}
      </div>
      ${r.admin_note?`<p style="font-size:12.5px; color:var(--ink-dim); margin-top:6px; background:var(--bg); padding:8px; border-radius:6px;">Napomena: ${esc(r.admin_note)}</p>`:""}
      ${(r.status==="pending"||r.status==="reviewing") ? `<div style="display:flex; gap:6px; margin-top:12px; flex-wrap:wrap;">
          ${r.status==="pending"?`<button class="btn btn-outline btn-sm" onclick="adminReportAction('${r.id}','reviewing')">Označi kao u pregledu</button>`:""}
          <button class="btn btn-primary btn-sm" onclick="adminReportResolve('${r.id}','resolved')">Reši</button>
          <button class="btn btn-ghost btn-sm" onclick="adminReportResolve('${r.id}','dismissed')">Odbaci</button>
        </div>`:""}
    </div>`).join("") : emptyState("🚩","Nema prijava za izabrani status.","")}
  `;
}
async function adminReportAction(id, status){
  try{ const { error } = await sb.rpc("admin_resolve_report", { p_report_id:id, p_status:status }); if(error) throw error; toast("Prijava ažurirana"); route(); }
  catch(e){ toast("Greška: "+(e.message||"pokušaj ponovo")); }
}
function adminReportResolve(id, status){
  const note = prompt(status==="resolved" ? "Napomena pre rešavanja prijave (opciono):" : "Napomena pre odbacivanja prijave (opciono):");
  if(note===null) return;
  adminReportResolveConfirmed(id, status, note);
}
async function adminReportResolveConfirmed(id, status, note){
  try{ const { error } = await sb.rpc("admin_resolve_report", { p_report_id:id, p_status:status, p_admin_note: note||null }); if(error) throw error; toast("Prijava ažurirana"); route(); }
  catch(e){ toast("Greška: "+(e.message||"pokušaj ponovo")); }
}

/* ---- Categories ---- */
async function renderAdminCategories(){
  const { data } = await sb.from("categories").select("*").order("name");
  const cats = data||[];
  return `
  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
    <h2 style="font-size:20px;">Kategorije (${cats.length})</h2>
    <button class="btn btn-primary btn-sm" onclick="adminCategoryFormToggle(null)">+ Nova kategorija</button>
  </div>
  <div id="adminCategoryForm"></div>
  <div class="overflow-x"><table class="admin-table"><thead><tr><th>Emoji</th><th>ID</th><th>Naziv</th><th>Status</th><th>Akcije</th></tr></thead><tbody>
    ${cats.map(c=>`<tr>
      <td>${c.emoji||""}</td><td><code>${esc(c.id)}</code></td><td>${esc(c.name)}</td>
      <td><span class="status-pill ${c.is_active?'status-active':'status-sold'}">${c.is_active?"Aktivna":"Isključena"}</span></td>
      <td>
        <button class="btn btn-outline btn-sm" onclick='adminCategoryFormToggle(${JSON.stringify(c)})'>Uredi</button>
        <a class="btn btn-outline btn-sm" href="#/admin/specifications?cat=${encodeURIComponent(c.id)}">Specifikacije</a>
        ${c.is_active?`<button class="btn btn-ghost btn-sm" onclick="adminToggleCategory('${c.id}',false)">Isključi</button>`:`<button class="btn btn-ghost btn-sm" onclick="adminToggleCategory('${c.id}',true)">Uključi</button>`}
        <button class="btn btn-danger btn-sm" onclick="adminDeleteCategory('${c.id}')">Obriši</button>
      </td>
    </tr>`).join("")}
  </tbody></table></div>
  <p style="font-size:12px; color:var(--ink-faint); margin-top:12px;">Isključene kategorije se ne prikazuju kupcima, a postojeći oglasi u njima ostaju netaknuti. Kategorija se može obrisati samo ako nema nijedan oglas ni prodavnicu; inače je isključi.</p>
  `;
}
function adminCategoryFormToggle(cat){
  const container = document.getElementById("adminCategoryForm");
  if(!container) return;
  if(!cat && container.dataset.open==="1"){ container.innerHTML=""; container.dataset.open="0"; return; }
  container.dataset.open="1";
  container.innerHTML = `<div style="background:var(--surface); border:1px solid var(--border); border-radius:var(--radius-m); padding:16px; margin-bottom:16px; max-width:420px;">
    <h4 style="font-size:13.5px; margin-bottom:10px;">${cat?"Uredi kategoriju":"Nova kategorija"}</h4>
    <div class="form-group"><label>ID (slug, npr. "muzika")</label><input type="text" id="catId" value="${cat?esc(cat.id):''}" ${cat?'readonly style="background:var(--bg);"':''}></div>
    <div class="form-group"><label>Naziv</label><input type="text" id="catName" value="${cat?esc(cat.name):''}"></div>
    <div class="form-group"><label>Emoji</label><input type="text" id="catEmoji" value="${cat?esc(cat.emoji||''):''}" style="max-width:80px;"></div>
    <div style="display:flex; gap:8px;">
      <button class="btn btn-primary btn-sm" onclick="adminSaveCategory()">Sačuvaj</button>
      <button class="btn btn-ghost btn-sm" onclick="adminCategoryFormToggle(null)">Otkaži</button>
    </div>
  </div>`;
}
async function adminSaveCategory(){
  const id = document.getElementById("catId").value.trim().toLowerCase().replace(/[^a-z0-9]/g,"");
  const name = document.getElementById("catName").value.trim();
  const emoji = document.getElementById("catEmoji").value.trim();
  if(!id || !name){ toast("Popuni ID i naziv"); return; }
  try{
    const { error } = await sb.rpc("admin_upsert_category", { p_id:id, p_name:name, p_emoji:emoji||null, p_is_active:true });
    if(error) throw error;
    toast("Kategorija sačuvana");
    await loadCategories();
    route();
  }catch(e){ toast("Greška: "+(e.message||"pokušaj ponovo")); }
}
async function adminDeleteCategory(id){
  const c = CATBYID[id];
  if(!confirm(`Obrisati kategoriju „${c?c.name:id}“?\nSpecifikacije vezane samo za nju biće obrisane (deljene ostaju za druge kategorije). Ako kategorija ima oglase, brisanje neće biti dozvoljeno.`)) return;
  try{
    const { error } = await sb.rpc("admin_delete_category", { p_id:id });
    if(error) throw error;
    toast("Kategorija obrisana");
    await loadCategories();
    route();
  }catch(e){ toast("Greška: "+((e&&e.message)||"pokušaj ponovo")); }
}
async function adminToggleCategory(id, active){
  try{
    const { data: cur } = await sb.from("categories").select("*").eq("id",id).maybeSingle();
    if(!cur) return;
    const { error } = await sb.rpc("admin_upsert_category", { p_id:id, p_name:cur.name, p_emoji:cur.emoji, p_is_active:active });
    if(error) throw error;
    toast(active?"Kategorija uključena":"Kategorija isključena");
    await loadCategories();
    route();
  }catch(e){ toast("Greška: "+(e.message||"pokušaj ponovo")); }
}

/* ---- Specifications (global fields assigned to categories + listing types; managed via the existing RPCs) ---- */
function specKeyFromName(s){
  return String(s||"").toLowerCase().replace(/đ/g,"dj").normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9]+/g,"_").replace(/^_+|_+$/g,"").slice(0,60);
}
function specTypesText(s){ const lt = s.listing_types||[]; return lt.length ? lt.map(listingTypeLabel).join(", ") : "Svi tipovi"; }
function specCatsText(s){ const c = s.category_ids||[]; return c.length ? c.map(id=>(CATBYID[id]?CATBYID[id].name:id)).join(", ") : "Sve kategorije"; }
async function fetchAdminSpecs(){
  const { data, error } = await sb.from("category_specifications").select("*").order("sort_order").order("created_at");
  if(error) throw error;
  return data||[];
}
function isMissingDbObject(e){ return !!e && (e.code==="PGRST205" || e.code==="42P01" || e.code==="PGRST202" || e.code==="42883" || /schema cache|does not exist|Could not find/i.test(e.message||"")); }
async function renderAdminSpecifications(params){
  const cats = CATEGORIES;
  const cat = params.get("cat") || (cats[0] && cats[0].id) || "";
  let all = [];
  try{ all = await fetchAdminSpecs(); }
  catch(e){
    if(isMissingDbObject(e)) return emptyState("🛠️","Tabela specifikacija nije dostupna","Baza ne vraća tabelu <code>category_specifications</code>.<br><code style=\"font-size:12px;\">"+esc(e.message||"")+"</code>");
    throw e;
  }
  const specs = all.filter(s=>!(s.category_ids||[]).length || s.category_ids.includes(cat));
  window.__adminSpecs = all; window.__adminSpecView = specs; window.__adminSpecCat = cat;
  const catName = (CATBYID[cat]||{}).name || cat;
  return `
  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; gap:10px; flex-wrap:wrap;">
    <h2 style="font-size:20px;">Specifikacije: ${esc(catName)} (${specs.length})</h2>
    <div style="display:flex; gap:8px; flex-wrap:wrap;"><a class="btn btn-outline btn-sm" href="#/admin/categories">🗂️ Upravljaj kategorijama</a><button class="btn btn-primary btn-sm" onclick="adminSpecFormToggle(null)">+ Nova specifikacija</button></div>
  </div>
  <div class="form-group" style="max-width:320px;"><label>Kategorija</label>
    <select onchange="location.hash='/admin/specifications?cat='+this.value">
      ${cats.map(c=>`<option value="${c.id}" ${cat===c.id?"selected":""}>${c.emoji||""} ${esc(c.name)}${c.isActive===false?" (isključena)":""}</option>`).join("")}
    </select></div>
  <div id="adminSpecForm"></div>
  ${specs.length ? `<div class="overflow-x"><table class="admin-table"><thead><tr><th>Redosled</th><th>Naziv</th><th>Tip polja</th><th>Kategorije</th><th>Tipovi oglasa</th><th>Obavezno</th><th>Filter</th><th>Status</th><th>Akcije</th></tr></thead><tbody>
    ${specs.map((s,i)=>`<tr>
      <td style="white-space:nowrap;"><button class="btn btn-ghost btn-sm" ${i===0?"disabled":""} onclick="adminMoveSpec('${s.id}',-1)" aria-label="Pomeri gore">▲</button><button class="btn btn-ghost btn-sm" ${i===specs.length-1?"disabled":""} onclick="adminMoveSpec('${s.id}',1)" aria-label="Pomeri dole">▼</button></td>
      <td><strong>${esc(s.label)}</strong>${s.unit?` <span class="chip">${esc(s.unit)}</span>`:""}<div style="font-size:11px;color:var(--ink-faint);"><code>${esc(s.key)}</code>${(s.field_type==="select"||s.field_type==="multiselect")?` · ${specOptions(s).length} opcija`:""}</div></td>
      <td>${esc((SPEC_FIELD_TYPES.find(f=>f[0]===s.field_type)||[0,s.field_type])[1])}</td>
      <td>${esc(specCatsText(s))}</td>
      <td>${esc(specTypesText(s))}</td>
      <td>${s.is_required?"Da":"Ne"}</td>
      <td>${s.is_filterable?`<span class="status-pill status-active">Filter</span>`:"—"}</td>
      <td><span class="status-pill ${s.is_active?'status-active':'status-sold'}">${s.is_active?"Aktivna":"Isključena"}</span></td>
      <td style="white-space:nowrap;">
        <button class="btn btn-outline btn-sm" onclick="adminSpecFormToggle('${s.id}')">Uredi</button>
        <button class="btn btn-ghost btn-sm" onclick="adminToggleSpec('${s.id}',${!s.is_active})">${s.is_active?"Isključi":"Uključi"}</button>
        <button class="btn btn-danger btn-sm" onclick="adminDeleteSpec('${s.id}')">Obriši</button>
      </td></tr>`).join("")}
  </tbody></table></div>` : emptyState("🧩","Nema specifikacija za ovu kategoriju.","Dodaj prvu specifikaciju dugmetom „Nova specifikacija“.")}
  <p style="font-size:12px; color:var(--ink-faint); margin-top:12px;">Specifikacije se prikazuju u formi za postavljanje/uređivanje oglasa i na stranici oglasa. Ako je uključeno „Prikaži kao filter“, specifikacija se automatski pojavljuje među filterima pretrage u svojim kategorijama (isključivanjem nestaje iz filtera, a specifikacija i vrednosti ostaju). Specifikacija može važiti za više kategorija ili za sve; izmena važi svuda gde je dodeljena. Isključene specifikacije se sakrivaju, a sačuvane vrednosti ostaju. Brisanje trajno uklanja i sačuvane vrednosti iz oglasa (sami oglasi ostaju).</p>`;
}
function adminSpecFormToggle(id){
  const box = document.getElementById("adminSpecForm"); if(!box) return;
  const s = id ? (window.__adminSpecs||[]).find(x=>x.id===id) : null;
  if(!s && box.dataset.open==="1"){ box.innerHTML=""; box.dataset.open="0"; return; }
  box.dataset.open = "1";
  const lt = s ? (s.listing_types||[]) : [];
  const sc = s ? (s.category_ids||[]) : [];
  const allT = !lt.length, allC = s ? !sc.length : false;
  const cur = window.__adminSpecCat;
  box.innerHTML = `<div style="background:var(--surface); border:1px solid var(--border); border-radius:var(--radius-m); padding:16px; margin-bottom:16px; max-width:520px;">
    <h4 style="font-size:13.5px; margin-bottom:10px;">${s?"Uredi specifikaciju":"Nova specifikacija"}</h4>
    <input type="hidden" id="spId" value="${s?s.id:""}">
    <div class="form-group"><label>Naziv (npr. „Kilometraža“)</label><input type="text" id="spName" maxlength="80" value="${s?esc(s.label):""}" oninput="adminSpecAutoKey()"></div>
    <div class="form-group"><label>Ključ (mala slova, brojevi, _)</label><input type="text" id="spKey" maxlength="60" value="${s?esc(s.key):""}" ${s?'readonly style="background:var(--bg);"':'oninput="this.dataset.manual=\'1\'"'}></div>
    <div class="form-row">
      <div class="form-group"><label>Tip polja</label><select id="spType" onchange="adminSpecTypeChanged()">${SPEC_FIELD_TYPES.map(f=>`<option value="${f[0]}" ${s&&s.field_type===f[0]?"selected":""}>${f[1]}</option>`).join("")}</select></div>
      <div class="form-group"><label>Jedinica (opciono, npr. km, GB)</label><input type="text" id="spUnit" maxlength="20" value="${s&&s.unit?esc(s.unit):""}"></div>
    </div>
    <div class="form-group"><label>Pomoćni tekst (opciono)</label><input type="text" id="spHelp" maxlength="200" value="${s&&s.help_text?esc(s.help_text):""}"></div>
    <div class="form-group" id="spOptionsBox" style="display:none;"><label>Opcije (jedna po redu)</label><textarea id="spOptions" style="min-height:90px;">${s?esc(specOptions(s).map(o=>o.label).join("\n")):""}</textarea></div>
    <div class="form-row" id="spRangeBox" style="display:none;">
      <div class="form-group"><label>Minimum (opciono)</label><input type="number" step="any" id="spMin" value="${s&&s.min_value!=null?esc(s.min_value):""}"></div>
      <div class="form-group"><label>Maksimum (opciono)</label><input type="number" step="any" id="spMax" value="${s&&s.max_value!=null?esc(s.max_value):""}"></div>
    </div>
    <div class="form-group"><label>Kategorije</label>
      <label class="f-check"><input type="checkbox" id="spAllCats" ${allC?"checked":""} onchange="adminSpecCatsChanged()"> Sve kategorije</label>
      ${CATEGORIES.map(c=>`<label class="f-check"><input type="checkbox" class="spCatCb" value="${c.id}" ${(s?sc.includes(c.id):c.id===cur)?"checked":""} ${allC?"disabled":""}> ${c.emoji||""} ${esc(c.name)}</label>`).join("")}
    </div>
    <div class="form-group"><label>Tipovi oglasa</label>
      <label class="f-check"><input type="checkbox" id="spAllTypes" ${allT?"checked":""} onchange="adminSpecTypesChanged()"> Svi tipovi oglasa</label>
      ${LISTING_TYPES.map(x=>`<label class="f-check"><input type="checkbox" class="spTypeCb" value="${x.id}" ${lt.includes(x.id)?"checked":""} ${allT?"disabled":""}> ${x.label}</label>`).join("")}
    </div>
    <label class="f-check"><input type="checkbox" id="spRequired" ${s&&s.is_required?"checked":""}> Obavezno polje</label>
    <label class="f-check"><input type="checkbox" id="spActive" ${!s||s.is_active?"checked":""}> Aktivna</label>
    <label class="f-check"><input type="checkbox" id="spFilterable" ${s&&s.is_filterable?"checked":""}> Prikaži kao filter u pretrazi (za izabrane kategorije)</label>
    <div style="display:flex; gap:8px; margin-top:12px;">
      <button class="btn btn-primary btn-sm" onclick="adminSaveSpec()">Sačuvaj</button>
      <button class="btn btn-ghost btn-sm" onclick="adminSpecFormToggle(null)">Otkaži</button>
    </div>
  </div>`;
  adminSpecTypeChanged();
}
function adminSpecAutoKey(){
  const k = document.getElementById("spKey"); if(!k || k.readOnly || k.dataset.manual==="1") return;
  k.value = specKeyFromName(document.getElementById("spName").value);
}
function adminSpecTypeChanged(){
  const t = document.getElementById("spType").value;
  const b = document.getElementById("spOptionsBox"); if(b) b.style.display = (t==="select"||t==="multiselect") ? "" : "none";
  const r = document.getElementById("spRangeBox"); if(r) r.style.display = (t==="number"||t==="decimal") ? "" : "none";
}
function adminSpecCatsChanged(){
  const all = document.getElementById("spAllCats").checked;
  document.querySelectorAll(".spCatCb").forEach(cb=>{ cb.disabled = all; if(all) cb.checked = false; });
}
function adminSpecTypesChanged(){
  const all = document.getElementById("spAllTypes").checked;
  document.querySelectorAll(".spTypeCb").forEach(cb=>{ cb.disabled = all; if(all) cb.checked = false; });
}
async function adminSaveSpec(){
  const id = document.getElementById("spId").value;
  const label = document.getElementById("spName").value.trim();
  const key = document.getElementById("spKey").value.trim() || specKeyFromName(label);
  const field_type = document.getElementById("spType").value;
  const allC = document.getElementById("spAllCats").checked, allT = document.getElementById("spAllTypes").checked;
  const category_ids = allC ? [] : [...document.querySelectorAll(".spCatCb:checked")].map(cb=>cb.value);
  const listing_types = allT ? [] : [...document.querySelectorAll(".spTypeCb:checked")].map(cb=>cb.value);
  if(!label){ toast("Unesi naziv"); return; }
  if(!id && !/^[a-z0-9_]{1,60}$/.test(key)){ toast("Ključ sme da sadrži samo mala slova, brojeve i _"); return; }
  if(!allC && !category_ids.length){ toast("Izaberi bar jednu kategoriju ili „Sve kategorije“"); return; }
  if(!allT && !listing_types.length){ toast("Izaberi bar jedan tip oglasa ili „Svi tipovi“"); return; }
  let options = [];
  if(field_type==="select" || field_type==="multiselect"){
    const labels = [...new Set(document.getElementById("spOptions").value.split("\n").map(x=>x.trim()).filter(Boolean))];
    if(!labels.length){ toast("Dodaj bar jednu opciju"); return; }
    const cur = id ? (window.__adminSpecs||[]).find(x=>x.id===id) : null;
    const prev = Object.fromEntries((cur?specOptions(cur):[]).map(o=>[o.label,o.value]));   // keep stored values stable on edit
    const used = new Set(Object.values(prev).filter((v,i)=>labels.includes(Object.keys(prev)[i])));
    options = labels.map(lb=>{
      if(prev[lb]) return {value:prev[lb], label:lb};
      let base = specKeyFromName(lb) || "opcija", v = base, n = 2;
      while(used.has(v)){ v = base.slice(0,56)+"_"+(n++); }
      used.add(v); return {value:v, label:lb};
    });
  }
  const num = el => { const v = document.getElementById(el).value.trim(); return v===""?"":v; };
  const data = {
    label, field_type, options,
    unit: document.getElementById("spUnit").value.trim(), help_text: document.getElementById("spHelp").value.trim(),
    min_value: (field_type==="number"||field_type==="decimal") ? num("spMin") : "", max_value: (field_type==="number"||field_type==="decimal") ? num("spMax") : "",
    is_required: document.getElementById("spRequired").checked, is_active: document.getElementById("spActive").checked,
    is_filterable: document.getElementById("spFilterable").checked, category_ids, listing_types,
  };
  if(!id) data.key = key;
  try{
    const { error } = await sb.rpc("admin_upsert_specification", { p_id: id||null, p_data: data });
    if(error) throw error;
    toast("Specifikacija sačuvana");
    route();
  }catch(e){ toast("Greška: "+((e&&e.message)||"pokušaj ponovo")); }
}
async function adminToggleSpec(id, active){
  try{
    const { error } = await sb.rpc("admin_set_specification_active", { p_id:id, p_active:active });
    if(error) throw error;
    toast(active?"Specifikacija uključena":"Specifikacija isključena"); route();
  }catch(e){ toast("Greška: "+((e&&e.message)||"pokušaj ponovo")); }
}
async function adminDeleteSpec(id){
  const s = (window.__adminSpecs||[]).find(x=>x.id===id); if(!s) return;
  let n = 0;
  try{ const r = await sb.from("listing_specification_values").select("id",{count:"exact",head:true}).eq("specification_id", id); n = r.count||0; }catch(e){}
  const shared = (s.category_ids||[]).length!==1;
  if(!confirm(`Obrisati specifikaciju „${s.label}“?`+(shared?`\nVaži za: ${specCatsText(s)} — biće uklonjena svuda.`:"")+(n?`\nBiće trajno obrisano ${n} sačuvanih vrednosti u oglasima (sami oglasi ostaju). Alternativa: isključi je.`:""))) return;
  try{
    const { error } = await sb.rpc("admin_delete_specification", { p_id:id });
    if(error) throw error;
    toast("Specifikacija obrisana"); route();
  }catch(e){ toast("Greška: "+((e&&e.message)||"pokušaj ponovo")); }
}
async function adminMoveSpec(id, dir){
  try{
    const ids = (window.__adminSpecView||[]).map(s=>s.id);   // order within the category being viewed
    const i = ids.indexOf(id), j = i+dir;
    if(i<0 || j<0 || j>=ids.length) return;
    [ids[i], ids[j]] = [ids[j], ids[i]];
    const { error } = await sb.rpc("admin_reorder_specifications", { p_ids: ids });
    if(error) throw error;
    route();
  }catch(e){ toast("Greška: "+((e&&e.message)||"pokušaj ponovo")); }
}

/* ---- Promotions ---- */
async function renderAdminPromotions(){
  const [{data: featuredData}, {data: activeData}] = await Promise.all([
    sb.from("listings").select("*").eq("is_featured", true).order("created_at",{ascending:false}),
    sb.from("listings").select("id,title,price,currency").eq("status","active").order("created_at",{ascending:false}).limit(80),
  ]);
  const featured = featuredData||[];
  const candidates = (activeData||[]).filter(l=>!featured.some(f=>f.id===l.id));
  return `
  <h2 style="font-size:20px; margin-bottom:16px;">Promocije / Izdvojeni oglasi</h2>
  <h3 style="font-size:14px; margin-bottom:10px;">Trenutno izdvojeni (${featured.length})</h3>
  ${featured.length ? `<div class="listing-grid" style="margin-bottom:14px;">${featured.map(listingCard).join("")}</div>
    <div style="display:flex; gap:8px; flex-wrap:wrap;">${featured.map(l=>`<button class="btn btn-ghost btn-sm" onclick="adminSetFeatured('${l.id}',false)">Ukloni „${esc(l.title).slice(0,24)}” sa izdvojenih</button>`).join("")}</div>`
    : emptyState("★","Trenutno nema izdvojenih oglasa.","")}
  <h3 style="font-size:14px; margin:24px 0 10px;">Izdvoj novi oglas</h3>
  ${candidates.length ? `<div style="display:flex; gap:8px; max-width:480px;">
    <select id="promoteListingSelect" style="flex:1;">
      ${candidates.map(l=>`<option value="${l.id}">${esc(l.title)} — ${fmtPrice(l.price,l.currency)}</option>`).join("")}
    </select>
    <button class="btn btn-primary btn-sm" onclick="adminFeatureSelected()">Izdvoj</button>
  </div>` : `<p style="font-size:13px; color:var(--ink-faint);">Nema dostupnih aktivnih oglasa za izdvajanje.</p>`}
  `;
}
async function adminFeatureSelected(){
  const sel = document.getElementById("promoteListingSelect");
  if(!sel || !sel.value) return;
  await adminSetFeatured(sel.value, true);
}
async function adminSetFeatured(id, featured){
  try{
    const { error } = await sb.rpc("admin_set_featured", { p_listing_id:id, p_featured:featured, p_until:null });
    if(error) throw error;
    toast(featured?"Oglas je izdvojen":"Oglas više nije izdvojen");
    route();
  }catch(e){ toast("Greška: "+(e.message||"pokušaj ponovo")); }
}

/* ---- Activity log ---- */
async function renderAdminActivity(){
  const { data } = await sb.from("admin_actions").select("*").order("created_at",{ascending:false}).limit(200);
  const actions = data||[];
  const adminIds = [...new Set(actions.map(a=>a.admin_id))];
  const profiles = await resolveProfiles(adminIds);
  return `
  <h2 style="font-size:20px; margin-bottom:16px;">Istorija admin akcija (${actions.length})</h2>
  ${actions.length ? `<div class="overflow-x"><table class="admin-table"><thead><tr><th>Vreme</th><th>Admin</th><th>Akcija</th><th>Cilj</th><th>Opis</th></tr></thead><tbody>
    ${actions.map(a=>`<tr><td>${fmtDate(a.created_at)}</td><td>${esc((profiles[a.admin_id]&&profiles[a.admin_id].name)||"—")}</td><td>${esc(a.action_type)}</td><td>${esc(a.target_type)}</td><td>${esc(a.description||"")}</td></tr>`).join("")}
  </tbody></table></div>` : emptyState("📜","Još nema zabeleženih akcija.","")}
  `;
}

/* ---- Settings ---- */
function renderAdminSettings(){
  return `
  <h2 style="font-size:20px; margin-bottom:16px;">Podešavanja</h2>
  <div style="background:var(--surface); border:1px solid var(--border); border-radius:var(--radius-m); padding:20px; max-width:480px;">
    <table class="spec-table">
      <tr><td>Email administratora</td><td>${esc(ME.email)}</td></tr>
      <tr><td>Status naloga</td><td>Aktivan administrator</td></tr>
      <tr><td>Supabase projekat</td><td><code style="font-size:12px;">${SUPABASE_URL.replace("https://","").split(".")[0]}</code></td></tr>
    </table>
    <p style="font-size:12px; color:var(--ink-faint); margin-top:14px;">Admin status (is_admin) se ne može menjati iz aplikacije, iz bezbednosnih razloga — isključivo direktno u Supabase bazi.</p>
  </div>`;
}


/* ======================================================================
   SELLER STORES (multi-vendor shops)
   Architecture: hybrid. `stores` + `store_categories` are new tables;
   store products ARE rows in the existing `listings` table (store_id set),
   so search, favorites, messaging, reports, views and admin moderation
   all keep working. Security lives in RLS + triggers (see
   supabase/migrations/20261001_stores.sql), not in this file.
   ====================================================================== */
const STORE_CACHE = {};                 // id -> {id,name,slug,logo_url}
const viewedStoresThisSession = new Set();
let storeImgState = {logo:null, cover:null};
let pform = null;                       // product form state

function slugify(s){
  return String(s||"").toLowerCase().replace(/đ/g,"dj").normalize("NFD").replace(/[\u0300-\u036f]/g,"")
    .replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"").slice(0,40).replace(/-+$/,"");
}
function storeStatusLabel(s){ return {active:"Aktivna",inactive:"Neaktivna",suspended:"Suspendovana"}[s]||s; }
function storeStatusClass(s){ return s==="active"?"status-active":s==="suspended"?"status-sold":"status-pending"; }
function productUnavailable(l){ return l.available===false || l.stock===0; }

async function cacheStoresFor(list){
  const ids = [...new Set((list||[]).map(l=>l.store_id).filter(id=>id && !STORE_CACHE[id]))];
  if(!ids.length) return;
  try{
    const { data } = await sb.from("stores").select("id,name,slug,logo_url").in("id", ids);
    (data||[]).forEach(s=>{ STORE_CACHE[s.id] = s; });
  }catch(e){}
}
function listingHref(l){
  const s = l.store_id && STORE_CACHE[l.store_id];
  return (s && l.slug) ? `#/prodavnica/${encodeURIComponent(s.slug)}/proizvod/${encodeURIComponent(l.slug)}` : `#/oglas/${esc(l.id)}`;
}
function storeLogoHtml(s, size){
  const cls = "store-logo " + (size||"md");
  if(s && s.logo_url) return `<img src="${esc(s.logo_url)}" class="${cls}" alt="">`;
  return `<div class="${cls} ph">${esc(((s&&s.name)||"P").trim().charAt(0).toUpperCase())}</div>`;
}

/* ---------- queries ---------- */
async function fetchStoreBySlug(slug){
  try{ const { data, error } = await sb.from("stores").select("*").eq("slug", slug).maybeSingle(); if(error) throw error; return data; }catch(e){ return null; }
}
async function fetchStoreById(id){
  try{ const { data, error } = await sb.from("stores").select("*").eq("id", id).maybeSingle(); if(error) throw error; return data; }catch(e){ return null; }
}
async function fetchMyStore(){
  if(!ME.id) return null;
  try{ const { data, error } = await sb.from("stores").select("*").eq("owner_id", ME.id).maybeSingle(); if(error) throw error; return data; }catch(e){ return null; }
}
async function fetchStoreCategories(storeId){
  try{ const { data, error } = await sb.from("store_categories").select("*").eq("store_id", storeId).order("sort_order").order("name"); if(error) throw error; return data||[]; }catch(e){ return []; }
}
async function fetchStoreProducts(storeId, onlyActive){
  try{
    let q = sb.from("listings").select("*").eq("store_id", storeId);
    if(onlyActive) q = q.eq("status","active");
    const { data, error } = await q.order("created_at",{ascending:false}).limit(500);
    if(error) throw error; return data||[];
  }catch(e){ return []; }
}
async function fetchStoreProductBySlug(storeId, productSlug){
  try{ const { data } = await sb.from("listings").select("*").eq("store_id", storeId).eq("slug", productSlug).maybeSingle(); return data; }catch(e){ return null; }
}
async function fetchStoreCounts(ids){
  if(!ids.length) return {};
  try{
    const { data, error } = await sb.rpc("store_product_counts", { p_store_ids: ids });
    if(error) throw error;
    return Object.fromEntries((data||[]).map(r=>[r.store_id, Number(r.product_count)||0]));
  }catch(e){ return {}; }
}
async function fetchActiveStores(opts){
  opts = opts||{};
  try{
    let q = sb.from("stores").select("*").eq("status","active");
    if(opts.q) q = q.ilike("name", `%${opts.q.replace(/[%,()]/g," ")}%`);
    if(opts.cat) q = q.eq("category", opts.cat);
    const { data, error } = await q.order("created_at",{ascending:false}).limit(opts.limit||100);
    if(error) throw error; return data||[];
  }catch(e){ return []; }
}
async function recordStoreView(storeId){
  if(viewedStoresThisSession.has(storeId)) return;
  viewedStoresThisSession.add(storeId);
  try{ await sb.rpc("record_store_view", { p_store_id: storeId, p_viewer_key: getViewerKey() }); }catch(e){}
}

/* ---------- cards ---------- */
function storeCard(s, count){
  const cat = CATBYID[s.category];
  return `<a class="store-card" href="#/prodavnica/${esc(s.slug)}">
    <div class="store-card-cover">${s.cover_url?`<img src="${esc(s.cover_url)}" alt="" loading="lazy">`:""}</div>
    <div class="store-card-body">
      ${storeLogoHtml(s,"md")}
      <div style="min-width:0;">
        <div class="n">${esc(s.name)}</div>
        <div class="c">${cat?`${cat.emoji} ${esc(cat.name)}`:"Prodavnica"}${s.city?` · ${esc(s.city)}`:""}</div>
        <div class="p">${count||0} proizvoda</div>
      </div>
    </div>
  </a>`;
}
function storeGrid(stores, counts){
  return `<div class="store-grid">${stores.map(s=>storeCard(s, counts[s.id])).join("")}</div>`;
}

/* ---------- STORE DIRECTORY ---------- */
async function viewStores(params){
  const q = (params.get("q")||"").trim();
  const cat = params.get("cat")||"";
  const stores = await fetchActiveStores({q, cat});
  const counts = await fetchStoreCounts(stores.map(s=>s.id));
  const myStore = ME.id ? await fetchMyStore() : null;
  return `<div class="wrap section">
    <div class="section-head" style="flex-wrap:wrap;">
      <h2>Prodavnice</h2>
      ${myStore ? `<a class="btn btn-outline btn-sm" href="#/moja-prodavnica">🏪 Moja prodavnica</a>` : `<a class="btn btn-primary btn-sm" href="#/moja-prodavnica">+ Otvori prodavnicu</a>`}
    </div>
    <div style="display:flex; gap:8px; flex-wrap:wrap; margin-bottom:18px;">
      <input type="text" placeholder="Pretraži prodavnice..." value="${esc(q)}" style="flex:1; min-width:180px; padding:10px 14px; border-radius:999px; border:1px solid var(--border); background:var(--surface); color:var(--ink);" onkeydown="if(event.key==='Enter')location.hash='/prodavnice?'+mkFilter('q',this.value.trim())">
      <select onchange="location.hash='/prodavnice?'+mkFilter('cat',this.value)">
        <option value="">Sve kategorije</option>
        ${activeCategories().map(c=>`<option value="${c.id}" ${cat===c.id?"selected":""}>${c.emoji} ${c.name}</option>`).join("")}
      </select>
    </div>
    ${stores.length ? storeGrid(stores, counts)
      : emptyState("🏪", q||cat?"Nema prodavnica za izabranu pretragu.":"Još nema prodavnica.", "Budi prvi koji će otvoriti svoju prodavnicu na PazariMe.", `<a href="#/moja-prodavnica" class="btn btn-primary" style="margin-top:14px;">Otvori prodavnicu</a>`)}
  </div>`;
}

/* ---------- PUBLIC STORE PAGE ---------- */
function eurEq(l){ const p = effPrice(l); return l.currency==="RSD" ? p/EUR_RSD_REF : p; }   // comparison only; never shown or stored
function storeSortProducts(list, key){
  const a = list.slice(), byNew = (x,y)=>new Date(y.created_at)-new Date(x.created_at);
  if(key==="cheap") a.sort((x,y)=>eurEq(x)-eurEq(y)||byNew(x,y));
  else if(key==="expensive") a.sort((x,y)=>eurEq(y)-eurEq(x)||byNew(x,y));
  else if(key==="popular") a.sort((x,y)=>(y.views_count||0)-(x.views_count||0)||byNew(x,y));
  else a.sort(byNew);
  return a;
}
async function viewStore(slug, sub, productSlug, params){
  const notFound = `<div class="wrap section">${emptyState("🏪","Prodavnica nije pronađena","Prodavnica ne postoji ili trenutno nije aktivna.", `<a href="#/prodavnice" class="btn btn-primary" style="margin-top:14px;">Sve prodavnice</a>`)}</div>`;
  const store = await fetchStoreBySlug(slug);
  if(!store || (store.status!=="active" && store.owner_id!==ME.id && !isAdmin())) return notFound;

  if(sub==="proizvod" && productSlug){
    const l = await fetchStoreProductBySlug(store.id, productSlug);
    if(!l) return `<div class="wrap section">${emptyState("🔎","Proizvod nije pronađen","", `<a href="#/prodavnica/${esc(store.slug)}" class="btn btn-primary" style="margin-top:14px;">Nazad u prodavnicu</a>`)}</div>`;
    STORE_CACHE[store.id] = store;
    return viewListingDetail(l.id);
  }

  if(store.status==="active") recordStoreView(store.id);
  const kat = params.get("k")||"";
  const sq = (params.get("q")||"").trim().toLowerCase();
  const [all, cats, profiles, sellerSt] = await Promise.all([
    fetchStoreProducts(store.id, true), fetchStoreCategories(store.id), resolveProfiles([store.owner_id]), fetchSellerStatuses([store.owner_id])
  ]);
  STORE_CACHE[store.id] = store;
  let products = all;
  if(kat) products = products.filter(p=>p.store_category_id===kat);
  if(sq) products = products.filter(p=>(p.title||"").toLowerCase().includes(sq));
  const onlyPromo = params.get("ak")==="1", sortKey = params.get("s")||"new";
  if(onlyPromo) products = products.filter(p=>promoOf(p));
  products = storeSortProducts(products, sortKey);
  const hasFilter = !!(kat || sq || onlyPromo);
  const onSale = all.filter(p=>promoOf(p)), featured = all.filter(p=>p.is_store_featured).slice(0,8);
  const owner = profiles[store.owner_id];
  const mainCat = CATBYID[store.category];
  const isMine = ME.id===store.owner_id;
  const contactBtns = [];
  if(!isMine) contactBtns.push(`<button class="btn btn-primary btn-sm" onclick="contactStore('${store.id}')">💬 Pošalji poruku</button>`);
  if(store.contact_phone) contactBtns.push(`<a class="btn btn-outline btn-sm" href="tel:${esc(store.contact_phone.replace(/[^\d+]/g,""))}">📞 ${esc(store.contact_phone)}</a>`);
  if(store.contact_email) contactBtns.push(`<a class="btn btn-outline btn-sm" href="mailto:${esc(store.contact_email)}">✉️ Email</a>`);

  return `<div class="wrap section" style="padding-top:20px;">
    <a href="#/" class="store-back">← Nazad na PazariMe</a>
    ${store.status!=="active" ? `<div class="notice warn">Ova prodavnica je ${store.status==="suspended"?"suspendovana":"neaktivna"} i nije javno vidljiva. ${isMine||isAdmin()?"Vidiš je jer si "+(isMine?"vlasnik":"administrator")+".":""}${store.status==="suspended"&&store.suspended_reason&&(isMine||isAdmin())?` Razlog: ${esc(store.suspended_reason)}`:""}</div>`:""}
    <div class="store-hero">
      <div class="store-cover">${store.cover_url?`<img src="${esc(store.cover_url)}" alt="">`:""}</div>
      <div class="store-head">
        ${storeLogoHtml(store,"lg")}
        <div style="flex:1; min-width:0;">
          <h1 style="font-size:24px;">${esc(store.name)}</h1>
          <div class="store-chips">
            ${mainCat?`<span class="chip">${mainCat.emoji} ${esc(mainCat.name)}</span>`:""}
            ${store.city?`<span class="chip">📍 ${esc(store.city)}</span>`:""}
            <span class="chip">📦 ${all.length} proizvoda</span>
            <span class="chip">👁 ${store.views_count||0} poseta</span>
            <span class="chip">Otvorena ${fmtDate(store.created_at)}</span>
          </div>
        </div>
        ${isMine?`<a class="btn btn-outline btn-sm" href="#/moja-prodavnica">⚙️ Upravljaj</a>`:""}
      </div>
      ${store.description?`<p class="store-desc">${esc(store.description)}</p>`:""}
      <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center; margin-top:14px;">
        ${contactBtns.join("")}
        ${owner?`<a href="#/prodavac/${store.owner_id}" class="btn btn-ghost btn-sm">👤 ${esc(owner.name)}</a>`:""}
      </div>
      <div style="margin-top:14px; max-width:640px;">${sellerStatusBoxHtml(sellerSt[store.owner_id])}</div>
    </div>

    ${!hasFilter && (store.welcome_title||store.welcome_text)?`<div class="store-welcome">${store.welcome_title?`<h2>${esc(store.welcome_title)}</h2>`:""}${store.welcome_text?`<p>${esc(store.welcome_text).replace(/\n/g,"<br>")}</p>`:""}</div>`:""}
    <div class="store-tabs">
      <a class="${!kat&&!onlyPromo?"active":""}" href="#/prodavnica/${esc(store.slug)}${sq?`?q=${encodeURIComponent(sq)}`:""}">Sve (${all.length})</a>
      ${onSale.length?`<a class="${onlyPromo?"active":""}" href="#/prodavnica/${esc(store.slug)}?ak=1">🏷️ Akcije (${onSale.length})</a>`:""}
      ${cats.map(c=>`<a class="${kat===c.id?"active":""}" href="#/prodavnica/${esc(store.slug)}?k=${c.id}${sq?`&q=${encodeURIComponent(sq)}`:""}">${esc(c.name)} (${all.filter(p=>p.store_category_id===c.id).length})</a>`).join("")}
    </div>
    ${!hasFilter && featured.length?`<section class="store-section"><h2>⭐ Istaknuti proizvodi</h2>${listingGrid(featured)}</section>`:""}
    ${!hasFilter && onSale.length?`<section class="store-section"><h2>🏷️ Akcije</h2>${listingGrid(storeSortProducts(onSale,"new"))}</section>`:""}
    <section class="store-section"><div class="store-bar"><h2>${onlyPromo?"Akcije":"Svi proizvodi"} <span style="font-weight:400;color:var(--ink-faint);font-size:.7em;">(${products.length})</span></h2>
      <div class="store-tools">
      <input type="text" placeholder="Traži u prodavnici..." value="${esc(params.get("q")||"")}" style="width:100%; max-width:380px; padding:10px 14px; border-radius:999px; border:1px solid var(--border); background:var(--surface); color:var(--ink);" onkeydown="if(event.key==='Enter'){const p=new URLSearchParams(location.hash.split('?')[1]||'');const v=this.value.trim();if(v)p.set('q',v);else p.delete('q');location.hash='/prodavnica/${esc(store.slug)}'+(p.toString()?'?'+p.toString():'')}">
      <select aria-label="Sortiranje" onchange="const p=new URLSearchParams(location.hash.split('?')[1]||'');if(this.value==='new')p.delete('s');else p.set('s',this.value);location.hash='/prodavnica/${esc(store.slug)}'+(p.toString()?'?'+p.toString():'')">
        ${[["new","Najnoviji"],["cheap","Cena: najniža"],["expensive","Cena: najviša"],["popular","Najpopularniji"]].map(([v,t])=>`<option value="${v}" ${sortKey===v?"selected":""}>${t}</option>`).join("")}
      </select></div></div>
    ${products.length ? listingGrid(products) : emptyState("📦", all.length?"Nema proizvoda za izabrani filter.":"Prodavnica još nema proizvoda.", all.length?"":"Svrati ponovo uskoro.")}
    </section>
  </div>`;
}
async function contactStore(storeId){
  if(!ME.id){ requireAuthRedirect("Prijavi se da bi poslao poruku prodavnici"); return; }
  const list = await fetchStoreProducts(storeId, true);
  if(!list.length){ toast("Prodavnica trenutno nema aktivnih proizvoda — pokušaj telefonom ili emailom."); return; }
  openContactSeller(list[0].id);
}

/* ---------- STORE BLOCK ON PRODUCT DETAIL ---------- */
function storeBlockHtml(s){
  if(!s) return "";
  return `<a href="#/prodavnica/${esc(s.slug)}" class="seller-card" style="margin-top:14px;">
    ${storeLogoHtml(s,"sm")}
    <div style="flex:1; min-width:0;">
      <div style="font-size:11px; color:var(--ink-faint); font-weight:600;">PRODAVNICA</div>
      <div style="font-weight:600; font-size:14px;">${esc(s.name)}</div>
      <div style="font-size:12px; color:var(--blue);">Pogledaj sve proizvode →</div>
    </div>
  </a>`;
}

/* ======================================================================
   OWNER DASHBOARD — "Moja prodavnica"
   ====================================================================== */
async function viewMyStore(tab, sub){
  if(!ME.id){
    Store.set("postLoginRedirect", "#/moja-prodavnica");
    return `<div class="wrap"><div class="auth-card"><h2>Prijava potrebna</h2><p class="sub">Prijavi se da bi otvorio prodavnicu.</p><a href="#/prijava" class="btn btn-primary btn-block">Prijavi se</a><a href="#/registracija" class="btn btn-outline btn-block" style="margin-top:8px;">Napravi nalog</a></div></div>`;
  }
  const store = await fetchMyStore();
  if(!store){
    if(ME.traderStatus==="undeclared") return declarationGateHtml("#/moja-prodavnica", "otvaranje prodavnice");
    return await viewStoreOpen();
  }

  const nav = [["pregled","Pregled","📊"],["porudzbine","Porudžbine","🧾"],["proizvodi","Proizvodi","📦"],["akcije","Akcije","🏷️"],["kategorije","Kategorije","🗂️"],["pretplata","Pretplata","💳"],["podesavanja","Podešavanja","⚙️"]];
  const newOrders = await countNewOrders();
  let body = "";
  if(tab==="porudzbine") body = await renderMyStoreOrders(store, sub);
  else if(tab==="proizvodi") body = await renderMyStoreProducts(store);
  else if(tab==="proizvod") body = await renderStoreProductForm(store, sub);
  else if(tab==="akcije") body = await renderMyStorePromos(store);
  else if(tab==="kategorije") body = await renderMyStoreCategories(store);
  else if(tab==="pretplata") body = await renderStoreSubscription(store);
  else if(tab==="podesavanja") body = renderStoreSettings(store);
  else { tab = "pregled"; body = await renderMyStoreOverview(store); }

  const navActive = tab==="proizvod" ? "proizvodi" : tab;
  return `<div class="wrap section"><div class="dash-layout">
    <nav class="dash-nav store-nav">
      ${nav.map(([id,label,icon])=>`<a href="#/moja-prodavnica/${id}" class="${navActive===id?"active":""}">${icon} ${label}${id==="porudzbine"&&newOrders>0?` <span class="order-badge">${newOrders}</span>`:""}</a>`).join("")}
      <a href="#/prodavnica/${esc(store.slug)}">🌐 Javna stranica</a>
      <a href="#/moj-pazarime" class="store-nav-back">← Moj PazariMe</a>
    </nav>
    <div>
      ${store.status==="suspended"?`<div class="notice warn">Tvoja prodavnica je suspendovana od strane administracije${store.suspended_reason?`: ${esc(store.suspended_reason)}`:"."} Proizvodi nisu javno vidljivi. Kontaktiraj podršku na podrska.pazarime@gmail.com.</div>`:""}
      ${tab!=="pretplata" ? storeSubNoticeHtml(store) : ""}
      ${(store.status==="inactive" && storeSubInfo(store).state!=="expired")?`<div class="notice warn">Prodavnica je neaktivna — nije javno vidljiva. Aktiviraj je u Podešavanjima.</div>`:""}
      ${body}
    </div>
  </div></div>`;
}

/* ---------- create store ---------- */
let sfStore = null;   // the store being edited (null while creating)
function storeImgNoun(kind){ return kind==="logo" ? "logo" : "baner"; }
function storeImgPreviewHtml(url){ return url ? `<img src="${esc(url)}" alt="">` : `<span>🖼️</span>`; }
function storeImgActionsHtml(kind, has){
  const noun = storeImgNoun(kind);
  return `<label class="btn btn-outline btn-sm" style="cursor:pointer;">${has?"Promeni":"Dodaj"} ${noun}<input type="file" accept="image/jpeg,image/png,image/webp" style="display:none" onchange="onStoreImagePick('${kind}', this)"></label>`
    + (has ? `<button type="button" class="btn btn-ghost btn-sm img-remove" onclick="removeStoreImage('${kind}')">Ukloni ${noun}</button>` : "");
}
function sfRefreshImg(kind){
  const url = storeImgState[kind];
  const prev = document.getElementById("sfPrev_"+kind); if(prev) prev.innerHTML = storeImgPreviewHtml(url);
  const act = document.getElementById("sfAct_"+kind); if(act) act.innerHTML = storeImgActionsHtml(kind, !!url);
}
function storeFormHtml(store){
  const editing = !!store;
  sfStore = store || null;
  storeImgState = { logo: store?store.logo_url:null, cover: store?store.cover_url:null };
  const imgBox = (kind, label, url)=>`<div class="form-group">
    <label>${label}</label>
    <div class="img-pick ${kind}">
      <div class="img-pick-prev" id="sfPrev_${kind}">${storeImgPreviewHtml(url)}</div>
      <div class="img-pick-actions" id="sfAct_${kind}">${storeImgActionsHtml(kind, !!url)}</div>
    </div></div>`;
  return `
    <div class="form-group"><label>Naziv prodavnice *</label>
      <input type="text" id="sfName" maxlength="60" value="${esc(store?store.name:"")}" placeholder="npr. Urban Store" ${editing?"":`oninput="sfAutoSlug()"`}></div>
    <div class="form-group"><label>Adresa prodavnice *</label>
      <div style="display:flex; align-items:center; gap:6px;"><span style="font-size:13px; color:var(--ink-faint); white-space:nowrap;">pazarime.rs/prodavnica/</span>
      <input type="text" id="sfSlug" maxlength="40" value="${esc(store?store.slug:"")}" placeholder="urban-store" ${editing?"readonly style=\"background:var(--bg);\"":`oninput="this.dataset.touched='1'"`}></div>
      <div style="font-size:11.5px; color:var(--ink-faint); margin-top:4px;">${editing?"Adresa se ne može menjati nakon otvaranja.":"Samo mala slova, brojevi i crtice (3–40 karaktera). Ne može se kasnije menjati."}</div></div>
    <div class="form-row">
      <div class="form-group"><label>Glavna kategorija *</label>
        <select id="sfCat"><option value="">Izaberi</option>${activeCategories().map(c=>`<option value="${c.id}" ${store&&store.category===c.id?"selected":""}>${c.emoji} ${c.name}</option>`).join("")}</select></div>
      <div class="form-group"><label>Grad *</label>
        <select id="sfCity"><option value="">Izaberi</option>${CITIES.map(c=>`<option ${store&&store.city===c?"selected":""}>${c}</option>`).join("")}</select></div>
    </div>
    <div class="form-group"><label>Opis</label><textarea id="sfDesc" maxlength="2000" placeholder="Reci kupcima šta prodaješ...">${esc(store?store.description||"":"")}</textarea></div>
    <h3 class="form-section-title">Izgled prodavnice</h3>
    <p class="form-hint">Logo i baner su javno vidljivi na stranici tvoje prodavnice. Ako ih ukloniš, prikazuje se podrazumevani izgled.</p>
    ${imgBox("logo","Logo",storeImgState.logo)}
    ${imgBox("cover","Baner (naslovna slika)",storeImgState.cover)}
    <div class="form-row">
      <div class="form-group"><label>Telefon za kontakt</label><input type="tel" id="sfPhone" maxlength="30" value="${esc(store?store.contact_phone||"":"")}" placeholder="+381 6x xxx xxxx"></div>
      <div class="form-group"><label>Email za kontakt</label><input type="email" id="sfEmail" maxlength="120" value="${esc(store?store.contact_email||"":"")}"></div>
    </div>
    <div class="form-group"><label>Naslov dobrodošlice</label><input type="text" id="sfWelcomeTitle" maxlength="80" value="${esc(store?store.welcome_title||"":"")}" placeholder="npr. Dobrodošli u našu prodavnicu"></div>
    <div class="form-group"><label>Uvodni tekst</label><textarea id="sfWelcome" rows="3" maxlength="1000" placeholder="Kratko predstavi prodavnicu, način isporuke, radno vreme...">${esc(store?store.welcome_text||"":"")}</textarea></div>
    <p style="font-size:12px; color:var(--ink-faint);">Telefon i email se prikazuju javno na stranici prodavnice. Ostavi prazno ako ne želiš.</p>`;
}
function sfAutoSlug(){
  const slugEl = document.getElementById("sfSlug");
  if(slugEl && !slugEl.dataset.touched) slugEl.value = slugify(document.getElementById("sfName").value);
}
async function onStoreImagePick(kind, input){
  const f = input.files && input.files[0]; if(!f) return;
  if(!/^image\/(jpeg|png|webp)$/.test(f.type)){ toast("Podržani formati: JPG, PNG, WEBP"); return; }
  if(f.size > 20*1024*1024){ toast("Slika je prevelika (maks 20MB)"); return; }
  const prev = document.getElementById("sfPrev_"+kind);
  if(prev) prev.innerHTML = `<span style="font-size:11px;">Otpremanje...</span>`;
  try{
    const blob = await compressImageToBlob(f, kind==="cover"?1800:700, 0.8);
    const path = `${ME.id}/${kind}-${crypto.randomUUID()}.jpg`;
    const { error } = await sb.storage.from("store-images").upload(path, blob, { contentType:"image/jpeg", upsert:false });
    if(error) throw error;
    const previousUnsaved = storeImgState[kind];
    storeImgState[kind] = sb.storage.from("store-images").getPublicUrl(path).data.publicUrl;
    sfRefreshImg(kind);
    // a replaced, never-saved upload is garbage: delete it (own file, not referenced by the store)
    if(previousUnsaved && previousUnsaved !== (sfStore && sfStore[kind==="logo"?"logo_url":"cover_url"])) removeOwnedStoreImages([previousUnsaved]);
  }catch(e){
    console.error(e); toast("Greška pri otpremanju slike");
    sfRefreshImg(kind);
  }
}
function readStoreForm(){
  const v = id => (document.getElementById(id)||{value:""}).value.trim();
  return { name:v("sfName"), slug:v("sfSlug").toLowerCase(), category:v("sfCat"), city:v("sfCity"), description:v("sfDesc"),
           contact_phone:v("sfPhone")||null, contact_email:v("sfEmail")||null, ...(document.getElementById("sfWelcome")?{welcome_title:v("sfWelcomeTitle")||null, welcome_text:v("sfWelcome")||null}:{}), logo_url:storeImgState.logo, cover_url:storeImgState.cover };
}
function sfShowError(msg){ const el=document.getElementById("sfError"); if(el){ el.textContent=msg; el.style.display="block"; el.scrollIntoView({block:"center"}); } else toast(msg); }
const saveStoreForm = guarded("storeSave", async (mode, storeId)=>{
  if(!ME.id){ requireAuthRedirect(); return; }
  const f = readStoreForm();
  const btn = document.getElementById("sfSaveBtn");
  if(f.name.length<2) return sfShowError("Unesi naziv prodavnice (bar 2 karaktera).");
  if(mode==="create" && !/^[a-z0-9]+(-[a-z0-9]+)*$/.test(f.slug)) return sfShowError("Adresa može sadržati samo mala slova, brojeve i crtice (npr. urban-store).");
  if(mode==="create" && (f.slug.length<3||f.slug.length>40)) return sfShowError("Adresa mora imati 3–40 karaktera.");
  if(!f.category) return sfShowError("Izaberi glavnu kategoriju.");
  if(!f.city) return sfShowError("Izaberi grad.");
  if(f.contact_email && !isValidEmail(f.contact_email)) return sfShowError("Email adresa nije ispravna.");
  if(btn){ btn.disabled=true; btn.textContent="Čuvanje..."; }
  try{
    if(mode==="create"){
      const { error } = await sb.from("stores").insert({ owner_id:ME.id, ...f, description:f.description||null });
      if(error) throw error;
      toast("Prodavnica je otvorena! 🎉");
    }else{
      const { slug, ...upd } = f;
      const prevLogo = sfStore ? sfStore.logo_url : null, prevCover = sfStore ? sfStore.cover_url : null;
      const { error } = await sb.from("stores").update({ ...upd, description:f.description||null }).eq("id", storeId);
      if(error) throw error;
      if(STORE_CACHE[storeId]) STORE_CACHE[storeId].logo_url = f.logo_url;
      toast("Izmene su sačuvane");
      // replaced images: delete the old files (only own files that nothing references anymore)
      await removeOwnedStoreImages([prevLogo!==f.logo_url?prevLogo:null, prevCover!==f.cover_url?prevCover:null]);
    }
    location.hash = "/moja-prodavnica"; route();
  }catch(e){
    console.error(e);
    let m = "Greška pri čuvanju. Pokušaj ponovo.";
    if(e.code==="42501") m = "Za otvaranje prodavnice potrebna je izjava o statusu prodavca. Otvori #/deklaracija i popuni je.";
    else if(e.code==="23505") m = String(e.message||"").includes("owner") ? "Već imaš prodavnicu." : "Ta adresa je već zauzeta — izaberi drugu.";
    else if(e.code==="23514") m = "Neka od unetih vrednosti nije ispravna (proveri dužinu naziva i adrese).";
    else if(e.message && /dozvol|suspend|Samo/i.test(e.message)) m = e.message;
    sfShowError(m);
    if(btn){ btn.disabled=false; btn.textContent = mode==="create"?"Otvori prodavnicu":"Sačuvaj izmene"; }
  }
});

/* ---------- overview ---------- */
async function renderMyStoreOverview(store){
  const products = await fetchStoreProducts(store.id, false);
  const active = products.filter(p=>p.status==="active").length;
  const pViews = products.reduce((s,p)=>s+(p.views_count||0),0);
  const pFavs = products.reduce((s,p)=>s+(p.favorites_count||0),0);
  const top = [...products].sort((a,b)=>(b.views_count||0)-(a.views_count||0)).slice(0,3);
  const newOrdersCount = await countNewOrders();
  return `
    ${newOrdersCount>0?`<a href="#/moja-prodavnica/porudzbine/nova" class="notice" style="display:block;">🧾 Imaš <b>${newOrdersCount}</b> ${newOrdersCount===1?"novu porudžbinu":"novih porudžbina"} — pogledaj →</a>`:""}
    <div style="display:flex; gap:14px; align-items:center; margin-bottom:20px; flex-wrap:wrap;">
      ${storeLogoHtml(store,"md")}
      <div style="flex:1; min-width:0;"><h2 style="font-size:20px;">${esc(store.name)}</h2>
        <div style="margin-top:4px;"><span class="status-pill ${storeStatusClass(store.status)}">${storeStatusLabel(store.status)}</span>
        <span style="font-size:12px; color:var(--ink-faint); margin-left:8px;">pazarime.rs/prodavnica/${esc(store.slug)}</span></div></div>
      <a class="btn btn-primary btn-sm" href="#/moja-prodavnica/proizvod/novi">+ Dodaj proizvod</a>
    </div>
    <div class="stat-grid">
      <div class="stat-card"><div class="n">${store.views_count||0}</div><div class="l">Poseta prodavnice</div></div>
      <div class="stat-card"><div class="n">${pViews}</div><div class="l">Pregleda proizvoda</div></div>
      <div class="stat-card"><div class="n">${active}<span style="font-size:14px; color:var(--ink-faint);"> / ${products.length}</span></div><div class="l">Aktivnih proizvoda</div></div>
      <div class="stat-card"><div class="n">${pFavs}</div><div class="l">Puta sačuvano</div></div>
    </div>
    ${products.length ? `<h3 style="font-size:15px; margin-bottom:10px;">Najgledaniji proizvodi</h3>${top.map(storeProductRow).join("")}`
      : emptyState("📦","Još nemaš proizvoda.","Dodaj prvi proizvod — traje manje od minuta.", `<a href="#/moja-prodavnica/proizvod/novi" class="btn btn-primary" style="margin-top:14px;">+ Dodaj proizvod</a>`)}
    `;
}

/* ---------- products list ---------- */
function storeProductRow(l){
  const unavailable = productUnavailable(l);
  return `<div class="list-row sp-row">
    <div class="thumb-sm">${l.images&&l.images.length?`<img src="${esc(l.images[Math.min(l.cover_index||0,l.images.length-1)])}" style="width:100%;height:100%;object-fit:cover;border-radius:9px;">`:"📦"}</div>
    <div class="info">
      <div class="t">${esc(l.title)}</div>
      <div class="stats" style="flex-wrap:wrap; gap:8px;">
        <span>${fmtPrice(l.price,l.currency)}</span>
        ${l.stock!=null?`<span>Zaliha: ${l.stock}</span>`:""}
        <span>👁 ${l.views_count||0}</span><span>♡ ${l.favorites_count||0}</span>
        <span class="status-pill ${statusClass(l.status)}">${statusLabel(l.status)}</span>
        ${unavailable?`<span class="status-pill status-sold">Nedostupno</span>`:""}
      </div>
    </div>
    <div class="sp-actions">
      <div class="sp-price"><input type="number" min="0" inputmode="numeric" id="qp-${l.id}" value="${l.price}"><button class="btn btn-outline btn-sm" onclick="spQuickPrice('${l.id}')">Cena</button></div>
      <a href="#/moja-prodavnica/proizvod/${l.id}" class="btn btn-outline btn-sm">Uredi</a>
      <button class="btn btn-ghost btn-sm" onclick="spToggleAvail('${l.id}',${l.available===false})">${l.available===false?"Označi dostupnim":"Nedostupno"}</button>
      ${l.status==="active"||l.status==="paused"?`<button class="btn btn-ghost btn-sm" onclick="spToggleStatus('${l.id}','${l.status}')">${l.status==="paused"?"Objavi":"Pauziraj"}</button>`:""}
      <button class="btn btn-danger btn-sm" onclick="spDelete('${l.id}')">Obriši</button>
    </div>
  </div>`;
}
// ================= Akcije (store promotions) =================
let promoEdit = null;
function promoLocalInput(d){ const z = new Date(d.getTime()-d.getTimezoneOffset()*60000); return z.toISOString().slice(0,16); }
async function renderMyStorePromos(store){
  const [pr, ls] = await Promise.all([
    sb.from("store_promotions").select("*").eq("store_id", store.id).order("starts_at",{ascending:false}),
    sb.from("listings").select("id,title,price,currency,images").eq("store_id", store.id).order("title")]);
  if(pr.error || ls.error){
    const er = pr.error || ls.error, code = er.code || "";
    // Only blame a missing migration when the error really says the table/column is missing; other errors (RLS, permissions, network) are shown as-is.
    const hint = pr.error ? ((code==="PGRST205"||code==="42P01") ? " (proveri da li je migracija 20261016 primenjena)" : "")
                          : ((code==="42703"||code==="PGRST204") ? " (proveri da li je migracija 20261015 primenjena)" : "");
    console.error("[PazariMe] Akcije:", er);
    return `<div class="notice warn">Akcije trenutno nisu dostupne${hint}.<br><small>Detalj: ${esc((er.message||"nepoznata greška")+(code?" ["+code+"]":""))}</small></div>`;
  }
  const promos = pr.data||[], prods = ls.data||[], byId = Object.fromEntries(prods.map(p=>[p.id,p]));
  const e = promoEdit && promos.find(x=>x.id===promoEdit) || null, el = e ? byId[e.listing_id] : null;
  const now = new Date(), st = e ? new Date(e.starts_at) : now, en = e ? new Date(e.ends_at) : new Date(now.getTime()+7*864e5);
  const row = p => { const l = byId[p.listing_id]; const state = promoState(p); if(!l) return "";
    const lbl = {active:"Aktivna",scheduled:"Zakazana",expired:"Istekla"}[state], cls = {active:"status-active",scheduled:"status-pending",expired:"status-sold"}[state];
    return `<div class="list-row"><div class="info"><div class="t">${esc(l.title)}</div><div class="stats"><span><s class="promo-old">${fmtPrice(l.price,l.currency)}</s> → <b>${fmtPrice(discountedPrice(l.price,p.percent),l.currency)}</b> (-${p.percent}%)</span>
      <span>${fmtDateTime(p.starts_at)} – ${fmtDateTime(p.ends_at)}</span><span class="status-pill ${cls}">${lbl}</span></div></div>
      ${state!=="expired"?`<button class="btn btn-outline btn-sm" onclick="promoEdit='${p.id}'; route();">Uredi</button>`:""}<button class="btn btn-outline btn-sm" onclick="spPromoDelete('${p.id}')">Ukloni</button></div>`; };
  const grp = (state,title) => { const a = promos.filter(p=>promoState(p)===state); return `<h3 style="font-size:14px;margin:18px 0 8px;">${title} (${a.length})</h3>${a.length?a.map(row).join(""):`<p style="font-size:13px;color:var(--ink-faint);">Nema akcija.</p>`}`; };
  return `<h2 style="margin-bottom:6px;">Akcije i popusti</h2>
  <p style="font-size:13px;color:var(--ink-dim);margin-bottom:14px;">Akcijska cena se računa iz trenutne cene proizvoda i važi samo u izabranom periodu. Posle isteka automatski se vraća redovna cena.</p>
  ${prods.length?`<div class="card-box" style="padding:16px;margin-bottom:10px;"><div id="prError" class="notice warn" style="display:none;"></div>
    <div class="form-group"><label>Proizvod *</label><select id="prListing" onchange="spPromoCalc('pct')" ${e?"disabled":""}>${prods.map(p=>`<option value="${p.id}" data-price="${p.price}" data-cur="${p.currency||"EUR"}" ${e&&e.listing_id===p.id?"selected":""}>${esc(p.title)} — ${fmtPrice(p.price,p.currency)}</option>`).join("")}</select></div>
    <div class="form-row"><div class="form-group"><label>Popust (%) *</label><input type="number" id="prPct" min="1" max="90" step="1" inputmode="numeric" value="${e?e.percent:""}" oninput="spPromoCalc('pct')"></div>
    <div class="form-group"><label>Akcijska cena</label><input type="number" id="prNew" min="0" step="1" inputmode="numeric" value="${el?discountedPrice(el.price,e.percent):""}" oninput="spPromoCalc('new')"></div></div>
    <div id="prPreview" style="font-size:13px;margin:-4px 0 10px;color:var(--ink-dim);">${el?`Redovna cena <s>${fmtPrice(el.price,el.currency)}</s> → akcijska <b>${fmtPrice(discountedPrice(el.price,e.percent),el.currency)}</b> (-${e.percent}%)`:"Unesi popust od 1% do 90%."}</div>
    <div class="form-row"><div class="form-group"><label>Početak *</label><input type="datetime-local" id="prStart" value="${promoLocalInput(st)}"></div>
    <div class="form-group"><label>Kraj *</label><input type="datetime-local" id="prEnd" value="${promoLocalInput(en)}"></div></div>
    <button class="btn btn-primary" id="prSave" onclick="spPromoSave()">${e?"Sačuvaj izmene":"Dodaj akciju"}</button>
    ${e?` <button class="btn btn-outline" onclick="promoEdit=null; route();">Otkaži</button>`:""}</div>`
  :emptyState("📦","Nemaš proizvoda.","Prvo dodaj proizvod, pa mu postavi akciju.")}
  ${grp("active","Aktivne")}${grp("scheduled","Zakazane")}${grp("expired","Istekle")}`;
}
function spPromoCalc(from){
  const sel = document.getElementById("prListing"); if(!sel || !sel.selectedOptions[0]) return;
  const price = Number(sel.selectedOptions[0].dataset.price), cur = sel.selectedOptions[0].dataset.cur;
  const pctEl = document.getElementById("prPct"), newEl = document.getElementById("prNew"), out = document.getElementById("prPreview");
  if(from==="new" && newEl.value!==""){ const np = Number(newEl.value); pctEl.value = (price>0 && np>=0 && np<price) ? Math.round(100 - 100*np/price) : ""; }
  const pct = parseInt(pctEl.value);
  if(pct>=1 && pct<=90){ const dp = discountedPrice(price, pct); if(from!=="new") newEl.value = dp; out.innerHTML = `Redovna cena <s>${fmtPrice(price,cur)}</s> → akcijska <b>${fmtPrice(dp,cur)}</b> (-${pct}%)`; }
  else out.textContent = "Unesi popust od 1% do 90%.";
}
async function spPromoSave(){
  const err = m => { const x = document.getElementById("prError"); x.textContent = m; x.style.display = "block"; };
  const listing = document.getElementById("prListing").value, pct = parseInt(document.getElementById("prPct").value);
  const sv = document.getElementById("prStart").value, ev = document.getElementById("prEnd").value;
  if(!(pct>=1 && pct<=90)) return err("Popust mora biti između 1% i 90%.");
  if(!sv || !ev) return err("Unesi početak i kraj akcije.");
  const s = new Date(sv), en = new Date(ev);
  if(en <= s) return err("Kraj akcije mora biti posle početka.");
  if(en <= new Date()) return err("Kraj akcije mora biti u budućnosti.");
  const btn = document.getElementById("prSave"); btn.disabled = true;
  const { error } = await sb.rpc("save_store_promotion", { p_id: promoEdit, p_listing_id: listing, p_percent: pct, p_starts: s.toISOString(), p_ends: en.toISOString() });
  if(error){ btn.disabled = false; return err(error.message || "Greška pri čuvanju akcije."); }
  promoEdit = null; await loadPromos(true); toast("Akcija je sačuvana."); route();
}
async function spPromoDelete(id){
  if(!confirm("Ukloniti ovu akciju? Proizvod se vraća na redovnu cenu.")) return;
  const { error } = await sb.rpc("delete_store_promotion", { p_id: id });
  if(error) return toast(error.message || "Greška pri uklanjanju.");
  await loadPromos(true); toast("Akcija je uklonjena."); route();
}
async function renderMyStoreProducts(store){
  const products = await fetchStoreProducts(store.id, false);
  return `<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; gap:10px; flex-wrap:wrap;">
      <h2 style="font-size:20px;">Proizvodi (${products.length})</h2>
      <a class="btn btn-primary btn-sm" href="#/moja-prodavnica/proizvod/novi">+ Dodaj proizvod</a></div>
    ${products.length ? products.map(storeProductRow).join("") : emptyState("📦","Još nemaš proizvoda.","Dodaj prvi proizvod u svoju prodavnicu.", `<a href="#/moja-prodavnica/proizvod/novi" class="btn btn-primary" style="margin-top:14px;">+ Dodaj proizvod</a>`)}`;
}
const spQuickPrice = guarded("spPrice", async (id)=>{
  const el = document.getElementById("qp-"+id); const price = parseInt(el&&el.value);
  if(!(price>=0)){ toast("Unesi ispravnu cenu"); return; }
  try{ const { error } = await sb.from("listings").update({ price }).eq("id", id); if(error) throw error; toast("Cena je ažurirana"); route(); }
  catch(e){ toast("Greška pri promeni cene"); }
});
async function spToggleAvail(id, currentlyUnavailable){
  try{ const { error } = await sb.from("listings").update({ available: !!currentlyUnavailable }).eq("id", id); if(error) throw error; toast(currentlyUnavailable?"Proizvod je dostupan":"Proizvod je označen kao nedostupan"); route(); }
  catch(e){ toast("Greška"); }
}
async function spToggleStatus(id, current){
  const next = current==="paused" ? "active" : "paused";
  try{ const { error } = await sb.from("listings").update({ status: next }).eq("id", id); if(error) throw error; toast(next==="active"?"Proizvod je objavljen":"Proizvod je pauziran"); route(); }
  catch(e){ toast(e.message && /aktivna/i.test(e.message) ? e.message : "Greška"); }
}
async function spDelete(id){
  if(!confirm("Obrisati proizvod? Ova radnja se ne može poništiti.")) return;
  try{ const { error } = await sb.from("listings").delete().eq("id", id); if(error) throw error; toast("Proizvod je obrisan"); route(); }
  catch(e){ toast("Greška pri brisanju"); }
}

/* ---------- product form (create / edit) ---------- */
async function renderStoreProductForm(store, id){
  const cats = await fetchStoreCategories(store.id);
  let l = null;
  if(id && id!=="novi"){
    l = await fetchListing(id);
    if(!l || l.store_id!==store.id) return emptyState("🔎","Proizvod nije pronađen","", `<a href="#/moja-prodavnica/proizvodi" class="btn btn-primary" style="margin-top:14px;">Nazad</a>`);
  }
  const images = l ? (l.images||[]) : [];
  pform = { id: l?l.id:null, draftId: l?l.id:crypto.randomUUID(), photos: images.map(u=>({url:u, path:null})), cover: l?(l.cover_index||0):0, uploading:false, storeId: store.id, originalUrls: images.slice() };
  const canPublish = store.status==="active";
  const status = l ? l.status : (canPublish?"active":"paused");
  return `<h2 style="font-size:20px; margin-bottom:16px;">${l?"Uredi proizvod":"Novi proizvod"}</h2>
    <div class="wizard-card" style="max-width:640px;">
      <div id="pfError" class="notice err" style="display:none;"></div>
      ${pformPhotosBlockHtml()}
      <div class="form-group"><label>Naziv proizvoda *</label><input type="text" id="pfTitle" maxlength="120" value="${esc(l?l.title:"")}" placeholder="npr. Kožni novčanik"></div>
      <div class="form-row">
        <div class="form-row"><div class="form-group"><label>Cena *</label><input type="number" min="0" inputmode="numeric" id="pfPrice" value="${l?l.price:""}"></div><div class="form-group"><label>Valuta *</label><select id="pfCurrency"><option value="EUR" ${(l&&l.currency!=="RSD")?"selected":""}>€ EUR</option><option value="RSD" ${(!l||l.currency==="RSD")?"selected":""}>RSD (dinari)</option></select></div></div><div style="font-size:12px;color:var(--ink-faint);margin:-6px 0 12px;">Iznos se NE preračunava automatski: unesi cenu u izabranoj valuti.</div>
    <label style="display:flex;gap:8px;align-items:center;margin:0 0 12px;font-size:14px;"><input type="checkbox" id="pfFeatured" ${l&&l.is_store_featured?"checked":""}> ⭐ Istakni na početnoj stranici prodavnice</label>
        <div class="form-group"><label>Zaliha (opciono)</label><input type="number" min="0" inputmode="numeric" id="pfStock" value="${l&&l.stock!=null?l.stock:""}" placeholder="npr. 10"></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Kategorija na PazariMe *</label>
          <select id="pfCat">${activeCategories().map(c=>`<option value="${c.id}" ${(l?l.category:store.category)===c.id?"selected":""}>${c.emoji} ${c.name}</option>`).join("")}</select></div>
        <div class="form-group"><label>Sekcija u prodavnici</label>
          <select id="pfStoreCat"><option value="">— bez sekcije —</option>${cats.map(c=>`<option value="${c.id}" ${l&&l.store_category_id===c.id?"selected":""}>${esc(c.name)}</option>`).join("")}</select>
          ${cats.length?"":`<div style="font-size:11.5px; color:var(--ink-faint); margin-top:4px;">Sekcije dodaješ u tabu „Kategorije“.</div>`}</div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Stanje</label><select id="pfCond">${CONDITIONS.map(c=>`<option ${(l?l.condition:"Novo")===c?"selected":""}>${c}</option>`).join("")}</select></div>
        <div class="form-group"><label>Dostava</label><select id="pfDelivery">${["Lično preuzimanje","Kurirska služba","Obe opcije"].map(o=>`<option ${(l?l.delivery:"Obe opcije")===o?"selected":""}>${o}</option>`).join("")}</select></div>
      </div>
      <div class="form-group"><label>Opis</label><textarea id="pfDesc" placeholder="Materijal, dimenzije, veličine, boje...">${esc(l?l.description||"":"")}</textarea></div>
      <div class="form-row">
        <div class="form-group"><label>Status</label>
          <select id="pfStatus"><option value="active" ${status==="active"?"selected":""} ${canPublish?"":"disabled"}>Objavljen</option><option value="paused" ${status==="paused"?"selected":""}>Pauziran (skriven)</option>${status!=="active"&&status!=="paused"?`<option value="${esc(status)}" selected disabled>${esc(statusLabel(status))} (ne može se menjati)</option>`:""}</select>
          ${status==="removed"?`<div style="font-size:11.5px; color:var(--danger); margin-top:4px;">Ovaj proizvod je uklonjen od strane administracije.</div>`:""}</div>
        <div class="form-group"><label>Dostupnost</label>
          <select id="pfAvail"><option value="1" ${!l||l.available!==false?"selected":""}>Dostupno</option><option value="0" ${l&&l.available===false?"selected":""}>Nedostupno</option></select></div>
      </div>
      <div class="wizard-actions"><a href="#/moja-prodavnica/proizvodi" class="btn btn-outline">Otkaži</a>
        <button id="pfSaveBtn" class="btn btn-primary" onclick="saveStoreProduct()">${l?"Sačuvaj izmene":"Dodaj proizvod"}</button></div>
    </div>`;
}
function pformPhotosHtml(){
  if(!pform) return "";
  const slots = pform.photos.map((p,i)=>photoSlotHtml(p.url,i,i===pform.cover,"pformCover","pformMove","pformRemove","pformPreview")).join("");
  const add = pform.photos.length<10 ? `<label class="upload-slot" style="cursor:pointer; font-size:24px;">+<input type="file" accept="image/jpeg,image/png,image/webp" multiple style="display:none" onchange="handlePformFiles(this)"></label>` : "";
  return slots+add;
}
function pformRefresh(){ const g=document.getElementById("pfPhotos"); if(g) g.innerHTML = pformPhotosHtml(); }
function pformCover(i){ pform.cover=i; pformRefresh(); }
function pformMove(i,dir){
  const j=i+dir; if(j<0||j>=pform.photos.length) return;
  [pform.photos[i],pform.photos[j]]=[pform.photos[j],pform.photos[i]];
  if(pform.cover===i) pform.cover=j; else if(pform.cover===j) pform.cover=i;
  pformRefresh();
}
async function pformRemove(i){
  const p = pform.photos[i]; pform.photos.splice(i,1);
  if(pform.cover>=pform.photos.length) pform.cover=0;
  pformRefresh();
  if(p && p.path){ try{ await sb.storage.from("listing-images").remove([p.path]); }catch(e){} }
}
async function handlePformFiles(input){
  const room = 10 - pform.photos.length;
  if(room<=0){ toast("Maksimalno 10 fotografija"); return; }
  const files = Array.from(input.files||[]).slice(0, room);
  input.value = "";
  const st = document.getElementById("pfUploading");
  for(let n=0;n<files.length;n++){
    const f = files[n];
    if(!/^image\/(jpeg|png|webp)$/.test(f.type)){ toast("Podržani formati: JPG, PNG, WEBP"); continue; }
    if(f.size > 20*1024*1024){ toast("Fotografija je prevelika (maks 20MB)"); continue; }
    if(st) st.textContent = `Otpremanje ${n+1}/${files.length}...`;
    try{
      const blob = await compressImageToBlob(f);
      const path = `${ME.id}/${pform.draftId}/${crypto.randomUUID()}.jpg`;
      const { error } = await sb.storage.from("listing-images").upload(path, blob, { contentType:"image/jpeg", upsert:false });
      if(error) throw error;
      pform.photos.push({ url: sb.storage.from("listing-images").getPublicUrl(path).data.publicUrl, path });
      pformRefresh();
    }catch(e){ console.error(e); toast("Greška pri otpremanju fotografije"); }
  }
  if(st) st.textContent = "";
}
function pfShowError(msg){ const el=document.getElementById("pfError"); if(el){ el.textContent=msg; el.style.display="block"; el.scrollIntoView({block:"center"}); } else toast(msg); }
const saveStoreProduct = guarded("spSave", async ()=>{
  if(!ME.id || !pform){ return; }
  const v = id => document.getElementById(id).value.trim();
  const title = v("pfTitle"), price = parseInt(v("pfPrice"));
  const stockRaw = v("pfStock"); const stock = stockRaw==="" ? null : parseInt(stockRaw);
  if(title.length<2) return pfShowError("Unesi naziv proizvoda.");
  if(!(price>=0) || v("pfPrice")==="") return pfShowError("Unesi ispravnu cenu.");
  if(stock!==null && !(stock>=0)) return pfShowError("Zaliha mora biti 0 ili veći broj.");
  if(!pform.photos.length) return pfShowError("Dodaj bar jednu fotografiju.");
  if(pform.uploading) return;
  const btn = document.getElementById("pfSaveBtn"); if(btn){ btn.disabled=true; btn.textContent="Čuvanje..."; }
  const store = await fetchMyStore();
  if(!store){ pfShowError("Prodavnica nije pronađena."); if(btn){ btn.disabled=false; } return; }
  const fields = {
    title, price, currency: (v("pfCurrency")==="RSD"?"RSD":"EUR"), is_store_featured: !!document.getElementById("pfFeatured").checked, stock, category: v("pfCat"), condition: v("pfCond"), delivery: v("pfDelivery"),
    description: v("pfDesc"), status: v("pfStatus"), available: v("pfAvail")==="1",
    store_category_id: v("pfStoreCat") || null,
    images: pform.photos.map(p=>p.url), cover_index: pform.cover||0,
  };
  try{
    if(pform.id){
      const { error } = await sb.from("listings").update(fields).eq("id", pform.id);
      if(error) throw error;
    }else{
      const base = slugify(title) || "proizvod";
      let lastErr = null;
      for(let attempt=0; attempt<4; attempt++){
        const slug = attempt===0 ? base : `${base}-${Math.random().toString(36).slice(2,6)}`;
        const { error } = await sb.from("listings").insert({
          id: pform.draftId, seller_id: ME.id, store_id: store.id, slug,
          brand: "", exchange: false, city: store.city || "Beograd", ...fields
        });
        if(!error){ lastErr=null; break; }
        lastErr = error;
        if(!(error.code==="23505" && /slug/i.test(error.message||""))) break;
      }
      if(lastErr) throw lastErr;
    }
    toast(pform.id?"Proizvod je ažuriran":"Proizvod je dodat");
    if(pform.id){   // photos removed from a saved product: delete their files now that the DB no longer references them
      const keep = new Set(fields.images);
      await removeOwnedListingImages((pform.originalUrls||[]).filter(u=>!keep.has(u)), pform.draftId);
    }
    pform = null;
    location.hash = "/moja-prodavnica/proizvodi";
  }catch(e){
    console.error(e);
    pfShowError(e.message && /Prodavnica|dozvol|uklonjen/i.test(e.message) ? e.message : (e.code==="42501" ? "Nemaš dozvolu za ovu radnju (potrebna je izjava o statusu prodavca)." : "Greška pri čuvanju proizvoda. Pokušaj ponovo."));
    if(btn){ btn.disabled=false; btn.textContent = pform&&pform.id?"Sačuvaj izmene":"Dodaj proizvod"; }
  }
});

/* ---------- store categories (sections) ---------- */
async function renderMyStoreCategories(store){
  const cats = await fetchStoreCategories(store.id);
  const products = await fetchStoreProducts(store.id, false);
  return `<h2 style="font-size:20px; margin-bottom:6px;">Kategorije prodavnice</h2>
    <p style="font-size:13px; color:var(--ink-dim); margin-bottom:16px;">Sekcije koje kupci vide na stranici tvoje prodavnice (npr. „Majice“, „Patike“).</p>
    <div style="display:flex; gap:8px; margin-bottom:16px; max-width:420px;">
      <input type="text" id="newStoreCat" maxlength="40" placeholder="Naziv nove kategorije" style="flex:1; padding:10px 13px; border-radius:10px; border:1px solid var(--border); background:var(--surface); color:var(--ink);" onkeydown="if(event.key==='Enter')addStoreCategory('${store.id}')">
      <button class="btn btn-primary btn-sm" onclick="addStoreCategory('${store.id}')">Dodaj</button></div>
    ${cats.length ? cats.map(c=>`<div class="list-row"><div class="info"><div class="t">${esc(c.name)}</div><div class="stats">${products.filter(p=>p.store_category_id===c.id).length} proizvoda</div></div>
      <div style="display:flex; gap:6px;"><button class="btn btn-outline btn-sm" onclick="renameStoreCategory('${c.id}')">Preimenuj</button><button class="btn btn-danger btn-sm" onclick="deleteStoreCategory('${c.id}')">Obriši</button></div></div>`).join("")
      : emptyState("🗂️","Nemaš kategorija.","Dodaj prvu kategoriju da organizuješ proizvode.")}`;
}
const addStoreCategory = guarded("scAdd", async (storeId)=>{
  const name = document.getElementById("newStoreCat").value.trim();
  if(!name){ toast("Unesi naziv kategorije"); return; }
  try{
    const { error } = await sb.from("store_categories").insert({ store_id: storeId, name, sort_order: Date.now()%100000000 });
    if(error) throw error; toast("Kategorija je dodata"); route();
  }catch(e){ toast(e.code==="23505"?"Kategorija sa tim nazivom već postoji":"Greška pri dodavanju"); }
});
async function renameStoreCategory(id){
  const name = (prompt("Novi naziv kategorije:")||"").trim(); if(!name) return;
  try{ const { error } = await sb.from("store_categories").update({ name }).eq("id", id); if(error) throw error; toast("Kategorija je preimenovana"); route(); }
  catch(e){ toast(e.code==="23505"?"Kategorija sa tim nazivom već postoji":"Greška"); }
}
async function deleteStoreCategory(id){
  if(!confirm("Obrisati kategoriju? Proizvodi ostaju u prodavnici, samo bez sekcije.")) return;
  try{ const { error } = await sb.from("store_categories").delete().eq("id", id); if(error) throw error; toast("Kategorija je obrisana"); route(); }
  catch(e){ toast("Greška pri brisanju"); }
}

/* ---------- settings ---------- */
function renderStoreSettings(store){
  const locked = store.status==="suspended";
  const subExpired = storeSubInfo(store).state==="expired";
  return `<h2 style="font-size:20px; margin-bottom:16px;">Podešavanja prodavnice</h2>
    <div class="wizard-card" style="max-width:640px;">
      <div id="sfError" class="notice err" style="display:none;"></div>
      ${storeFormHtml(store)}
      <div class="wizard-actions"><span></span><button id="sfSaveBtn" class="btn btn-primary" onclick="saveStoreForm('update','${store.id}')">Sačuvaj izmene</button></div>
    </div>
    <div class="wizard-card" style="max-width:640px; margin-top:16px;">
      <h3 style="font-size:15px; margin-bottom:6px;">Vidljivost</h3>
      <p style="font-size:13px; color:var(--ink-dim); margin-bottom:12px;">Neaktivna prodavnica i svi njeni proizvodi su sakriveni od kupaca. Kada je ponovo aktiviraš, proizvodi koji su bili javni vraćaju se automatski.</p>
      ${locked ? `<p style="font-size:13px; color:var(--warn);">Prodavnica je suspendovana — status može da promeni samo administrator.</p>`
        : store.status==="active" ? `<button class="btn btn-outline" onclick="setMyStoreStatus('${store.id}','inactive')">Deaktiviraj prodavnicu</button>`
        : subExpired ? `<p style="font-size:13px; color:var(--warn); margin-bottom:10px;">Pretplata je istekla — prodavnica ne može da bude javno vidljiva dok je ne obnoviš.</p><a class="btn btn-primary" href="#/moja-prodavnica/pretplata">Obnovi pretplatu</a>`
        : `<button class="btn btn-primary" onclick="setMyStoreStatus('${store.id}','active')">Aktiviraj prodavnicu</button>`}
    </div>
    <div class="wizard-card" style="max-width:640px; margin-top:16px; border-color:#f3c7c7;">
      <h3 style="font-size:15px; margin-bottom:6px; color:var(--danger);">Brisanje prodavnice</h3>
      <p style="font-size:13px; color:var(--ink-dim); margin-bottom:12px;">Trajno briše prodavnicu, njene kategorije i sve njene proizvode. Ovo se ne može poništiti.</p>
      <button class="btn btn-danger" onclick="deleteMyStore('${store.id}')">Obriši prodavnicu</button>
    </div>`;
}
async function setMyStoreStatus(id, status){
  try{ const { error } = await sb.from("stores").update({ status }).eq("id", id); if(error) throw error; toast(status==="active"?"Prodavnica je aktivna":"Prodavnica je deaktivirana"); route(); }
  catch(e){ toast(e.message && /suspend|pretplat/i.test(e.message) ? e.message : "Greška"); }
}
async function deleteMyStore(id){
  if(!confirm("Trajno obrisati prodavnicu i SVE njene proizvode?")) return;
  if(!confirm("Poslednje upozorenje: ovo se ne može poništiti. Nastaviti?")) return;
  try{ const { error } = await sb.from("stores").delete().eq("id", id); if(error) throw error; toast("Prodavnica je obrisana"); location.hash="/moj-pazarime"; }
  catch(e){ toast(e && e.message && /porudžbine/i.test(e.message) ? e.message : "Greška pri brisanju"); }
}

/* ======================================================================
   ADMIN — stores
   ====================================================================== */
async function renderAdminStores(subId, params){
  if(subId) return renderAdminStoreDetail(subId);
  const q = (params.get("q")||"").trim().toLowerCase();
  const status = params.get("status")||"";
  let query = sb.from("stores").select("*").order("created_at",{ascending:false}).limit(300);
  if(status) query = query.eq("status", status);
  const [{ data }, users, { data: prodRows }] = await Promise.all([
    query, fetchAdminUsers(null),
    sb.from("listings").select("store_id,status").not("store_id","is",null).limit(5000),
  ]);
  const userMap = Object.fromEntries((users||[]).map(u=>[u.id,u]));
  const tot = {}, act = {};
  (prodRows||[]).forEach(r=>{ tot[r.store_id]=(tot[r.store_id]||0)+1; if(r.status==="active") act[r.store_id]=(act[r.store_id]||0)+1; });
  let stores = data||[];
  if(q) stores = stores.filter(s=>(s.name||"").toLowerCase().includes(q) || s.slug.includes(q) || ((userMap[s.owner_id]&&userMap[s.owner_id].email)||"").toLowerCase().includes(q));
  return `
  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:10px;">
    <h2 style="font-size:20px;">Prodavnice (${stores.length})</h2>
    <div style="display:flex; gap:8px; flex-wrap:wrap;">
      <input type="text" placeholder="Naziv, adresa ili email vlasnika..." value="${esc(params.get("q")||"")}" style="padding:9px 14px;border-radius:8px;border:1px solid var(--border);min-width:230px;" onkeydown="if(event.key==='Enter')location.hash='/admin/stores?'+mkFilter('q',this.value.trim())">
      <select onchange="location.hash='/admin/stores?'+mkFilter('status',this.value)">
        <option value="">Svi statusi</option>${["active","inactive","suspended"].map(s=>`<option value="${s}" ${status===s?"selected":""}>${storeStatusLabel(s)}</option>`).join("")}
      </select></div>
  </div>
  ${stores.length ? `<div class="overflow-x"><table class="admin-table"><thead><tr><th>Prodavnica</th><th>Vlasnik</th><th>Proizvodi (aktivni/ukupno)</th><th>Posete</th><th>Status</th><th>Pretplata</th><th>Otvorena</th><th>Akcije</th></tr></thead><tbody>
  ${stores.map(s=>{ const o = userMap[s.owner_id]; return `<tr>
    <td><a href="#/admin/stores/${s.id}" style="font-weight:600;">${esc(s.name)}</a><div style="font-size:11px;color:var(--ink-faint);">/${esc(s.slug)}</div></td>
    <td>${o?`<a href="#/admin/users/${o.id}">${esc(o.display_name||o.email)}</a><div style="font-size:11px;color:var(--ink-faint);">${esc(o.email)}${o.trader_status?` · ${esc(sellerStatusLabel(o.trader_status))}`:""}</div>`:"—"}</td>
    <td>${act[s.id]||0} / ${tot[s.id]||0}</td><td>${s.views_count||0}</td>
    <td><span class="status-pill ${storeStatusClass(s.status)}">${storeStatusLabel(s.status)}</span></td>
    <td>${storeSubPill(s)}${(!s.grandfathered && s.paid_until)?`<div style="font-size:11px;color:var(--ink-faint);">do ${fmtDate(s.paid_until)}</div>`:""}</td>
    <td>${fmtDate(s.created_at)}</td>
    <td style="white-space:nowrap;"><a href="#/admin/stores/${s.id}" class="btn btn-outline btn-sm">Detalji</a>
      ${s.status==="suspended"?`<button class="btn btn-outline btn-sm" onclick="adminStoreStatus('${s.id}','active')">Reaktiviraj</button>`:`<button class="btn btn-danger btn-sm" onclick="adminStoreStatus('${s.id}','suspended')">Suspenduj</button>`}</td>
  </tr>`; }).join("")}
  </tbody></table></div>` : emptyState("🏪","Nema prodavnica za prikaz.","")}`;
}
async function renderAdminStoreDetail(id){
  const store = await fetchStoreById(id);
  if(!store) return emptyState("🏪","Prodavnica nije pronađena","");
  const [products, users] = await Promise.all([fetchStoreProducts(id,false), fetchAdminUsers(store.owner_id)]);
  const owner = (users||[]).find(u=>u.id===store.owner_id);
  const cat = CATBYID[store.category];
  return `
  <a href="#/admin/stores" style="font-size:12.5px; color:var(--ink-faint);">← Nazad na prodavnice</a>
  <div style="display:flex; gap:16px; align-items:center; margin:16px 0 20px; flex-wrap:wrap;">
    ${storeLogoHtml(store,"lg")}
    <div style="flex:1; min-width:200px;">
      <h2 style="font-size:20px;">${esc(store.name)}</h2>
      <div style="font-size:13px; color:var(--ink-faint); margin-top:4px;">/prodavnica/${esc(store.slug)} · otvorena ${fmtDate(store.created_at)}</div>
      <div style="display:flex; gap:8px; margin-top:8px; flex-wrap:wrap;"><span class="status-pill ${storeStatusClass(store.status)}">${storeStatusLabel(store.status)}</span>
        ${cat?`<span class="chip">${cat.emoji} ${esc(cat.name)}</span>`:""}${store.city?`<span class="chip">📍 ${esc(store.city)}</span>`:""}<span class="chip">👁 ${store.views_count||0}</span></div>
    </div>
  </div>
  <table class="spec-table" style="max-width:520px; margin-bottom:16px;">
    <tr><td>Vlasnik</td><td>${owner?`<a href="#/admin/users/${owner.id}">${esc(owner.display_name||"—")}</a> · ${esc(owner.email)}`:esc(store.owner_id)}</td></tr>
    <tr><td>Pretplata</td><td>${storeSubPill(store)}${store.grandfathered?`<div style="font-size:11.5px;color:var(--ink-faint);">Besplatna — otvorena pre uvođenja pretplate (bez isteka)</div>`:`<div style="font-size:11.5px;color:var(--ink-faint);">važi do ${store.paid_until?fmtDateTime(store.paid_until):"—"}</div>`}</td></tr>
    <tr><td>Telefon</td><td>${esc(store.contact_phone||"—")}</td></tr><tr><td>Email</td><td>${esc(store.contact_email||"—")}</td></tr>
    ${store.suspended_reason?`<tr><td>Razlog suspenzije</td><td>${esc(store.suspended_reason)}</td></tr>`:""}
  </table>
  ${store.description?`<p style="font-size:13.5px; color:var(--ink-dim); white-space:pre-wrap; max-width:640px; margin-bottom:16px;">${esc(store.description)}</p>`:""}
  <div style="display:flex; gap:8px; flex-wrap:wrap; margin-bottom:26px;">
    <a href="#/prodavnica/${esc(store.slug)}" class="btn btn-outline btn-sm">Otvori javnu stranicu</a>
    <a href="#/admin/orders?store=${store.id}" class="btn btn-outline btn-sm">🧾 Porudžbine prodavnice</a>
    <a href="#/admin/payments?q=${encodeURIComponent(store.slug)}" class="btn btn-outline btn-sm">💳 Uplate pretplate</a>
    ${store.grandfathered?`<button class="btn btn-outline btn-sm" onclick="adminStoreGrandfather('${store.id}',false)">Prebaci na plaćenu pretplatu</button>`:`<button class="btn btn-outline btn-sm" onclick="adminStoreGrandfather('${store.id}',true)">Označi kao besplatnu</button>`}
    ${store.status==="suspended"?`<button class="btn btn-primary btn-sm" onclick="adminStoreStatus('${store.id}','active')">Reaktiviraj prodavnicu</button>`:`<button class="btn btn-danger btn-sm" onclick="adminStoreStatus('${store.id}','suspended')">Suspenduj prodavnicu</button>`}
  </div>
  <h3 style="font-size:15px; margin-bottom:12px;">Proizvodi (${products.length})</h3>
  ${products.length ? products.map(l=>`<div class="list-row"><div class="thumb-sm">${l.images&&l.images.length?`<img src="${esc(l.images[0])}" style="width:100%;height:100%;object-fit:cover;border-radius:9px;">`:"📦"}</div>
    <div class="info"><div class="t">${esc(l.title)}</div><div class="stats"><span>${fmtPrice(l.price,l.currency)}</span><span>👁 ${l.views_count||0}</span><span class="status-pill ${statusClass(l.status)}">${statusLabel(l.status)}</span></div></div>
    <div style="display:flex; gap:6px; flex-wrap:wrap; justify-content:flex-end;"><a href="#/oglas/${l.id}" class="btn btn-outline btn-sm">Pogledaj</a>
    ${l.status!=="removed"?`<button class="btn btn-danger btn-sm" onclick="adminListingAction('${l.id}','removed',true)">Ukloni</button>`:`<button class="btn btn-outline btn-sm" onclick="adminListingAction('${l.id}','active')">Vrati</button>`}</div></div>`).join("")
    : emptyState("📦","Prodavnica nema proizvoda.","")}`;
}
async function adminStoreStatus(id, status){
  let reason = null;
  if(status==="suspended"){
    reason = prompt("Razlog suspenzije (vidljiv vlasniku):"); if(reason===null) return;
  }else if(!confirm("Reaktivirati ovu prodavnicu?")) return;
  try{
    const { error } = await sb.rpc("admin_set_store_status", { p_store_id:id, p_status:status, p_reason:reason });
    if(error) throw error;
    toast(status==="suspended"?"Prodavnica je suspendovana":"Prodavnica je reaktivirana"); route();
  }catch(e){ toast("Greška: "+(e.message||"pokušaj ponovo")); }
}


/* ======================================================================
   TRADER DECLARATION (Izjava o statusu prodavca)
   The database REQUIRES profiles.trader_status <> 'undeclared' before a user
   may insert listings or open a store (RLS). This screen only calls the RPC
   declare_trader_status() (server-side validation lives there). Asked at the first publish / store attempt, never at registration.
   ====================================================================== */
function declarationGateHtml(returnHash, purpose){
  Store.set("declReturn", returnHash);
  return `<div class="wrap"><div class="auth-card">
    <h2>Potrebna je izjava o statusu prodavca</h2>
    <p class="sub">Pre nego što nastaviš sa: ${esc(purpose)}, potrebno je da izjaviš da li prodaješ kao fizičko lice (privatni prodavac) ili kao trgovac. Traje oko minut, a pita se samo jednom.</p>
    <a href="#/deklaracija" class="btn btn-primary btn-block">Popuni izjavu</a>
  </div></div>`;
}
function decToggle(){
  const t = (document.querySelector('input[name="decType"]:checked')||{}).value;
  const el = document.getElementById("decBiz"); if(el) el.style.display = t==="trader" ? "block" : "none";
}
async function viewDeclaration(){
  if(!ME.id){
    Store.set("postLoginRedirect", "#/deklaracija");
    return `<div class="wrap"><div class="auth-card"><h2>Prijava potrebna</h2><a href="#/prijava" class="btn btn-primary btn-block">Prijavi se</a></div></div>`;
  }
  const cur = await fetchMySellerStatus();
  const st = cur && (cur.trader_status==="trader" || cur.trader_status==="non_trader") ? cur.trader_status : "";
  const b = st==="trader" ? cur : {};
  const val = k => esc(b[k]||"");
  const forms = ["Preduzetnik","Društvo sa ograničenom odgovornošću (d.o.o.)","Akcionarsko društvo","Ortačko društvo","Drugo"];
  const curForm = b.business_legal_form || "";
  return `<div class="wrap section"><div class="wizard-card" style="max-width:600px;">
    <h2>Izjava o statusu prodavca</h2>
    <p class="sub" style="text-align:left; margin-bottom:16px;">Kupci na svakom oglasu vide da li prodaješ kao fizičko lice ili kao trgovac. ${st?`Trenutni status: <b>${esc(sellerStatusLabel(st))}</b>. Izjavu možeš da izmeniš.`:"Izaberi jednu opciju."} <a href="#/zastita-kupaca" style="color:var(--blue); text-decoration:underline;">Saznaj više</a></p>
    <div id="decError" class="notice err" style="display:none;"></div>
    <label class="dec-opt"><input type="radio" name="decType" value="non_trader" ${st==="non_trader"?"checked":""} onchange="decToggle()">
      <div><b>Fizičko lice – privatni prodavac</b><span>Prodajem kao fizičko lice i ne nastupam kao trgovac, van svoje poslovne ili druge komercijalne delatnosti. Podaci o delatnosti se ne traže.</span></div></label>
    <label class="dec-opt"><input type="radio" name="decType" value="trader" ${st==="trader"?"checked":""} onchange="decToggle()">
      <div><b>Trgovac</b><span>Prodajem u okviru svoje delatnosti (preduzetnik, pravno lice ili drugo lice koje nastupa kao trgovac). Potrebni su podaci o poslovanju, koji se prikazuju kupcima.</span></div></label>
    <div id="decBiz" style="display:${st==="trader"?"block":"none"}; margin-top:14px;">
      <div class="form-group"><label>Poslovno ime *</label><input type="text" id="decName" maxlength="120" value="${val("business_name")}"></div>
      <div class="form-group"><label>Pravna forma *</label>
        <select id="decForm">${forms.map(f=>`<option ${f===curForm?"selected":""}>${esc(f)}</option>`).join("")}</select></div>
      <div class="form-group"><label>Adresa sedišta *</label><input type="text" id="decAddr" maxlength="200" value="${val("business_address")}"></div>
      <div class="form-row">
        <div class="form-group"><label>Matični broj * (8 cifara)</label><input type="text" id="decReg" maxlength="12" inputmode="numeric" value="${val("business_registration_number")}"></div>
        <div class="form-group"><label>PIB * (9 cifara)</label><input type="text" id="decPib" maxlength="12" inputmode="numeric" value="${val("business_pib")}"></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>E-pošta *</label><input type="email" id="decEmail" maxlength="120" value="${val("business_email")}"></div>
        <div class="form-group"><label>Telefon *</label><input type="tel" id="decPhone" maxlength="30" value="${val("business_phone")}"></div>
      </div>
      <p style="font-size:12px; color:var(--ink-faint);">Ovi podaci se javno prikazuju na tvojim oglasima i u prodavnici, uz napomenu da su navedeni prema tvojoj izjavi.</p>
    </div>
    <label class="f-check" style="margin:14px 0 4px; align-items:flex-start;"><input type="checkbox" id="decConfirm"> Potvrđujem da su podaci tačni i da ću izjavu ažurirati ako se promene. Ako prodajem u okviru svoje delatnosti, biram „Trgovac“.</label>
    <div class="wizard-actions"><a href="${Store.get("declReturn","")==="#/moj-pazarime/podesavanja"?"#/moj-pazarime/podesavanja":"#/moj-pazarime"}" class="btn btn-outline">Otkaži</a>
      <button id="decBtn" class="btn btn-primary" onclick="submitDeclaration()">Potvrdi izjavu</button></div>
  </div></div>`;
}
const submitDeclaration = guarded("declare", async ()=>{
  const v = id => (document.getElementById(id)||{value:""}).value.trim();
  const err = m => { const el=document.getElementById("decError"); el.textContent=m; el.style.display="block"; el.scrollIntoView({block:"center"}); };
  const sel = document.querySelector('input[name="decType"]:checked');
  if(!sel) return err("Izaberi jednu opciju: fizičko lice ili trgovac.");
  const status = sel.value;
  let business = null;
  if(status==="trader"){
    const digits = x => x.replace(/\s+/g,"");
    business = { business_name:v("decName"), business_legal_form:v("decForm"), business_address:v("decAddr"),
      business_registration_number:digits(v("decReg")), business_pib:digits(v("decPib")), business_email:v("decEmail"), business_phone:v("decPhone") };
    if(business.business_name.length<2) return err("Unesi poslovno ime.");
    if(business.business_address.length<5) return err("Unesi adresu sedišta.");
    if(!/^\d{8}$/.test(business.business_registration_number)) return err("Matični broj mora imati 8 cifara.");
    if(!/^\d{9}$/.test(business.business_pib)) return err("PIB mora imati 9 cifara.");
    if(!isValidEmail(business.business_email)) return err("Unesi ispravnu e-adresu.");
    if(!/^\+?\d[\d\s()./-]{5,29}$/.test(business.business_phone)) return err("Unesi ispravan broj telefona.");
  }
  if(!document.getElementById("decConfirm").checked) return err("Potvrdi da su podaci tačni.");
  if(status==="non_trader" && ME.traderStatus==="trader" && !confirm("Promena na „Fizičko lice“ briše podatke o delatnosti iz tvog profila. Nastaviti?")) return;
  const btn = document.getElementById("decBtn"); if(btn){ btn.disabled=true; btn.textContent="Čuvanje..."; }
  try{
    const { error } = await sb.rpc("declare_trader_status", { p_status: status, p_business: business });
    if(error) throw error;
    ME.traderStatus = status;
    toast("Izjava je sačuvana");
    const dest = Store.get("declReturn", null); Store.del("declReturn");
    location.hash = (dest || "#/moja-prodavnica").replace(/^#/, "");
  }catch(e){
    console.error(e);
    err(e && /^Izjava:/.test(e.message||"") ? e.message.replace(/^Izjava:\s*/,"") : "Greška pri čuvanju izjave. Pokušaj ponovo.");
    if(btn){ btn.disabled=false; btn.textContent="Potvrdi izjavu"; }
  }
});


/* ======================================================================
   ORDERS  (store products: "Kupi" -> checkout -> orders)
   Data lives in public.orders / public.order_items. Orders are created ONLY by
   the place_order() RPC, which reads price + product name from the database
   (nothing price-related is trusted from this file) and stores snapshots.
   Who can read an order is decided by RLS: buyer, seller or admin.
   No online payment: the order is simply submitted to the seller.
   ====================================================================== */
const ORDER_STATUSES = [["nova","Nova"],["potvrdjena","Potvrđena"],["u_pripremi","U pripremi"],["poslata","Poslata"],["zavrsena","Završena"],["otkazana","Otkazana"]];
const ORDER_SELECT = "*, order_items(*)";
function orderStatusLabel(s){ const f = ORDER_STATUSES.find(x=>x[0]===s); return f ? f[1] : s; }
function orderStatusClass(s){ return s==="nova" ? "status-pending" : s==="zavrsena" ? "status-sold" : s==="otkazana" ? "status-cancel" : "status-active"; }
function fmtOrderNo(n){ return "PM-" + String(n||0).padStart(6,"0"); }
function fmtDateTime(ts){ try{ return new Date(ts).toLocaleString("sr-RS",{day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit"}); }catch(e){ return fmtDate(ts); } }

/* ---------- queries (RLS decides what comes back) ---------- */
async function countNewOrders(){
  if(!ME.id) return 0;
  try{
    const { count, error } = await sb.from("orders").select("id",{count:"exact",head:true}).eq("seller_id", ME.id).eq("status","nova");
    if(error) throw error; return count||0;
  }catch(e){ return 0; }
}
async function fetchOrders(filter){
  try{
    let q = sb.from("orders").select(ORDER_SELECT).order("created_at",{ascending:false}).limit(300);
    if(filter && filter.seller) q = q.eq("seller_id", filter.seller);
    if(filter && filter.buyer)  q = q.eq("buyer_id", filter.buyer);
    if(filter && filter.store)  q = q.eq("store_id", filter.store);
    if(filter && filter.status) q = q.eq("status", filter.status);
    if(filter && filter.id)     q = q.eq("id", filter.id);
    const { data, error } = await q; if(error) throw error; return data||[];
  }catch(e){ console.error(e); return []; }
}

/* ---------- shared order card ---------- */
function orderItemsHtml(o){
  const items = o.order_items||[];
  return items.map(i=>`<div class="order-line"><div style="min-width:0;">${esc(i.product_name)} <span style="color:var(--ink-faint);">× ${i.quantity}</span>
      <div style="font-size:11.5px; color:var(--ink-faint);">${fmtPrice(i.product_price,i.currency)} po komadu</div></div><div>${fmtPrice(i.subtotal,i.currency)}</div></div>`).join("")
    + `<div class="order-total"><span>Ukupno</span><span>${fmtPrice(o.total,o.currency)}</span></div>`;
}
function orderCardHtml(o, mode){
  const closed = o.status==="zavrsena" || o.status==="otkazana";
  const canEdit = mode==="admin" || (mode==="seller" && !closed);
  const statusCtl = mode==="buyer"
    ? `<span class="status-pill ${orderStatusClass(o.status)}">${esc(orderStatusLabel(o.status))}</span>`
    : `<select class="order-status-sel" ${canEdit?"":"disabled"} onchange="setOrderStatus('${o.id}', this.value)">${ORDER_STATUSES.map(([v,l])=>`<option value="${v}" ${o.status===v?"selected":""}>${l}</option>`).join("")}</select>`;
  const tel = esc(String(o.buyer_phone||"").replace(/[^\d+]/g,""));
  const customer = `<div>
      <div class="order-label">Kupac</div>
      <div style="font-weight:600;">${esc(o.buyer_name)} ${esc(o.buyer_surname)}</div>
      <div style="font-size:13px; margin-top:4px;"><a href="mailto:${esc(o.buyer_email)}" style="color:var(--blue);">${esc(o.buyer_email)}</a></div>
      <div style="font-size:13px;"><a href="tel:${tel}" style="color:var(--blue);">${esc(o.buyer_phone)}</a></div>
      <div class="order-label" style="margin-top:10px;">Adresa za isporuku</div>
      <div style="font-size:13.5px; line-height:1.5;">${esc(o.buyer_address)}<br>${esc(o.buyer_postal_code)} ${esc(o.buyer_city)}</div>
      ${o.buyer_note?`<div class="order-label" style="margin-top:10px;">Napomena kupca</div><div style="font-size:13.5px; white-space:pre-wrap;">${esc(o.buyer_note)}</div>`:""}
    </div>`;
  const storeLine = (mode!=="seller") ? `<div style="font-size:12.5px; color:var(--ink-dim); margin-bottom:8px;">Prodavnica: ${o.store_slug?`<a href="#/prodavnica/${encodeURIComponent(o.store_slug)}" style="color:var(--blue);">${esc(o.store_name)}</a>`:esc(o.store_name)}</div>` : "";
  return `<div class="order-card">
    <div class="order-head">
      <div><span class="order-no">${fmtOrderNo(o.order_number)}</span> <span style="font-size:12px; color:var(--ink-faint); margin-left:6px;">${fmtDateTime(o.created_at)}</span></div>
      ${statusCtl}
    </div>
    ${storeLine}
    <div class="order-grid">
      <div><div class="order-label">Proizvodi</div>${orderItemsHtml(o)}</div>
      ${customer}
    </div>
    ${mode==="seller"&&closed?`<div style="font-size:11.5px; color:var(--ink-faint); margin-top:10px;">Porudžbina je zaključena — status se više ne može menjati.</div>`:""}
  </div>`;
}
const setOrderStatus = guarded("orderStatus", async (id, status)=>{
  if(status==="otkazana" && !confirm("Otkazati porudžbinu? Količina se vraća na stanje, a otkazanu porudžbinu prodavac više ne može da menja.")){ route(); return; }
  if(status==="zavrsena" && !isAdmin() && !confirm("Označiti porudžbinu kao završenu? Nakon toga se status više ne može menjati.")){ route(); return; }
  try{
    const { error } = await sb.from("orders").update({ status }).eq("id", id);
    if(error) throw error;
    toast("Status: " + orderStatusLabel(status)); route();
  }catch(e){
    console.error(e); toast(e && e.message && /zaključena/i.test(e.message) ? e.message : "Greška pri promeni statusa"); route();
  }
});

/* ---------- seller: Moja prodavnica -> Porudžbine ---------- */
async function renderMyStoreOrders(store, statusFilter){
  const all = await fetchOrders({ seller: ME.id });
  const counts = {}; all.forEach(o=>{ counts[o.status]=(counts[o.status]||0)+1; });
  const list = statusFilter ? all.filter(o=>o.status===statusFilter) : all;
  return `<h2 style="font-size:20px; margin-bottom:14px;">Porudžbine (${all.length})</h2>
    <div class="store-tabs">
      <a class="${!statusFilter?"active":""}" href="#/moja-prodavnica/porudzbine">Sve (${all.length})</a>
      ${ORDER_STATUSES.map(([v,l])=>`<a class="${statusFilter===v?"active":""}" href="#/moja-prodavnica/porudzbine/${v}">${l} (${counts[v]||0})</a>`).join("")}
    </div>
    ${list.length ? list.map(o=>orderCardHtml(o,"seller")).join("")
      : emptyState("🧾", all.length?"Nema porudžbina sa tim statusom.":"Još nemaš porudžbina.", all.length?"":"Kada kupac klikne „Kupi“ na tvom proizvodu, porudžbina će se pojaviti ovde.")}`;
}

/* ---------- customer: Moje porudžbine ---------- */
async function viewMyOrders(){
  if(!ME.id){
    Store.set("postLoginRedirect", "#/moje-porudzbine");
    return `<div class="wrap"><div class="auth-card"><h2>Prijava potrebna</h2><p class="sub">Prijavi se da bi video svoje porudžbine.</p><a href="#/prijava" class="btn btn-primary btn-block">Prijavi se</a></div></div>`;
  }
  const orders = await fetchOrders({ buyer: ME.id });
  return `<div class="wrap section" style="max-width:820px;">
    <div class="section-head"><h2>Moje porudžbine</h2><a class="link" href="#/moj-pazarime">← Moj PazariMe</a></div>
    ${orders.length ? orders.map(o=>orderCardHtml(o,"buyer")).join("")
      : emptyState("🧾","Još nemaš porudžbina.","Kada kupiš proizvod iz neke prodavnice, porudžbina će se pojaviti ovde.", `<a href="#/prodavnice" class="btn btn-primary" style="margin-top:14px;">Pogledaj prodavnice</a>`)}
  </div>`;
}

/* ---------- checkout ("Kupi") ---------- */
let ck = null;           // checkout state (product + price are DISPLAY ONLY; the server re-reads them)
let lastOrder = null;
async function viewCheckout(id){
  const l = await fetchListing(id);
  const blockedPage = (title, text)=>`<div class="wrap section">${emptyState("🛒", title, text, `<a href="#/oglas/${esc(id)}" class="btn btn-primary" style="margin-top:14px;">Nazad</a>`)}</div>`;
  if(!l) return blockedPage("Proizvod nije pronađen", "Proizvod ne postoji ili trenutno nije dostupan.");
  if(!l.store_id) return blockedPage("Ovaj oglas se ne može kupiti ovde", "Kontaktiraj prodavca porukom da se dogovorite o kupovini.");
  const store = await fetchStoreById(l.store_id);
  if(store) STORE_CACHE[store.id] = store;
  if(!store || store.status!=="active") return blockedPage("Prodavnica ne prima porudžbine", "Prodavnica trenutno nije aktivna.");
  if(l.status!=="active" || productUnavailable(l)) return blockedPage("Proizvod nije dostupan", "Ovaj proizvod trenutno nije dostupan za kupovinu.");
  if(ME.id && ME.id===l.seller_id) return blockedPage("Ovo je tvoj proizvod", "Ne možeš da kupiš sopstveni proizvod.");

  const sellerSt = await fetchSellerStatuses([l.seller_id]);
  const maxQty = l.stock!=null ? Math.max(1, Math.min(99, l.stock)) : 99;
  ck = { id:l.id, title:l.title, price:effPrice(l), listPrice:Number(l.price)||0, currency:l.currency||"RSD", maxQty, storeName:store.name, storeSlug:store.slug, image:(l.images&&l.images[0])||null };
  const parts = (ME.name||"").trim().split(/\s+/);
  const first = ME.id ? (parts[0]||"") : "", last = ME.id ? parts.slice(1).join(" ") : "";
  return `<div class="wrap section" style="max-width:860px;">
    <a href="#/prodavnica/${esc(store.slug)}/proizvod/${encodeURIComponent(l.slug||"")}" style="font-size:12.5px; color:var(--ink-faint);">← Nazad na proizvod</a>
    <h2 style="margin:10px 0 18px; font-size:22px;">Poručivanje</h2>
    <div class="order-grid" style="align-items:start;">
      <div class="wizard-card" style="max-width:none; margin:0;">
        <div id="ckError" class="notice err" style="display:none;"></div>
        <div class="form-row">
          <div class="form-group"><label>Ime *</label><input type="text" id="ckIme" maxlength="60" autocomplete="given-name" value="${esc(first)}"></div>
          <div class="form-group"><label>Prezime *</label><input type="text" id="ckPrezime" maxlength="60" autocomplete="family-name" value="${esc(last)}"></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Email *</label><input type="email" id="ckEmail" maxlength="120" autocomplete="email" value="${esc(ME.id?ME.email:"")}"></div>
          <div class="form-group"><label>Broj telefona *</label><input type="tel" id="ckTel" maxlength="30" autocomplete="tel" placeholder="+381 6x xxx xxxx"></div>
        </div>
        <div class="form-group"><label>Adresa *</label><input type="text" id="ckAdresa" maxlength="200" autocomplete="street-address" placeholder="Ulica i broj"></div>
        <div class="form-row">
          <div class="form-group"><label>Grad *</label><input type="text" id="ckGrad" maxlength="80" autocomplete="address-level2" list="ckCities"><datalist id="ckCities">${CITIES.map(c=>`<option value="${esc(c)}">`).join("")}</datalist></div>
          <div class="form-group"><label>Poštanski broj *</label><input type="text" id="ckPosta" maxlength="12" inputmode="numeric" autocomplete="postal-code"></div>
        </div>
        <div class="form-group"><label>Količina *</label>
          <div class="qty-stepper"><button type="button" onclick="ckQty(-1)" aria-label="Manje">−</button><input type="number" id="ckQty" min="1" max="${maxQty}" value="1" inputmode="numeric" oninput="ckSummary()"><button type="button" onclick="ckQty(1)" aria-label="Više">+</button></div>
          ${l.stock!=null?`<div style="font-size:11.5px; color:var(--ink-faint); margin-top:4px;">Na stanju: ${l.stock}</div>`:""}</div>
        <div class="form-group"><label>Napomena (opciono)</label><textarea id="ckNapomena" maxlength="500" placeholder="Npr. vreme isporuke, boja, veličina..."></textarea></div>
      </div>
      <div class="order-summary">
        <div class="order-label">Pregled porudžbine</div>
        <div id="ckSummary"></div>
        ${sellerStatusBoxHtml(sellerSt[l.seller_id])}
        <button id="ckBtn" class="btn btn-primary btn-block" style="margin-top:14px;" onclick="submitOrder()">Potvrdi porudžbinu</button>
        <p style="font-size:12px; color:var(--ink-faint); margin-top:10px; line-height:1.5;">Online plaćanje trenutno nije dostupno. Porudžbina se šalje prodavcu, a način plaćanja i isporuke dogovarate direktno sa njim.</p>
      </div>
    </div>
  </div>`;
}
function ckQtyValue(){
  const el = document.getElementById("ckQty"); let q = parseInt(el && el.value);
  if(!(q>=1)) q = 1; if(ck && q>ck.maxQty) q = ck.maxQty; return q;
}
function ckQty(d){ const el=document.getElementById("ckQty"); if(!el||!ck) return; el.value = Math.min(ck.maxQty, Math.max(1, (parseInt(el.value)||1)+d)); ckSummary(); }
function ckSummary(){
  const box = document.getElementById("ckSummary"); if(!box||!ck) return;
  const q = ckQtyValue();
  box.innerHTML = `
    <div class="order-line"><span>Proizvod</span><span style="text-align:right; max-width:60%;">${esc(ck.title)}</span></div>
    <div class="order-line"><span>Količina</span><span>${q}</span></div>
    <div class="order-line"><span>Cena${ck.listPrice>ck.price?` <small style="color:var(--ink-faint)">(akcija)</small>`:""}</span><span>${ck.listPrice>ck.price?`<s class="promo-old">${fmtPrice(ck.listPrice,ck.currency)}</s> `:""}${fmtPrice(ck.price,ck.currency)}</span></div>
    <div class="order-line"><span>Prodavnica</span><span>${esc(ck.storeName)}</span></div>
    <div class="order-total" style="font-size:16px;"><span>Ukupno</span><span>${fmtPrice(ck.price*q,ck.currency)}</span></div>`;
}
const submitOrder = guarded("order", async ()=>{
  if(!ck) return;
  const v = id => (document.getElementById(id)||{value:""}).value.trim();
  const showErr = m => { const el=document.getElementById("ckError"); if(el){ el.textContent=m; el.style.display="block"; el.scrollIntoView({block:"center"}); } else toast(m); };
  const f = { ime:v("ckIme"), prezime:v("ckPrezime"), email:v("ckEmail"), tel:v("ckTel"), adresa:v("ckAdresa"), grad:v("ckGrad"), posta:v("ckPosta"), napomena:v("ckNapomena") };
  const qty = parseInt(v("ckQty"));
  if(!f.ime) return showErr("Unesi ime.");
  if(!f.prezime) return showErr("Unesi prezime.");
  if(!isValidEmail(f.email)) return showErr("Unesi ispravnu email adresu.");
  if(f.tel.replace(/[^\d]/g,"").length<6) return showErr("Unesi ispravan broj telefona.");
  if(f.adresa.length<3) return showErr("Unesi adresu.");
  if(f.grad.length<2) return showErr("Unesi grad.");
  if(f.posta.length<3) return showErr("Unesi poštanski broj.");
  if(!(qty>=1 && qty<=ck.maxQty)) return showErr("Količina mora biti između 1 i " + ck.maxQty + ".");
  const btn = document.getElementById("ckBtn"); if(btn){ btn.disabled=true; btn.textContent="Slanje..."; }
  try{
    const { data, error } = await sb.rpc("place_order", {
      p_product_id: ck.id, p_quantity: qty, p_name: f.ime, p_surname: f.prezime, p_email: f.email, p_phone: f.tel,
      p_address: f.adresa, p_city: f.grad, p_postal_code: f.posta, p_note: f.napomena || null
    });
    if(error) throw error;
    lastOrder = { number: data.order_number, total: data.total, currency: data.currency || ck.currency || "RSD", qty, title: ck.title, store: ck.storeName, storeSlug: ck.storeSlug, loggedIn: !!ME.id };
    ck = null;
    location.hash = "/porudzbina-primljena";
  }catch(e){
    console.error(e);
    const msg = (e && e.message && !/^(TypeError|Failed to fetch|NetworkError)/i.test(e.message)) ? e.message : "Greška pri slanju porudžbine. Pokušaj ponovo.";
    showErr(msg);
    if(btn){ btn.disabled=false; btn.textContent="Potvrdi porudžbinu"; }
  }
});
function viewOrderPlaced(){
  const o = lastOrder;
  return `<div class="wrap section"><div class="empty" style="max-width:480px; margin:0 auto;">
    <div class="glyph">🎉</div><h3>Porudžbina je poslata!</h3>
    ${o?`<p>Broj porudžbine: <b>${fmtOrderNo(o.number)}</b><br>${esc(o.title)} × ${o.qty} — ukupno <b>${fmtPrice(o.total,o.currency)}</b><br>Prodavnica: ${esc(o.store)}</p>`:`<p>Tvoja porudžbina je poslata prodavcu.</p>`}
    <p style="font-size:13px; color:var(--ink-dim);">Prodavac je primio tvoju porudžbinu i kontaktiraće te na email ili telefon koji si ostavio/la. ${o&&!o.loggedIn?"Sačuvaj broj porudžbine.":""}</p>
    <div style="display:flex; gap:10px; justify-content:center; margin-top:18px; flex-wrap:wrap;">
      ${ME.id?`<a href="#/moje-porudzbine" class="btn btn-primary">Moje porudžbine</a>`:""}
      ${o&&o.storeSlug?`<a href="#/prodavnica/${encodeURIComponent(o.storeSlug)}" class="btn ${ME.id?"btn-outline":"btn-primary"}">Nazad u prodavnicu</a>`:""}
      <a href="#/" class="btn btn-outline">Početna</a>
    </div>
  </div></div>`;
}

/* ---------- admin: Porudžbine ---------- */
async function renderAdminOrders(subId, params){
  if(subId){
    const [o] = await fetchOrders({ id: subId });
    if(!o) return emptyState("🧾","Porudžbina nije pronađena","");
    return `<a href="#/admin/orders" style="font-size:12.5px; color:var(--ink-faint);">← Nazad na porudžbine</a><div style="margin-top:14px;">${orderCardHtml(o,"admin")}</div>`;
  }
  const status = params.get("status")||"", storeId = params.get("store")||"";
  const orders = await fetchOrders({ status, store: storeId });
  return `
  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:10px;">
    <h2 style="font-size:20px;">Porudžbine (${orders.length})</h2>
    <div style="display:flex; gap:8px; flex-wrap:wrap;">
      ${storeId?`<a href="#/admin/orders" class="btn btn-outline btn-sm">✕ Sve prodavnice</a>`:""}
      <select onchange="location.hash='/admin/orders?'+mkFilter('status',this.value)">
        <option value="">Svi statusi</option>${ORDER_STATUSES.map(([v,l])=>`<option value="${v}" ${status===v?"selected":""}>${l}</option>`).join("")}
      </select></div>
  </div>
  <p style="font-size:12px; color:var(--ink-faint); margin-bottom:12px;">Podaci o kupcima su privatni — koristi ih samo kada je potrebno za moderaciju ili podršku.</p>
  ${orders.length ? `<div class="overflow-x"><table class="admin-table"><thead><tr><th>Broj</th><th>Datum</th><th>Prodavnica</th><th>Kupac</th><th>Ukupno</th><th>Status</th><th></th></tr></thead><tbody>
  ${orders.map(o=>`<tr>
    <td><a href="#/admin/orders/${o.id}" style="font-weight:600;">${fmtOrderNo(o.order_number)}</a></td>
    <td>${fmtDateTime(o.created_at)}</td>
    <td>${esc(o.store_name)}</td>
    <td>${esc(o.buyer_name)} ${esc(o.buyer_surname)}<div style="font-size:11px; color:var(--ink-faint);">${esc(o.buyer_email)}</div></td>
    <td>${fmtPrice(o.total,o.currency)}</td>
    <td><span class="status-pill ${orderStatusClass(o.status)}">${esc(orderStatusLabel(o.status))}</span></td>
    <td><a href="#/admin/orders/${o.id}" class="btn btn-outline btn-sm">Detalji</a></td>
  </tr>`).join("")}
  </tbody></table></div>` : emptyState("🧾","Nema porudžbina za prikaz.","")}`;
}


/* ======================================================================
   MOBILE UX  (header drawer, search toggle, keyboard handling, table labels)
   Pure UI helpers: no data access, no business logic.
   ====================================================================== */
function mmLink(href, label, extra){
  const here = (location.hash||"#/").split("?")[0];
  return `<a href="${href}" class="${here===href?"active":""} ${extra||""}" onclick="closeMobileMenu()">${label}</a>`;
}
function buildMobileMenu(){
  const box = document.getElementById("mmLinks"); if(!box) return;
  const unread = (typeof unreadMessages!=="undefined" && unreadMessages.length) || 0;
  let h = `<a href="#/postavi-oglas" class="mm-cta" onclick="closeMobileMenu()">+ Postavi oglas</a>`;
  h += mmLink("#/","🏠 Početna") + mmLink("#/oglasi","🔎 Oglasi") + mmLink("#/prodavnice","🏪 Prodavnice") + mmLink("#/omiljeni","♡ Omiljeni");
  h += mmLink("#/poruke", `<span>💬 Poruke</span>${unread?`<span class="mm-count">${unread}</span>`:""}`);
  h += `<div class="mm-sep"></div>`;
  if(ME.id){
    h += `<div class="mm-label">Moj nalog</div>` + mmLink("#/moj-pazarime","👤 Moj PazariMe") + mmLink("#/moja-prodavnica","🏬 Moja prodavnica") + mmLink("#/moje-porudzbine","🧾 Moje porudžbine");
    if(ME.isAdmin) h += mmLink("#/admin/dashboard","🛡️ Admin panel");
    h += `<button type="button" onclick="closeMobileMenu();doLogout()">↩ Odjavi se</button>`;
  }else{
    h += mmLink("#/prijava","🔑 Prijava") + mmLink("#/registracija","✨ Registracija");
  }
  h += `<div class="mm-sep"></div><div class="mm-label">Informacije</div>` + mmLink("#/kako-radi","Kako radi?") + mmLink("#/bezbednost","Bezbednost") + mmLink("#/kontakt","Kontakt") + mmLink("#/faq","Najčešća pitanja") + mmLink("#/zastita-kupaca","Zaštita kupaca");
  box.innerHTML = h;
}
function openMobileMenu(){
  buildMobileMenu(); closeMobileSearch();
  document.body.classList.add("menu-open");
  const m = document.getElementById("mobileMenu"); if(m) m.setAttribute("aria-hidden","false");
  const t = document.getElementById("menuToggle"); if(t) t.setAttribute("aria-expanded","true");
}
function closeMobileMenu(){
  document.body.classList.remove("menu-open");
  const m = document.getElementById("mobileMenu"); if(m) m.setAttribute("aria-hidden","true");
  const t = document.getElementById("menuToggle"); if(t) t.setAttribute("aria-expanded","false");
}
function toggleMobileMenu(){ document.body.classList.contains("menu-open") ? closeMobileMenu() : openMobileMenu(); }
function closeMobileSearch(){
  const hd = document.querySelector(".site-header"); if(hd) hd.classList.remove("search-open");
  const t = document.getElementById("searchToggle"); if(t) t.setAttribute("aria-expanded","false");
}
function toggleMobileSearch(){
  const hd = document.querySelector(".site-header"); if(!hd) return;
  const open = !hd.classList.contains("search-open");
  hd.classList.toggle("search-open", open);
  const t = document.getElementById("searchToggle"); if(t) t.setAttribute("aria-expanded", String(open));
  if(open){ closeMobileMenu(); const i = document.getElementById("headerSearchInput"); if(i) setTimeout(()=>i.focus(), 30); }
}
/* runs after every route render */
function enhanceUI(){
  // admin tables: copy header text into data-label so the phone layout can show "label: value" rows
  document.querySelectorAll("table.admin-table").forEach(tb=>{
    const heads = [...tb.querySelectorAll("thead th")].map(th=>th.textContent.trim());
    tb.querySelectorAll("tbody tr").forEach(tr=>{ [...tr.children].forEach((td,i)=>{ if(!td.hasAttribute("data-label")) td.setAttribute("data-label", heads[i]||""); }); });
  });
  // horizontal tab bars: keep the active tab visible
  const act = document.querySelector(".dash-nav a.active");
  if(act && act.scrollIntoView){ try{ act.scrollIntoView({inline:"center", block:"nearest"}); }catch(e){} window.scrollTo(0,0); }
  closeMobileMenu(); closeMobileSearch();
}
(function setupViewportHelpers(){
  const root = document.documentElement;
  const setVvh = ()=> root.style.setProperty("--vvh", ((window.visualViewport && window.visualViewport.height) || window.innerHeight) + "px");
  setVvh();
  window.addEventListener("resize", ()=>{ setVvh(); if(window.innerWidth>1100) closeMobileMenu(); if(window.innerWidth>680) closeMobileSearch(); });
  if(window.visualViewport){ window.visualViewport.addEventListener("resize", setVvh); }
  const isField = el => el && /^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName) && !/^(checkbox|radio|button|submit|file|range)$/.test(el.type||"");
  document.addEventListener("focusin", e=>{ if(isField(e.target)) document.body.classList.add("kbd-open"); });
  document.addEventListener("focusout", ()=>{ setTimeout(()=>{ if(!isField(document.activeElement)) document.body.classList.remove("kbd-open"); }, 120); });
  document.addEventListener("keydown", e=>{ if(e.key==="Escape"){ closeMobileMenu(); closeMobileSearch(); if(window.__pzmSheet) toggleFiltersPanel(); } });
})();


/* ======================================================================
   IMAGE VIEWER (lightbox) + IMAGE MANAGEMENT
   * Lightbox: overlay on the current page (no separate page), contain-fit so images are never
     distorted, X / backdrop / Esc / Android-back to close, prev/next + swipe for multiple images.
   * Storage cleanup helpers only ever delete files inside the CURRENT USER's own folder, only
     AFTER the database no longer references them. Authorization itself is enforced by the
     existing RLS + storage policies (owner-folder only), not by this file.
   ====================================================================== */
let galleryState = { images: [], i: 0 };
function galleryShow(i){
  const imgs = galleryState.images; if(!imgs.length) return;
  i = Math.max(0, Math.min(imgs.length-1, i)); galleryState.i = i;
  const el = document.getElementById("galleryImg"); if(el) el.src = imgs[i];
  document.querySelectorAll(".gallery-thumbs .t").forEach((t,k)=>t.classList.toggle("active", k===i));
}
function galleryKey(e){ if(e.key==="Enter" || e.key===" "){ e.preventDefault(); openGalleryLightbox(); } }
function openGalleryLightbox(){ if(galleryState.images.length) openLightbox(galleryState.images, galleryState.i, galleryShow); }
function wizPreview(i){ openLightbox(wizState.photos.map(p=>p.url), i); }
function pformPreview(i){ if(pform) openLightbox(pform.photos.map(p=>p.url), i); }

const LB = { open:false, urls:[], i:0, onChange:null, pushed:false, lastFocus:null, tracking:false, tx:0, ty:0 };
function lbEnsure(){
  let el = document.getElementById("lightbox"); if(el) return el;
  el = document.createElement("div");
  el.id = "lightbox"; el.className = "lb";
  el.setAttribute("role","dialog"); el.setAttribute("aria-modal","true"); el.setAttribute("aria-label","Pregled slike");
  el.innerHTML = `<div class="lb-top"><span class="lb-count" id="lbCount" aria-live="polite"></span><button type="button" class="lb-close" id="lbClose" aria-label="Zatvori pregled slike">✕</button></div>
    <div class="lb-stage" id="lbStage">
      <button type="button" class="lb-nav lb-prev" id="lbPrev" aria-label="Prethodna slika">‹</button>
      <img class="lb-img" id="lbImg" alt="" draggable="false">
      <div class="lb-err" id="lbErr" hidden>Slika nije dostupna</div>
      <button type="button" class="lb-nav lb-next" id="lbNext" aria-label="Sledeća slika">›</button>
    </div>`;
  document.body.appendChild(el);
  el.querySelector("#lbClose").addEventListener("click", ()=>closeLightbox());
  el.querySelector("#lbPrev").addEventListener("click", ()=>lbGo(-1));
  el.querySelector("#lbNext").addEventListener("click", ()=>lbGo(1));
  // tapping/clicking anywhere that is not the image or a button = outside = close
  el.addEventListener("click", e=>{ if(e.target.id!=="lbImg" && !e.target.closest("button")) closeLightbox(); });
  // touch: horizontal swipe = prev/next, vertical swipe = close. Two-finger gestures (pinch) are left to the browser.
  el.addEventListener("touchstart", e=>{
    if(e.touches.length!==1){ LB.tracking=false; return; }
    LB.tracking=true; LB.tx=e.touches[0].clientX; LB.ty=e.touches[0].clientY;
  }, {passive:true});
  el.addEventListener("touchend", e=>{
    if(!LB.tracking) return; LB.tracking=false;
    const t = e.changedTouches[0], dx = t.clientX-LB.tx, dy = t.clientY-LB.ty, ax = Math.abs(dx), ay = Math.abs(dy);
    if(ax>50 && ax>ay*1.4) lbGo(dx<0 ? 1 : -1);
    else if(ay>90 && ay>ax*1.4) closeLightbox();
  }, {passive:true});
  return el;
}
function lbRender(){
  const n = LB.urls.length, img = document.getElementById("lbImg"), err = document.getElementById("lbErr");
  err.hidden = true; img.style.visibility = "visible";
  img.onerror = ()=>{ img.style.visibility = "hidden"; err.hidden = false; };
  img.src = LB.urls[LB.i];
  img.alt = `Slika ${LB.i+1} od ${n}`;
  document.getElementById("lbCount").textContent = n>1 ? `${LB.i+1} / ${n}` : "";
  document.getElementById("lbPrev").hidden = n<2; document.getElementById("lbNext").hidden = n<2;
  [LB.i-1, LB.i+1].forEach(k=>{ if(k>=0 && k<n){ const p = new Image(); p.src = LB.urls[k]; } });   // preload neighbours
}
function lbGo(d){
  const n = LB.urls.length; if(n<2) return;
  LB.i = (LB.i + d + n) % n; lbRender();
  if(LB.onChange){ try{ LB.onChange(LB.i); }catch(e){} }
}
function openLightbox(urls, start, onChange){
  urls = (urls||[]).filter(Boolean); if(!urls.length) return;
  const el = lbEnsure();
  LB.urls = urls; LB.i = Math.max(0, Math.min(urls.length-1, start||0)); LB.onChange = onChange||null;
  if(!LB.open) LB.lastFocus = document.activeElement;
  closeMobileMenu(); closeMobileSearch();
  lbRender();
  el.classList.add("open"); document.body.classList.add("lb-open");
  if(!LB.open){
    LB.open = true;
    try{ history.pushState({pzmLb:1}, "", location.href); LB.pushed = true; }catch(e){ LB.pushed = false; }   // Android/browser Back closes the viewer, not the page
  }
  const c = document.getElementById("lbClose"); if(c) c.focus({preventScroll:true});
}
function closeLightbox(fromPop){
  if(!LB.open) return;
  LB.open = false;
  const el = document.getElementById("lightbox"); if(el) el.classList.remove("open");
  document.body.classList.remove("lb-open");
  const img = document.getElementById("lbImg"); if(img){ img.onerror = null; img.removeAttribute("src"); }
  if(LB.pushed){ LB.pushed = false; if(!fromPop){ try{ history.back(); }catch(e){} } }
  if(LB.lastFocus && LB.lastFocus.focus){ try{ LB.lastFocus.focus({preventScroll:true}); }catch(e){} }
}
window.addEventListener("popstate", ()=>{ if(LB.open){ LB.pushed = false; closeLightbox(true); } });
window.addEventListener("hashchange", ()=>{ if(LB.open){ LB.pushed = false; closeLightbox(true); } });
document.addEventListener("keydown", e=>{
  if(!LB.open) return;
  if(e.key==="Escape"){ e.preventDefault(); e.stopImmediatePropagation(); closeLightbox(); }
  else if(e.key==="ArrowLeft"){ lbGo(-1); }
  else if(e.key==="ArrowRight"){ lbGo(1); }
  else if(e.key==="Tab"){   // keep keyboard focus inside the dialog
    const f = [...document.querySelectorAll("#lightbox button")].filter(b=>!b.hidden && b.offsetParent!==null);
    if(!f.length) return;
    if(e.shiftKey && document.activeElement===f[0]){ e.preventDefault(); f[f.length-1].focus(); }
    else if(!e.shiftKey && document.activeElement===f[f.length-1]){ e.preventDefault(); f[0].focus(); }
  }
}, true);

/* ---------- shared photo editor pieces (wizard, product form, listing edit form) ---------- */
function photoSlotHtml(url, i, isCover, fCover, fMove, fRemove, fPreview){
  return `<div class="photo-slot">
    <div class="photo-thumb">
      <img src="${esc(url)}" alt="Fotografija ${i+1}" onclick="${fPreview}(${i})">
      ${isCover?'<span class="photo-cover-badge">Naslovna</span>':""}
      <div class="photo-tools">
        <button type="button" onclick="${fCover}(${i})" title="Postavi kao naslovnu" aria-label="Postavi kao naslovnu">★</button>
        <button type="button" onclick="${fMove}(${i},-1)" aria-label="Pomeri ulevo">←</button>
        <button type="button" onclick="${fMove}(${i},1)" aria-label="Pomeri udesno">→</button>
      </div>
    </div>
    <button type="button" class="photo-remove" onclick="${fRemove}(${i})">Ukloni sliku</button>
  </div>`;
}
function pformPhotosBlockHtml(){
  return `<div class="form-group"><label>Fotografije * <span style="font-weight:400; color:var(--ink-faint);">(do 10, ★ = naslovna)</span></label>
        <div style="display:flex; gap:8px; margin-bottom:10px; flex-wrap:wrap;">
          <label class="btn btn-outline btn-sm" style="cursor:pointer;">📷 Snimi<input type="file" accept="image/jpeg,image/png,image/webp" capture="environment" style="display:none" onchange="handlePformFiles(this)"></label>
          <label class="btn btn-outline btn-sm" style="cursor:pointer;">🖼️ Galerija<input type="file" accept="image/jpeg,image/png,image/webp" multiple style="display:none" onchange="handlePformFiles(this)"></label>
          <span id="pfUploading" style="font-size:12.5px; color:var(--ink-faint); align-self:center;"></span>
        </div>
        <div class="upload-grid" id="pfPhotos">${pformPhotosHtml()}</div></div>`;
}

/* ---------- storage cleanup: own files only, never before the DB stopped referencing them ---------- */
function storagePathFromUrl(url, bucket){
  try{
    const u = new URL(url);
    if(u.origin !== new URL(SUPABASE_URL).origin) return null;          // external image: never touch
    const marker = `/storage/v1/object/public/${bucket}/`;
    if(!u.pathname.startsWith(marker)) return null;
    return decodeURIComponent(u.pathname.slice(marker.length));
  }catch(e){ return null; }
}
async function removeOwnedListingImages(urls, listingId){
  if(!ME.id || !urls || !urls.length) return 0;
  try{
    // anything still referenced by one of my listings must stay
    const { data: mine, error } = await sb.from("listings").select("id,images").eq("seller_id", ME.id);
    if(error) throw error;
    const used = new Set(); (mine||[]).forEach(r=>(r.images||[]).forEach(u=>used.add(u)));
    const prefix = `${ME.id}/${listingId}/`;      // layout written by the uploader: {user}/{listing}/{file}
    const paths = [...new Set(urls)].filter(u=>!used.has(u)).map(u=>storagePathFromUrl(u,"listing-images"))
      .filter(p=>p && p.startsWith(prefix) && !p.slice(prefix.length).includes("/"));
    if(!paths.length) return 0;
    const { error: e2 } = await sb.storage.from("listing-images").remove(paths);
    if(e2) throw e2;
    return paths.length;
  }catch(e){ console.warn("Image cleanup skipped:", e); return 0; }
}
async function removeOwnedStoreImages(urls){
  if(!ME.id) return 0;
  try{
    const store = await fetchMyStore();
    const used = new Set([store && store.logo_url, store && store.cover_url].filter(Boolean));
    const prefix = `${ME.id}/`;
    const paths = [...new Set((urls||[]).filter(Boolean))].filter(u=>!used.has(u)).map(u=>storagePathFromUrl(u,"store-images"))
      .filter(p=>p && p.startsWith(prefix) && !p.slice(prefix.length).includes("/"));
    if(!paths.length) return 0;
    const { error } = await sb.storage.from("store-images").remove(paths);
    if(error) throw error;
    return paths.length;
  }catch(e){ console.warn("Store image cleanup skipped:", e); return 0; }
}

/* ---------- "Ukloni logo" / "Ukloni baner" ---------- */
const removeStoreImage = guarded("storeImgRemove", async (kind)=>{
  if(!ME.id) { requireAuthRedirect(); return; }
  const col = kind==="logo" ? "logo_url" : "cover_url";
  const noun = storeImgNoun(kind);
  if(!confirm(`Ukloniti ${noun} prodavnice?`)) return;
  const shown = storeImgState[kind];                 // what the preview shows (may be a not-yet-saved upload)
  const saved = sfStore ? sfStore[col] : null;       // what the database currently holds
  try{
    if(sfStore){
      // owner_id filter + RLS: only the owner's own store row can match
      const { data, error } = await sb.from("stores").update({ [col]: null }).eq("id", sfStore.id).eq("owner_id", ME.id).select("id");
      if(error) throw error;
      if(!data || !data.length) throw new Error("Nemaš dozvolu za ovu prodavnicu");
      sfStore[col] = null;
      if(STORE_CACHE[sfStore.id]) STORE_CACHE[sfStore.id][col] = null;
    }
    storeImgState[kind] = null;
    sfRefreshImg(kind);
    toast(kind==="logo" ? "Logo je uklonjen" : "Baner je uklonjen");
    await removeOwnedStoreImages([saved, shown]);    // after the DB update; own files only
  }catch(e){
    console.error(e);
    toast(e && /dozvolu/i.test(e.message||"") ? e.message : `Greška pri uklanjanju (${noun})`);
  }
});
